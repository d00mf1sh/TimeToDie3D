﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Get Volume", BlockType.Variable, Order = 1, ShowIcon = "listener",
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Return the volume of the selected sound volume type as an integer value from 0 to 100 (percentage).")]
	public class plyGame_Audio_GetVolume : Int_Value
	{
		[plyBlockField("Volume of", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "The sound volume type.")]
		public GameGlobal.VolumeType type = GameGlobal.VolumeType.Main;

		public override void Created()
		{
			GameGlobal.Create();
			stopAllOnError = false;
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			float f = GameGlobal.Instance.GetSoundVolume(type);
			value = Mathf.Clamp((int)(f * 100f), 0, 100);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}