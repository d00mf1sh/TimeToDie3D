﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Stop Music", BlockType.Action, Order = 1, ShowIcon = "audio", ShowName = "Stop Music",
		Description = "Stops any playing music.")]
	public class plyGame_Audio_StopMusic : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create();
			stopAllOnError = false;
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.StopMusic();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}