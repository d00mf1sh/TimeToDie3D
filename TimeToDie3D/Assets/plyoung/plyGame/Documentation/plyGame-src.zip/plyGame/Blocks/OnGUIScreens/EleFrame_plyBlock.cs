﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Element Frame", BlockType.Variable, Order = 10,
		ReturnValueString = "Return - Rect", ReturnValueType = typeof(Rect_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Calculate a GUI element's position and frame from given settings.")]
	public class EleFrame_plyBlock : Rect_Value
	{
		[plyBlockField("anchor", ShowValue = true, ShowAfterField=":")]
		public UIAnchor anchor = UIAnchor.MiddleCenter;
		[plyBlockField("scaling", ShowValue = true, ShowAfterField = "-")]
		public UIScale scaling = UIScale.None;
		[plyBlockField("offsetX", ShowValue = true, ShowAfterField = ",")]
		public int offsetX = 0;
		[plyBlockField("offsetY", ShowValue = true, ShowAfterField = ",")]
		public int offsetY = 0;
		[plyBlockField("width", ShowValue = true, ShowAfterField = ",")]
		public int width = 100;
		[plyBlockField("height", ShowValue = true)]
		public int height = 100;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = GUIScreen.GetElementFrame(anchor, scaling, offsetX, offsetY, width, height);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}