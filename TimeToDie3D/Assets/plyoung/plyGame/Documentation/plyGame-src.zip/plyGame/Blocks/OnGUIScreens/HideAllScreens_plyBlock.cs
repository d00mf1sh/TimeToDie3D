﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Hide All Screens", BlockType.Action, Order = 10,
		ShowName = "Hide All Screens",
		Description = "Will hide all screens.")]
	public class HideAllScreens_plyBlock : plyBlock
	{

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.uiManager.HideAllScreens(false);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}