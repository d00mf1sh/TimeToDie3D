﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Screen is Visible", BlockType.Condition, Order = 10,
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Returns True if the Custom screen is currently visible, else False.")]
	public class ScreenIsVisible_plyBlock : Bool_Value
	{
		[plyBlockField("Screen:", ShowAfterField="is visible?", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screenName = new ScreenDefNameTextData();

		private GUIScreen screen;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = !string.IsNullOrEmpty(screenName.name);
			if (!blockIsValid) Log(LogType.Error, "Screen Name must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				value = false;
				return BlockReturn.OK;
			}

			if (screen == null)
			{
				screen = GameGlobal.Instance.uiManager.GetScreen(screenName.name);
				if (screen == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The screen is not defined: " + screenName.name);
					return BlockReturn.Error;
				}
			}

			value = screen.visible;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}