﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Set Image", BlockType.Action, Order = 10, 
		Description = "Set the image used on an element. This could be used to set the image of the Image element. Ignored if element does not make use of an image.")]
	public class ScreensEle_SetImage_plyBlock : plyBlock
	{
		[plyBlockField("Set Image of", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", CustomValueStyle = "plyBlox_BoldLabel", Description = "Name of the element as defined in the Screens Editor.")]
		public string eleName = "";

		[plyBlockField("on", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		[plyBlockField("to", ShowName = true, ShowValue = true, DefaultObject = typeof(UnityObject_Value), BasicTypeHint = typeof(Texture2D), SubName = "Value - UnityObject (Texture2D)", Description = "")]
		public UnityObject_Value img;

		private OnGUIElement ele;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) { Log(LogType.Error, "Screen name must be set."); return; }
			blockIsValid = !string.IsNullOrEmpty(eleName);
			if (!blockIsValid) { Log(LogType.Error, "Element name must be set."); return; }
			blockIsValid = img != null;
			if (!blockIsValid) { Log(LogType.Error, "Image field must be set."); return; }
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				Log(LogType.Warning, "The screen system is not yet ready. You are making calls too early.");
				return BlockReturn.OK;
			}

			if (ele == null)
			{
				GUIScreen scr = GameGlobal.Instance.uiManager.GetScreen(screen.name);
				if (scr == null)
				{
					Log(LogType.Error, "The screen [" + screen.name + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}

				ele = scr.GetElement(eleName);
				if (ele == null)
				{
					Log(LogType.Error, "The element [" + eleName + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}
			}

			Texture2D t = img.RunAndGetUnityObject() as Texture2D;
			if (t != null)
			{
				ele.SetImage(t);
			}
			else
			{
				Log(LogType.Error, "The specified value is on an Image (Texture2D).");
				blockIsValid = false;
				return BlockReturn.Error;
			}
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}