﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Set Style", BlockType.Action, Order = 10, 
		Description = "Change the Style of the Screen Element.")]
	public class ScreensEle_SetStyle_plyBlock : plyBlock
	{
		[plyBlockField("Set Style of", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", CustomValueStyle = "plyBlox_BoldLabel", Description = "Name of the element as defined in the Screens Editor.")]
		public string eleName = "";

		[plyBlockField("on", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		[plyBlockField("to", ShowName = true, ShowValue = true, DefaultObject=typeof(String_Value), SubName="Style Name - String", Description = "Name of the new Style for Element.")]
		public String_Value styleName;

		GUIScreen scr;
		private OnGUIElement ele;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) { Log(LogType.Error, "Screen name must be set."); return; }
			blockIsValid = !string.IsNullOrEmpty(eleName);
			if (!blockIsValid) { Log(LogType.Error, "Element name must be set."); return; }
			blockIsValid = styleName != null;
			if (!blockIsValid) { Log(LogType.Error, "Style field must be set."); return; }
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				Log(LogType.Warning, "The screen system is not yet ready. You are making calls too early.");
				return BlockReturn.OK;
			}

			if (ele == null)
			{
				scr = GameGlobal.Instance.uiManager.GetScreen(screen.name);
				if (scr == null)
				{
					Log(LogType.Error, "The screen [" + screen.name + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}

				ele = scr.GetElement(eleName);
				if (ele == null)
				{
					Log(LogType.Error, "The element [" + eleName + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}
			}

			ele.SetStyle(scr.skin, styleName.RunAndGetString());
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}