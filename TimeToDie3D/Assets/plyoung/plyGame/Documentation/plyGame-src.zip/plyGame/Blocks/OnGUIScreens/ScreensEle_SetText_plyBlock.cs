﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Set Text", BlockType.Action, Order = 10, 
		Description = "Set the text used on an element. This could be used to set the label on a button or the text in a text edit element. Ignored if element does not make use of a label or text.")]
	public class ScreensEle_SetText_plyBlock : plyBlock
	{
		[plyBlockField("Set Text of", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", CustomValueStyle = "plyBlox_BoldLabel", Description = "Name of the element as defined in the Screens Editor.")]
		public string eleName = "";

		[plyBlockField("on", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		[plyBlockField("to", ShowName = true, ShowValue = true, DefaultObject=typeof(String_Value), SubName="Value - String", Description="")]
		public String_Value text;

		private OnGUIElement ele;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) { Log(LogType.Error, "Screen name must be set."); return; }
			blockIsValid = !string.IsNullOrEmpty(eleName);
			if (!blockIsValid) { Log(LogType.Error, "Element name must be set."); return; }
			blockIsValid = text != null;
			if (!blockIsValid) { Log(LogType.Error, "Text field must be set."); return; }
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				Log(LogType.Warning, "The screen system is not yet ready. You are making calls too early.");
				return BlockReturn.OK;
			}

			if (ele == null)
			{
				GUIScreen scr = GameGlobal.Instance.uiManager.GetScreen(screen.name);
				if (scr == null)
				{
					Log(LogType.Error, "The screen [" + screen.name + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}

				ele = scr.GetElement(eleName);
				if (ele == null)
				{
					Log(LogType.Error, "The element [" + eleName + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}
			}

			ele.SetText(text.RunAndGetString());
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}