﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Render", "Screen (plyGame)", "Save GFX Settings", BlockType.Action, Order = 31, ShowName = "Save GFX Settings",
		Description = "Saves the quality level and resolution settings.")]
	public class SaveScreenSettings_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.SafeGFXSettings();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}