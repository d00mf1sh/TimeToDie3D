﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary>
	/// This will make an object fall to the floor. You need to instantiate the Item in the air
	/// then attach this component. The Item will then be dropped to the floor but at an arc
	/// from the start position. The object should have a collider. This component will 
	/// remove itself when done.
	/// </summary>
	[AddComponentMenu("")]
	public class FallToFloor : MonoBehaviour
	{

		public bool freezeRotation = false;
		public bool giveRandomPush = true;
		public Vector3 forwardVelocity = Vector3.zero; // not used if giveRandomPush = true

		private List<Collider> changedTriggers = new List<Collider>();
		private Rigidbody rb;
		private bool removeRB = false;
		private bool rotWasFrozen = false;
		
		protected void Start()
		{
			// make sure there is rigidbody so it can handle the physics
			rb = gameObject.GetComponent<Rigidbody>();
			if (rb == null)
			{
				removeRB = true;
				rb = gameObject.AddComponent<Rigidbody>();
			}
			else
			{
				rotWasFrozen = rb.freezeRotation;
			}

			rb.freezeRotation = freezeRotation;

			// make sure all colliders are active and not triggers
			Collider[] c = gameObject.GetComponentsInChildren<Collider>();
			for (int i = 0; i < c.Length; i++)
			{
				if (c[i].isTrigger)
				{
					changedTriggers.Add(c[i]);
					c[i].isTrigger = false;
				}
			}

			// give the item a little push so the drop looks better
			if (giveRandomPush)
			{
				float x = Random.Range(1.5f, 2.5f) * (Random.Range(0, 2) == 0 ? -1 : 1);
				float z = Random.Range(1.5f, 2.5f) * (Random.Range(0, 2) == 0 ? -1 : 1);
				rb.velocity = new Vector3(x, 1.5f, z);
				//rigidbody.velocity = Random.onUnitSphere * 3f;
			}
			else
			{
				rb.velocity = forwardVelocity;
			}
		}

		protected void LateUpdate()
		{
			if (rb == null) return;
			if (rb.IsSleeping())
			{
				for (int i = 0; i < changedTriggers.Count; i++) changedTriggers[i].isTrigger = true;
				if (removeRB) Destroy(rb);
				else rb.freezeRotation = rotWasFrozen;
				Destroy(this);
			}
		}

		// ============================================================================================================
	}
}