﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	/// <summary>
	/// This class handles destroying an object. There are various ways in which it can happen
	/// like first sinking the object below the terrain before removing. This class is used
	/// by behaviours as needed.
	/// </summary>
	[System.Serializable]
	public class ObjectDestroyerHandler
	{
		/// <summary> Method to use </summary>
		public enum DestroyMethod
		{
			DoNothing=-1,		//!< Do not destroy the object
			Destroy=0,			//!< Simply destroy after a timeout
			SinkAndDestroy=1,	//!< Move a certain distance on Y and then destroy
		}

		public DestroyMethod method = DestroyMethod.Destroy;	//!< destroy method to use

		/// <summary>
		/// the opt_ variables' use depends on what DestroyMethod was chosen
		/// Destroy:
		///		opt_c is how long (in seconds) to wait before destroying the object
		/// SinkAndDestroy: 
		///		opt_a = how far to sink (meters, must be positive number)
		///		opt_b = at what speed it will sink
		///		opt_c = after what timeout (seconds) will sinking start
		/// </summary>
		public float opt_a = 1f;
		public float opt_b = 1f;	//<! see opt_a
		public float opt_c = 10f;	//<! see opt_a

		// ============================================================================================================

		private Transform target;
		private bool done = true;
		private Vector3 pos;
		private float timer = 0f;

		// ============================================================================================================

		/// <summary>
		/// Called by an object to start the destroy procedure
		/// </summary>
		public void Start(Transform target)
		{
			done = (method == DestroyMethod.DoNothing);
			this.target = target;

			if (method == DestroyMethod.Destroy)
			{
				done = true; // no need to run update loop
				if (opt_c > 0.0f) Object.Destroy(target.gameObject, opt_c);
				else Object.Destroy(target.gameObject);
			}
			else if (method == DestroyMethod.SinkAndDestroy)
			{
				// set target position to reach
				pos = target.position; pos.y -= Mathf.Abs(opt_a);
				timer = opt_c;
			}
		}

		/// <summary>
		/// Called by an object to have the destroy procedure update as needed
		/// </summary>
		public void Update()
		{
			if (done) return;
			UpdateSinkAndDestroy();
		}

		private void UpdateSinkAndDestroy()
		{
			if (timer > 0.0f) timer -= Time.deltaTime;
			else
			{
				target.position = Vector3.MoveTowards(target.position, pos, Time.deltaTime * opt_b);
				if (target.position.y <= pos.y)
				{
					done = true;
					Object.Destroy(target.gameObject);
				}
			}
		}

		// ============================================================================================================
	}
}