﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("plyGame/Misc/Sound Volume Updater")]
	public class SoundVolumeUpdater : MonoBehaviour
	{
		public GameGlobal.VolumeType volumeType = GameGlobal.VolumeType.Main;
		public AudioSource audioSource;

		protected void Awake()
		{
			if (audioSource == null) audioSource = GetComponent<AudioSource>();
		}

		protected IEnumerator Start()
		{
			// wait a frame
			yield return null;
			UpdateVolume();
		}

		public void UpdateVolume()
		{
			if (audioSource != null)
			{
				audioSource.volume = GameGlobal.Instance.dataAsset.volume[(int)volumeType];
			}
		}

		// ============================================================================================================
	}
}