﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class CustomScreensAsset : ScriptableObject
	{
		[HideInInspector] public List<GUIScreen> screens = new List<GUIScreen>();
		[HideInInspector, SerializeField] private int nextScreenId = 0;
		public int NextScreenId { get { nextScreenId++; return nextScreenId - 1; } }

		// ============================================================================================================
	}
}
