﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> plyGame definitions. </summary>
	[System.Serializable]
	public class DataAsset : ScriptableObject
	{
		[HideInInspector] public GameObject loadSaveProviderFab = null;							//!< The prefab that the LoadSave provider is instantiated from at runtime
		[HideInInspector] public List<ScriptableObject> assets = new List<ScriptableObject>(1); //!< References to assets. Mostly those created via the plyGame Editor. Do not access this directly, use the static functions provided by the asset's class if you need it
		[HideInInspector] public List<GameObject> autoCreate = new List<GameObject>(0);			//!< List of prefabs that wants to be auto created when GameGlobal is created. Do not manipulate directly. See EdGlobal.RegisterAutoCreate()
		[HideInInspector] public List<string> autoComponents = new List<string>(0);				//!< components that will automatically be attached to existing objects. Do not manipulate directly, use EdGlobal.RegisterAutoComponent()
		[HideInInspector] public List<GameObject> autoFabs = new List<GameObject>(0);			//!< These are similar to autoCreate but is the list of prefabs added by the designer via the plyGame main editor. Do not use this directly. For autoCreate prefabs of plyGame plugins you need to use EdGlobal.RegisterAutoCreate 

		[HideInInspector] public float[] volume = { 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f };
		[HideInInspector] public GameGlobal.VolumeType guiVolumeType = GameGlobal.VolumeType.GUI;
		[HideInInspector] public bool createDefaultAudioListener = true;

		// ============================================================================================================

		/// <summary> (used by editor scripts) Get reference to an asset saved in dataAsset.assets list </summary>
		public ScriptableObject GetAsset<T>()
		{
			for (int i = 0; i < assets.Count; i++)
			{
				if (assets[i] == null) continue; // can happen
				if (typeof(T).IsAssignableFrom(assets[i].GetType()))
				{
					return assets[i];
				}
			}
			return null;
		}

		/// <summary> (used by editor scripts) Add asset to list. return true if actually added to list and false if already in list (or if was null) </summary>
		public bool AddAsset(ScriptableObject asset)
		{
			if (asset == null) return false;
			if (!assets.Contains(asset))
			{
				assets.Add(asset);
				return true;
			}
			return false;
		}

		/// <summary> (used by editor scripts) Set null and remove and asset in dataAsset.assets list. return true if removed, else false if was not in list </summary>
		public bool RemoveAsset(ScriptableObject asset)
		{
			if (asset == null) return false;
			int idx = assets.IndexOf(asset);
			if (idx >= 0)
			{
				assets[idx] = null;
				assets.RemoveAt(idx);
				Resources.UnloadUnusedAssets();
				return true;
			}
			return false;
		}

		// ============================================================================================================
	}
}