﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class LoadScreensAsset : ScriptableObject
	{
		[HideInInspector] public List<GUIScreen> screens = new List<GUIScreen>();
		[HideInInspector, SerializeField] private int nextScreenId = 0;
		[HideInInspector] public float minLoadTime = 0f;
		[HideInInspector] public bool clickToContinue = false;
		[HideInInspector] public string loadText = "now loading ...";

		public int NextScreenId { get { nextScreenId++; return nextScreenId - 1; } }
		
		// ============================================================================================================
	}
}
