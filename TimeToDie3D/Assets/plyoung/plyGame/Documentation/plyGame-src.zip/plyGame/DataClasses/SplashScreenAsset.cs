﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class SplashScreenAsset : ScriptableObject
	{
		[HideInInspector] public List<SplashScreenData> screens = new List<SplashScreenData>();

		// ============================================================================================================
	}
}