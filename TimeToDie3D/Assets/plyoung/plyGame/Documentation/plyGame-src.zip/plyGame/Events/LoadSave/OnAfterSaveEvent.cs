﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("Common", "On After Save",
		Description = "Called after data was saved for the object.")]
	public class OnAfterSaveEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_LoadSaveSystem);
		}

		// ============================================================================================================
	}
}