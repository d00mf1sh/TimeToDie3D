﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	public enum UIAnchor { UpperLeft = 0, UpperCenter = 1, UpperRight = 2, MiddleLeft = 3, MiddleCenter = 4, MiddleRight = 5, LowerLeft = 6, LowerCenter = 7, LowerRight = 8, }
	public enum UIScale { None = 0, ScaleAndCrop = 1, ScaleToFit = 2, StretchBoth = 3, StretchWidth = 4, StretchHeight = 5 }
	public enum UIElementType { None, Label, Image, Movie, Button, Edit, Toggle, Box }

	[System.Serializable]
	public class OnGUIElement
	{
		public int id = -1;
		public string name;
		public UIElementType type = UIElementType.None;

		public int zdepth = 0;	// Depth of the block (in front or behind other blocks)
		public UIAnchor anchor = UIAnchor.MiddleCenter;
		public UIScale scaling = UIScale.None;
		public int offsetX = 0;
		public int offsetY = 0;
		public int width = 100;
		public int height = 100;

		public bool visible = true;
		public bool enabled = true;
		public string styleName = "";

		public AudioClip soundClip;
		public string eventName;
		public string eventParam1;
		public string eventParam2;
		public string eventParam3;

		public bool langEdTouched = false; // helper for multi-lang feature and editor

		// ============================================================================================================
		#region Runtime/ Editor

		[System.NonSerialized] public Rect frame;
		[System.NonSerialized] public GUIStyle style;
		protected GeneralCallback onEvent = null;
		protected object[] args = null;

		#endregion
		// ============================================================================================================
		#region sys

		public virtual OnGUIElement Copy()
		{
			OnGUIElement obj = new OnGUIElement();
			this.CopyTo(obj);
			return obj;
		}

		public virtual void CopyTo(OnGUIElement o)
		{
			o.id = this.id;
			o.name = this.name;
			o.type = this.type;
			o.zdepth = this.zdepth;
			o.anchor = this.anchor;
			o.scaling = this.scaling;
			o.offsetX = this.offsetX;
			o.offsetY = this.offsetY;
			o.width = this.width;
			o.height = this.height;
			o.visible = this.visible;
			o.enabled = this.enabled;
			o.styleName = this.styleName;
			o.soundClip = this.soundClip;
			o.eventName = this.eventName;
			o.eventParam1 = this.eventParam1;
			o.eventParam2 = this.eventParam2;
			o.eventParam3 = this.eventParam3;
		}

		public override string ToString()
		{
			return name;
		}

		#endregion
		// ============================================================================================================
		#region pub

		public virtual void InitGUICache(GUISkin skin)
		{
			RecalcFrame();
			style = skin.FindStyle(styleName);
			if (style == null) style = new GUIStyle();
		}

		public void InitGUICacheEd(GUISkin skin)
		{	// special version used by editor where I need to grab style from customStyles[] array if possible
			// else it will not update in real time. Get/FindStyle seems to cache it.

			InitGUICache(skin);
			
			for (int i = 0; i < skin.customStyles.Length; i++)
			{
				if (skin.customStyles[i] == null) continue;
				if (skin.customStyles[i].name.Equals(styleName))
				{
					style = skin.customStyles[i];
					return;
				}
			}
		}

		public void RecalcFrame()
		{
			frame = GUIScreen.GetElementFrame(this);
		}

		public virtual void Init()
		{
		}

		public virtual void OnScreenVisibleChange(bool becomeVisible)
		{
		}

		public virtual void Draw()
		{
		}

		public virtual void EdDraw(Rect r)
		{
		}

		public virtual void SetStyle(GUISkin skin, string styleName)
		{
			this.styleName = styleName;
			style = skin.FindStyle(styleName);
			if (style == null) style = new GUIStyle();
		}

		public virtual void SetText(string txt)
		{
		}

		public virtual void SetImage(Texture2D img)
		{
		}

		// ============================================================================================================

		protected void PlaySound()
		{
			if (soundClip != null)
			{
				GUIManager.Instance.PlayGUISound(soundClip);
			}
		}

		public void SetCallback(GeneralCallback callback, object[] args)
		{
			this.onEvent = callback;
			this.args = args;
		}

		public void RemoveCallback()
		{
			this.onEvent = null;
			this.args = null;
		}

		#endregion
		// ============================================================================================================
	}
}