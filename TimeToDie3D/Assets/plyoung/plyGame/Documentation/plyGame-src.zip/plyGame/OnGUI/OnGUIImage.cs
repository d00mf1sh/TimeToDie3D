﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[System.Serializable]
	public class OnGUIImage : OnGUIElement
	{
		public Texture2D texture;

		// ============================================================================================================

		public OnGUIImage()
		{
			type = UIElementType.Image;
		}

		public override OnGUIElement Copy()
		{
			OnGUIImage obj = new OnGUIImage();
			this.CopyTo(obj);
			return obj;
		}

		public override void CopyTo(OnGUIElement obj)
		{
			base.CopyTo(obj);
			OnGUIImage o = obj as OnGUIImage;
			o.texture = this.texture;
		}

		// ============================================================================================================

		public override void Draw()
		{
			if (texture != null)
			{
				GUI.DrawTexture(frame, texture);
			}
		}

		public override void EdDraw(Rect r)
		{
			if (texture != null)
			{
				GUI.DrawTexture(r, texture);
			}
		}

		public override void SetImage(Texture2D img)
		{
			texture = img;
		}

		// ============================================================================================================
	}
}