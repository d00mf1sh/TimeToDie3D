﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	public enum UITextAlign { Left = 0, Center = 1, Right = 2 }

	[System.Serializable]
	public class OnGUILabel : OnGUIElement
	{
		public string text;
		public bool showOutline = false;
		public bool showShadow = false;
		public Color outlineColor = Color.black;
		public Color shadowColor = Color.black;
		public float outlineThickness = 2f;
		public Vector2 shadowOffset = Vector2.one;

		// ============================================================================================================

		public OnGUILabel()
		{
			type = UIElementType.Label;
			styleName = "label";
		}

		public override OnGUIElement Copy()
		{
			OnGUILabel obj = new OnGUILabel();
			this.CopyTo(obj);
			return obj;
		}

		public override void CopyTo(OnGUIElement obj)
		{
			base.CopyTo(obj);
			OnGUILabel o = obj as OnGUILabel;
			o.text = this.text;
			o.showOutline = this.showOutline;
			o.showShadow = this.showShadow;
			o.outlineColor = this.outlineColor;
			o.outlineThickness = this.outlineThickness;
			o.shadowColor = this.shadowColor;
			o.shadowOffset = this.shadowOffset;
		}

		// ============================================================================================================

		public override void Draw()
		{
			if (showShadow)
			{
				Color col = style.normal.textColor;
				style.normal.textColor = shadowColor;
				Rect rt = frame; rt.x += shadowOffset.x; rt.y += shadowOffset.y;
				GUI.Label(rt, text, style);
				style.normal.textColor = col;
			}

			if (showOutline)
			{
				Color col = style.normal.textColor;
				style.normal.textColor = outlineColor;
				Rect rt = frame; rt.x -= outlineThickness; rt.y -= outlineThickness;
				GUI.Label(rt, text, style);
				rt.x += outlineThickness * 2f;
				GUI.Label(rt, text, style);
				rt.y += outlineThickness * 2f;
				GUI.Label(rt, text, style);
				rt.x -= outlineThickness * 2f;
				GUI.Label(rt, text, style);
				style.normal.textColor = col;
			} 
			
			GUI.Label(frame, text, style);
		}

		public override void EdDraw(Rect r)
		{
			if (showShadow)
			{
				Color col = style.normal.textColor;
				style.normal.textColor = shadowColor;
				Rect rt = r; rt.x += shadowOffset.x; rt.y += shadowOffset.y;
				GUI.Label(rt, text, style);
				style.normal.textColor = col;
			}

			if (showOutline)
			{
				Color col = style.normal.textColor;
				style.normal.textColor = outlineColor;
				Rect rt = r; rt.x -= outlineThickness; rt.y -= outlineThickness;
				GUI.Label(rt, text, style);
				rt.x += outlineThickness * 2f;
				GUI.Label(rt, text, style);
				rt.y += outlineThickness * 2f;
				GUI.Label(rt, text, style);
				rt.x -= outlineThickness * 2f;
				GUI.Label(rt, text, style);
				style.normal.textColor = col;
			}

			GUI.Label(r, text, style);
		}

		public override void SetText(string txt)
		{
			text = txt;
		}

		// ============================================================================================================
	}
}