﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[System.Serializable]
	public class OnGUIToggle : OnGUIElement
	{
		public string label;
		public bool initState;

		// ============================================================================================================
		
		[System.NonSerialized] public bool state;

		// ============================================================================================================

		public OnGUIToggle()
		{
			type = UIElementType.Toggle;
			styleName = "toggle";
		}

		public override OnGUIElement Copy()
		{
			OnGUIToggle obj = new OnGUIToggle();
			this.CopyTo(obj);
			return obj;
		}

		public override void CopyTo(OnGUIElement obj)
		{
			base.CopyTo(obj);
			OnGUIToggle o = obj as OnGUIToggle;
			o.initState = this.initState;
			o.label = this.label;
		}

		// ============================================================================================================

		public override void Init()
		{
			state = initState;
		}

		public override void Draw()
		{
			bool prev = state;
			state = GUI.Toggle(frame, state, label, style);
			if (state != prev)
			{
				PlaySound();
				if (onEvent != null)
				{
					eventParam2 = state ? "on" : "off";
					onEvent(this, args);
				}
			}
		}

		public override void EdDraw(Rect r)
		{
			GUI.enabled = false;
			GUI.color = Color.white;
			GUI.Toggle(r, initState, label, style);
			GUI.enabled = true;
		}

		public override void SetText(string txt)
		{
			label = txt;
		}

		// ============================================================================================================
	}
}