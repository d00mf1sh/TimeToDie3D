﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> InputBind </summary>
	[System.Serializable]
	public class InputBind
	{
		public enum Device
		{
			KeyMouse=0,
			Gamepad=1,
			//Virtual=2
		}

		public enum MouseAxis 
		{ 
			None=-1,
			MouseX=0,
			MouseY=1,
			ScrollWheel=2
		}

		public enum Gamepad 
		{ 
			None=0,
			Gamepad1=1,
			Gamepad2=2,
			Gamepad3=3,
			Gamepad4=4
		}

		public enum GamepadAxis 
		{ 
			None=-1,
			Axis1=0,
			Axis2=1,
			Axis3=2,
			Axis4=3,
			Axis5=4,
			Axis6=5,
			Axis7=6,
			Axis8=7,
			Axis9=8,
			Axis10=9
		}

		public enum AxisSide
		{
			Positive=0,
			Negative=1
		}

		// ============================================================================================================

		public Device device = Device.KeyMouse;

		public KeyCode keyMod = KeyCode.None;				//!< modifier key for input
		public KeyCode key1 = KeyCode.None;					//!< primary or positive axis
		public KeyCode key2 = KeyCode.None;					//!< negative axis

		public MouseAxis mouseAxis = MouseAxis.None;
		public bool keyMouseInvert = false;
		public AxisSide mouseAxisSide = AxisSide.Positive;	// use to detect axis change as a button

		public GamepadAxis gamepadAxisMod = GamepadAxis.None;
		public GamepadAxis gamepadAxis = GamepadAxis.None;
		public bool gamepadInvert = false;
		public AxisSide gamepadAxisModSide = AxisSide.Positive;
		public AxisSide gamepadAxisSide = AxisSide.Positive;

		// ============================================================================================================

		public void Reset()
		{
			keyMod = KeyCode.None;
			key1 = KeyCode.None;
			key2 = KeyCode.None;

			mouseAxis = MouseAxis.None;
			keyMouseInvert = false;
			mouseAxisSide = AxisSide.Positive;

			gamepadAxisMod = GamepadAxis.None;
			gamepadAxis = GamepadAxis.None;
			gamepadInvert = false;
			gamepadAxisModSide = AxisSide.Positive;
			gamepadAxisSide = AxisSide.Positive;
		}

		public virtual InputBind Copy()
		{
			InputBind d = new InputBind();
			this.CopyTo(d);
			return d;
		}

		public virtual void CopyTo(InputBind d)
		{
			d.device = this.device;
			d.keyMod = this.keyMod;
			d.key1 = this.key1;
			d.key2 = this.key2;
			d.mouseAxis = this.mouseAxis;
			d.keyMouseInvert = this.keyMouseInvert;
			d.mouseAxisSide = this.mouseAxisSide;
			d.gamepadAxisMod = this.gamepadAxisMod;
			d.gamepadAxis = this.gamepadAxis;
			d.gamepadInvert = this.gamepadInvert;
			d.gamepadAxisModSide = this.gamepadAxisModSide;
			d.gamepadAxisSide = this.gamepadAxisSide;
		}

		// ============================================================================================================
	}
}