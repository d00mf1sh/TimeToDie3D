﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> InputDefinition </summary>
	[System.Serializable]
	public class InputDefinition
	{
		public enum InputType
		{
			Button = 0,
			Axis = 1
		}
		
		// ============================================================================================================

		public InputType type = InputType.Button;			// The type of this input
		
		public bool active = true;							// Is the definition active?
		public string category;								// The category this definition belongs to
		public string name;									// The name of the definition
		public string screenName1;							// The name to show when presenting the input definition to the player - for key1 & key1Alt option (positive)
		public string screenName2;							// The name to show when presenting the input definition to the player - for key2 & key2Alt option (negative)

		public InputBind[] binds = new InputBind[0];

		// ============================================================================================================

		private string _ident = null;
		public string ident
		{
			get
			{
				if (_ident == null) _ident = category + "/" + name;
				return _ident;
			}
		}

		// ============================================================================================================

		public InputDefinition Copy()
		{
			InputDefinition d = new InputDefinition();

			d.type = this.type;
	
			d.active = this.active;
			d.category = this.category;
			d.name = this.name;
			d.screenName1 = this.screenName1;
			d.screenName2 = this.screenName2;

			d.binds = new InputBind[this.binds.Length];
			for (int i = 0; i < this.binds.Length; i++) d.binds[i] = this.binds[i].Copy();

			return d;
		}

		// ============================================================================================================
	}
}