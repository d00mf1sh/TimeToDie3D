﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> plyGame Input manager </summary>
	[AddComponentMenu("")]
	public class plyInput : MonoBehaviour
	{
		private const float mouseAxisButtonDetect = 0.2f;
		private const float gamepadAxisButtonDetect = 0.2f;

		/// <summary> Set this to True in each frame that input from mouse was handled. Will be reset to
		///  False in LateUpdate() </summary>
		public static bool MouseInputHandled { get; set; }

		// ============================================================================================================

		private static int nextIndex = 0;
		private static InputDefinition[] inputs = new InputDefinition[0];

		private static readonly string[] MouseAxisString = new string[] { "plyMouseX", "plyMouseY", "plyScrollWheel" };
		private static readonly string[] GamepadAxisString = new string[] { "plyPad1A1", "plyPad1A2", "plyPad1A3", "plyPad1A4", "plyPad1A5", "plyPad1A6", "plyPad1A7", "plyPad1A8", "plyPad1A9", "plyPad1A10" };

		private static bool hasShownInputConfigError = false;

		// ============================================================================================================
		#region system

		protected void Awake()
		{
			MouseInputHandled = false;
			Object.DontDestroyOnLoad(gameObject);
		}

		protected void LateUpdate()
		{
			MouseInputHandled = false;
		}

		#endregion
		// ============================================================================================================
		#region pub

		/// <summary> Initialise plyInput. The parentObject you specify should be a global that will not be destroyed
		///  during the life of the game running, else simply pass null and plyInput will create its own object. </summary>
		public static void Init(GameObject parentObject, InputDefAsset asset)
		{
			plyInput instance = FindObjectOfType<plyInput>();
			if (instance == null)
			{
				if (parentObject == null)
				{
					parentObject = new GameObject("plyInput");
					Object.DontDestroyOnLoad(parentObject);
				}
				parentObject.AddComponent<plyInput>();
			}

			nextIndex = 0;

			if (asset != null)
			{
				inputs = new InputDefinition[asset.inputDefs.Count];
				for (int i = 0; i < asset.inputDefs.Count; i++) DefineButton(asset.inputDefs[i]);
			}
			else inputs = new InputDefinition[0];

		}

		/// <summary> Call to save the changes made to the buttons to PlayerPrefs or via SaveLoad provider. </summary>
		public static void Save()
		{
			// todo
		}

		/// <summary> Call this only after having defined all buttons to read the changes that where saved
		///  to PlayerPrefs (or via SaveLoad provider) and overwrite any defaults assigned while defining
		///  the buttons. </summary>
		public static void Restore()
		{
			// todo
		}

		/// <summary> Define a button from an input definition. Return index (idx) of new input or -1 on error. </summary>
		public static int DefineButton(InputDefinition def)
		{
			if (def == null) return -1;
			if (def.active == false) return -1;
			if (string.IsNullOrEmpty(def.name)) return -1;
			if (nextIndex >= inputs.Length)
			{
				Debug.LogError("Strange error occurred. Please report.");
				return -1;
			}

			inputs[nextIndex] = def.Copy();
			nextIndex++;
			return nextIndex - 1;
		}

		/// <summary> Return the index (idx) of the defined button, -1 if not found. An def.ident is the combination of category and name
		/// for example: "Player/SelectNextTarget" </summary>
		public static int GetInputIdx(string ident)
		{
			for (int i = 0; i < inputs.Length; i++)
			{
				if (inputs[i] == null) continue;
				if (inputs[i].ident == ident)
				{
					return i;
				}
			}
			return -1;
		}

		/// <summary> Return true if the input definition is active </summary>
		public static bool IsActive(int idx)
		{
			if (idx < 0) return false;
			return inputs[idx].active;
		}

		/// <summary> Return true if the inputs, identified by idx1 and idx2, use similar buttons or axis. </summary>
		public static bool SimilarBinds(int idx1, int idx2)
		{
			if (idx1 < 0 || idx2 < 0) return false;
			if (idx1 == idx2) return false;
			if (inputs[idx1].type != inputs[idx2].type) return false;
			if (!inputs[idx1].active || !inputs[idx2].active) return false;

			for (int i = 0; i < inputs[idx1].binds.Length; i++)
			{
				for (int j = 0; j < inputs[idx2].binds.Length; j++)
				{
					if (inputs[idx1].binds[i].device == inputs[idx2].binds[j].device)
					{
						if (inputs[idx1].binds[i].device == InputBind.Device.KeyMouse)
						{
							if (inputs[idx1].binds[i].key1 == inputs[idx2].binds[j].key1 &&
								inputs[idx1].binds[i].key2 == inputs[idx2].binds[j].key2 &&
								inputs[idx1].binds[i].keyMod == inputs[idx2].binds[j].keyMod &&
								inputs[idx1].binds[i].mouseAxis == inputs[idx2].binds[j].mouseAxis) return true;
						}

						else if (inputs[idx1].binds[i].device == InputBind.Device.Gamepad)
						{
							if (inputs[idx1].binds[i].key1 == inputs[idx2].binds[j].key1 &&
								inputs[idx1].binds[i].key2 == inputs[idx2].binds[j].key2 &&
								inputs[idx1].binds[i].keyMod == inputs[idx2].binds[j].keyMod &&
								inputs[idx1].binds[i].gamepadAxis == inputs[idx2].binds[j].gamepadAxis && 
								inputs[idx1].binds[i].gamepadAxisMod == inputs[idx2].binds[j].gamepadAxisMod) return true;
						}
					}
				}
			}

			return false;
		}

		// ============================================================================================================

		/// <summary> Returns true while the virtual button is held down. </summary>
		public static bool GetButton(int idx)
		{
			if (idx < 0) return false;
			if (!inputs[idx].active) return false;
			if (inputs[idx].type != InputDefinition.InputType.Button) return false;

			for (int i = 0; i < inputs[idx].binds.Length; i++)
			{
				if (inputs[idx].binds[i].device == InputBind.Device.KeyMouse)
				{
					// skip if uses mouse bind and mouse input was captured by something else
					if (MouseInputHandled)
					{	
						if (inputs[idx].binds[i].key1 == KeyCode.None && inputs[idx].binds[i].mouseAxis != InputBind.MouseAxis.None) continue;
						if (IsMouseButton(inputs[idx].binds[i].key1) || IsMouseButton(inputs[idx].binds[i].keyMod)) continue;
					}

					if (inputs[idx].binds[i].keyMod != KeyCode.None && false == Input.GetKey(inputs[idx].binds[i].keyMod)) continue;
					if (inputs[idx].binds[i].key1 != KeyCode.None)
					{
						if (Input.GetKey(inputs[idx].binds[i].key1)) return true;
					}
					else if (MouseAxisAsButton_Held(inputs[idx].binds[i].mouseAxis, inputs[idx].binds[i].mouseAxisSide == InputBind.AxisSide.Positive)) return true;
				}

				else if (inputs[idx].binds[i].device == InputBind.Device.Gamepad)
				{
					if (inputs[idx].binds[i].keyMod != KeyCode.None && false == Input.GetKey(inputs[idx].binds[i].keyMod)) continue;
					if (inputs[idx].binds[i].gamepadAxisMod != InputBind.GamepadAxis.None && false == GamepadAxisAsButton_Held(inputs[idx].binds[i].gamepadAxisMod, inputs[idx].binds[i].gamepadAxisModSide == InputBind.AxisSide.Positive)) continue;
					if (inputs[idx].binds[i].key1 != KeyCode.None)
					{
						if (Input.GetKey(inputs[idx].binds[i].key1)) return true;
					}
					if (GamepadAxisAsButton_Held(inputs[idx].binds[i].gamepadAxis, inputs[idx].binds[i].gamepadAxisSide == InputBind.AxisSide.Positive)) return true;
				}
			}

			return false;
		}

		/// <summary> Returns true during the frame the user pressed down the virtual button identified by
		///  'name'. </summary>
		public static bool GetButtonDown(int idx)
		{
			if (idx < 0) return false;
			if (!inputs[idx].active) return false;
			if (inputs[idx].type != InputDefinition.InputType.Button) return false;

			for (int i = 0; i < inputs[idx].binds.Length; i++)
			{
				if (inputs[idx].binds[i].device == InputBind.Device.KeyMouse)
				{
					// skip if uses mouse bind and mouse input was captured by something else
					if (MouseInputHandled)
					{
						if (inputs[idx].binds[i].key1 == KeyCode.None && inputs[idx].binds[i].mouseAxis != InputBind.MouseAxis.None) continue;
						if (IsMouseButton(inputs[idx].binds[i].key1) || IsMouseButton(inputs[idx].binds[i].keyMod)) continue;
					}

					if (inputs[idx].binds[i].keyMod != KeyCode.None && false == Input.GetKey(inputs[idx].binds[i].keyMod)) continue;
					if (inputs[idx].binds[i].key1 != KeyCode.None)
					{
						if (Input.GetKeyDown(inputs[idx].binds[i].key1)) return true;
					}
					// do not support detection of axis as button in this case
					//else if (MouseAxisAsButton_Held(inputs[idx].binds[i].mouseAxis, inputs[idx].binds[i].mouseAxisSide == InputBind.AxisSide.Positive)) return true;
				}

				else if (inputs[idx].binds[i].device == InputBind.Device.Gamepad)
				{
					if (inputs[idx].binds[i].keyMod != KeyCode.None && false == Input.GetKey(inputs[idx].binds[i].keyMod)) continue;
					if (inputs[idx].binds[i].gamepadAxisMod != InputBind.GamepadAxis.None && false == GamepadAxisAsButton_Held(inputs[idx].binds[i].gamepadAxisMod, inputs[idx].binds[i].gamepadAxisModSide == InputBind.AxisSide.Positive)) continue;
					if (inputs[idx].binds[i].key1 != KeyCode.None)
					{
						if (Input.GetKeyDown(inputs[idx].binds[i].key1)) return true;
					}
					// do not support detection of axis as button in this case
					//if (GamepadAxisAsButton_Held(inputs[idx].binds[i].gamepadAxis, inputs[idx].binds[i].gamepadAxisSide == InputBind.AxisSide.Positive)) return true;
				}
			}

			return false;
		}

		/// <summary> Returns true the first frame the user releases the virtual button. </summary>
		public static bool GetButtonUp(int idx)
		{
			if (idx < 0) return false;
			if (!inputs[idx].active) return false;
			if (inputs[idx].type != InputDefinition.InputType.Button) return false;

			for (int i = 0; i < inputs[idx].binds.Length; i++)
			{
				if (inputs[idx].binds[i].device == InputBind.Device.KeyMouse)
				{
					// skip if uses mouse bind and mouse input was captured by something else
					if (MouseInputHandled)
					{
						if (inputs[idx].binds[i].key1 == KeyCode.None && inputs[idx].binds[i].mouseAxis != InputBind.MouseAxis.None) continue;
						if (IsMouseButton(inputs[idx].binds[i].key1) || IsMouseButton(inputs[idx].binds[i].keyMod)) continue;
					}

					if (inputs[idx].binds[i].keyMod != KeyCode.None && false == Input.GetKey(inputs[idx].binds[i].keyMod)) continue;
					if (inputs[idx].binds[i].key1 != KeyCode.None)
					{
						if (Input.GetKeyUp(inputs[idx].binds[i].key1)) return true;
					}
					// do not support detection of axis as button in this case
					//else if (MouseAxisAsButton_Held(inputs[idx].binds[i].mouseAxis, inputs[idx].binds[i].mouseAxisSide == InputBind.AxisSide.Positive)) return true;
				}

				else if (inputs[idx].binds[i].device == InputBind.Device.Gamepad)
				{
					if (inputs[idx].binds[i].keyMod != KeyCode.None && false == Input.GetKey(inputs[idx].binds[i].keyMod)) continue;
					if (inputs[idx].binds[i].gamepadAxisMod != InputBind.GamepadAxis.None && false == GamepadAxisAsButton_Held(inputs[idx].binds[i].gamepadAxisMod, inputs[idx].binds[i].gamepadAxisModSide == InputBind.AxisSide.Positive)) continue;
					if (inputs[idx].binds[i].key1 != KeyCode.None)
					{
						if (Input.GetKeyUp(inputs[idx].binds[i].key1)) return true;
					}
					// do not support detection of axis as button in this case
					//if (GamepadAxisAsButton_Held(inputs[idx].binds[i].gamepadAxis, inputs[idx].binds[i].gamepadAxisSide == InputBind.AxisSide.Positive)) return true;
				}
			}

			return false;
		}

		/// <summary> Returns the value of the virtual axis. </summary>
		public static float GetAxis(int idx)
		{
			if (idx < 0) return 0.0f;
			if (!inputs[idx].active) return 0.0f;
			if (inputs[idx].type != InputDefinition.InputType.Axis) return 0.0f;

			try
			{
				try
				{

					for (int i = 0; i < inputs[idx].binds.Length; i++)
					{
						if (inputs[idx].binds[i].device == InputBind.Device.KeyMouse)
						{
							// skip if uses mouse bind and mouse input was captured by something else
							if (MouseInputHandled)
							{
								if (inputs[idx].binds[i].key1 == KeyCode.None && inputs[idx].binds[i].mouseAxis != InputBind.MouseAxis.None) continue;
								if (IsMouseButton(inputs[idx].binds[i].key1) || IsMouseButton(inputs[idx].binds[i].keyMod)) continue;
							}

							if (inputs[idx].binds[i].keyMod != KeyCode.None && false == Input.GetKey(inputs[idx].binds[i].keyMod)) continue;
							if (inputs[idx].binds[i].key1 != KeyCode.None || inputs[idx].binds[i].key2 != KeyCode.None)
							{
								if (Input.GetKey(inputs[idx].binds[i].key1)) return inputs[idx].binds[i].keyMouseInvert ? -1.0f : +1.0f;
								if (Input.GetKey(inputs[idx].binds[i].key2)) return inputs[idx].binds[i].keyMouseInvert ? +1.0f : -1.0f;
							}
							else if (inputs[idx].binds[i].mouseAxis != InputBind.MouseAxis.None)
							{
								float f = Input.GetAxis(MouseAxisString[(int)inputs[idx].binds[i].mouseAxis]);
								if (f != 0.0f) return (inputs[idx].binds[i].keyMouseInvert ? (f * -1f) : (f));
							}
						}

						else if (inputs[idx].binds[i].device == InputBind.Device.Gamepad)
						{
							if (inputs[idx].binds[i].gamepadAxis != InputBind.GamepadAxis.None)
							{
								//int axisIdx = (((int)inputs[idx].binds[i].gamepad - 1) * 4) + (int)inputs[idx].binds[i].gamepadAxis;
								float f = Input.GetAxis(GamepadAxisString[(int)inputs[idx].binds[i].gamepadAxis]);
								if (f != 0.0f) return (inputs[idx].binds[i].gamepadInvert ? (f * -1f) : (f));
							}
						}
					}

				}
				catch (UnityException) { ShowConfigError(); }
			}
			catch (System.IndexOutOfRangeException) { ShowConfigError(); }
			return 0.0f;
		}

		/// <summary> Returns the axis for input idx1. If it is 0 then the axis for input idx2 will be returned. </summary>
		public static float GetAxis(int idx1, int idx2)
		{
			float f = GetAxis(idx1);
			if (f != 0.0f) return f;
			return GetAxis(idx2);
		}

		#endregion
		// ============================================================================================================
		#region helpers

		private static bool IsMouseButton(KeyCode k)
		{
			return (k >= KeyCode.Mouse0 && k <= KeyCode.Mouse6);
		}

		private static void ShowConfigError()
		{
			if (!hasShownInputConfigError)
			{
				Debug.LogError("The Unity Input Manager configuration seems to be invalid. Go to plyGame Main Editor > Input Definitions and press the 'Setup Input Manager' button. Have a look at the plyGame documentation to learn more.");
				hasShownInputConfigError = true;
			}
		}

		private static bool MouseAxisAsButton_Held(InputBind.MouseAxis axis, bool positive)
		{
			if (axis == InputBind.MouseAxis.None) return false;
			try
			{
				try
				{
					float f = Input.GetAxis(MouseAxisString[(int)axis]);
					if ((positive && f >= mouseAxisButtonDetect) || (!positive && f <= -mouseAxisButtonDetect)) return true;
				}
				catch (UnityException) { ShowConfigError(); }
			}
			catch (System.IndexOutOfRangeException) { ShowConfigError(); }
			return false;
		}

		private static bool GamepadAxisAsButton_Held(InputBind.GamepadAxis axis, bool positive)
		{
			if (axis == InputBind.GamepadAxis.None) return false;
			try
			{
				try
				{
					float f = Input.GetAxis(GamepadAxisString[(int)axis]);
					if ((positive && f >= gamepadAxisButtonDetect) || (!positive && f <= -gamepadAxisButtonDetect)) return true;
				}
				catch (UnityException) { ShowConfigError(); }
			}
			catch (System.IndexOutOfRangeException) { ShowConfigError(); }
			return false;
		}

		#endregion
		// ============================================================================================================
	}
}