﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> Base class for LoadSave Providers. The provider will be asked by plyGame to save or
	///  load keys with data associated to them. The provider will be instantiated under the Game
	///  Global GameObject parent.
	///  
	///  For a provider to be shown as option in plyGame you need to also add an editor script for it.
	///  See LoadSaveProviderEdBase for more information on this. </summary>
	[AddComponentMenu("")]
	public class LoadSaveProviderBase : MonoBehaviour
	{
		/// <summary> The provider's GameObject is set inactive at runtime, in Awake() as it does not need
		///  to be active for the function calls to work, no Update(), etc needed. You can replace this
		///  function with new protected void Awake() if you need a different behaviour. </summary>
		protected void Awake()
		{
			gameObject.SetActive(false);
		}

		/// <summary> This is called at the start of the game by the Game Global, just after the LoadSave
		///  Provider object was created. </summary>
		public virtual void Load() { }

		/// <summary> Called when it is a good time to write all stored keys to disc. Normally when the
		///  user selects to save the game. Will also be called if the game application quits in a 
		///  normal way. </summary>
		public virtual void Save() { }

		/// <summary> Is the key present? </summary>
		public virtual bool HasKey(string key) { return false; }

		/// <summary> Deletes the key and its value. </summary>
		public virtual void DeleteKey(string key) { }

		/// <summary> Deletes all keys and values. </summary>
		public virtual void DeleteAll() { }

		/// <summary> Sets a key with string value. </summary>
		public virtual void SetString(string key, string value)
		{
		}

		/// <summary> Gets a string from stored key or return the defaultVal if key not set. </summary>
		public virtual string GetString(string key, string defaultVal)
		{
			return defaultVal;
		}

		// ============================================================================================================

		/// <summary> Set a key with int value. </summary>
		public void SetInt(string key, int value)
		{
			SetString(key, value.ToString());
		}

		/// <summary> Sets a key with float value. </summary>
		public void SetFloat(string key, float value)
		{
			SetString(key, value.ToString());
		}

		/// <summary> Sets a key with bool value. </summary>
		public void SetBool(string key, bool value)
		{
			SetString(key, (value == true ? "1" : "0"));
		}

		/// <summary> Sets a key with a vector2 value. </summary>
		public void SetVector2(string key, Vector2 value)
		{
			SetString(key, string.Format("{0:N3}|{1:N3}", value.x, value.y));
		}

		/// <summary> Sets a key with a vector3 value. </summary>
		public void SetVector3(string key, Vector3 value)
		{
			SetString(key, string.Format("{0:N3}|{1:N3}|{2:N3}", value.x, value.y, value.z));
		}

		/// <summary> Sets a key with a vector4 value. </summary>
		public void SetVector4(string key, Vector4 value)
		{
			SetString(key, string.Format("{0:N3}|{1:N3}|{2:N3}|{3:N3}", value.x, value.y, value.z, value.w));
		}

		/// <summary> Sets a key with a rect value. </summary>
		public void SetRect(string key, Rect value)
		{
			SetString(key, string.Format("{0:N3}|{1:N3}|{2:N3}|{3:N3}", value.x, value.y, value.width, value.height));
		}

		// ============================================================================================================

		/// <summary> Gets an int from stored key or return the defaultVal if key not set </summary>
		public int GetInt(string key, int defaultVal)
		{
			string s = GetString(key, null);
			if (string.IsNullOrEmpty(s)) return defaultVal;
			int res = defaultVal;
			if (int.TryParse(s, out res)) return res;
			return defaultVal;
		}

		/// <summary> Gets a float from stored key or return the defaultVal if key not set. </summary>
		public float GetFloat(string key, float defaultVal)
		{
			string s = GetString(key, null);
			if (string.IsNullOrEmpty(s)) return defaultVal;
			float res = defaultVal;
			if (float.TryParse(s, out res)) return res;
			return defaultVal;
		}

		/// <summary> Gets a bool from stored key or return the defaultVal if key not set. </summary>
		public bool GetBool(string key, bool defaultVal)
		{
			return (GetString(key, (defaultVal ? "1" : "0")) == "1");
		}

		/// <summary> Gets vector2 from stored key or return the defaultVal if key not set. </summary>
		public Vector2 GetVector2(string key, Vector2 defaultVal)
		{
			string s = GetString(key, null);
			if (!string.IsNullOrEmpty(s))
			{
				Vector2 v = Vector2.zero;
				string[] vs = s.Split('|');
				if (vs.Length >= 2)
				{
					if (float.TryParse(vs[0], out v.x))
					{
						if (float.TryParse(vs[1], out v.y))
						{
							return v;
						}
					}
				}
			}
			return defaultVal;
		}

		/// <summary> Gets vector3 from stored key or return the defaultVal if key not set. </summary>
		public Vector3 GetVector3(string key, Vector3 defaultVal)
		{
			string s = GetString(key, null);
			if (!string.IsNullOrEmpty(s))
			{
				Vector3 v = Vector3.zero;
				string[] vs = s.Split('|');
				if (vs.Length >= 3)
				{
					if (float.TryParse(vs[0], out v.x))
					{
						if (float.TryParse(vs[1], out v.y))
						{
							if (float.TryParse(vs[2], out v.z))
							{
								return v;
							}
						}
					}
				}
			}
			return defaultVal;
		}

		/// <summary> Gets vector4 from stored key or return the defaultVal if key not set. </summary>
		public Vector4 GetVector4(string key, Vector4 defaultVal)
		{
			string s = GetString(key, null);
			if (!string.IsNullOrEmpty(s))
			{
				Vector4 v = Vector4.zero;
				string[] vs = s.Split('|');
				if (vs.Length >= 4)
				{
					if (float.TryParse(vs[0], out v.x))
					{
						if (float.TryParse(vs[1], out v.y))
						{
							if (float.TryParse(vs[2], out v.z))
							{
								if (float.TryParse(vs[3], out v.w))
								{
									return v;
								}
							}
						}
					}
				}
			}
			return defaultVal;
		}

		/// <summary> Gets rect from stored key or return the defaultVal if key not set.  </summary>
		public Rect GetRect(string key, Rect defaultVal)
		{
			string s = GetString(key, null);
			if (!string.IsNullOrEmpty(s))
			{
				float x = 0f, y = 0f, w = 0f, h = 0f;
				string[] vs = s.Split('|');
				if (vs.Length >= 4)
				{
					if (float.TryParse(vs[0], out x))
					{
						if (float.TryParse(vs[1], out y))
						{
							if (float.TryParse(vs[2], out w))
							{
								if (float.TryParse(vs[3], out h))
								{
									return new Rect(x, y, w, h);
								}
							}
						}
					}
				}
			}
			return defaultVal;
		}

		// ============================================================================================================
	}
}