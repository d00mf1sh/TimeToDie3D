﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> This component is added to any GameObject that should be saved or restored via the LoadSave System. </summary>
	[AddComponentMenu("plyGame/Misc/Persistable Object")]
	public class PersistableObject : MonoBehaviour
	{
		//[HideInInspector] 
		public UniqueID id = new UniqueID();

		// these are data related to components or data which can't be handled in the components
		public bool objectStartsActive = true;
		public bool persistBloxLocalVars = true;
		public bool persistPosition = true;
		public bool persistRotation = false;
		public bool persistScale = false;
		public bool persistActiveState = false;
		public bool persistDestroyedState = true;

		public bool useOffset = false;
		public Vector3 positionOffset = new Vector3(0f, 0.1f, 0f);

		// ============================================================================================================

		private string customKey = null;
		private bool skipActiveState = false; // needed to prevent ActiveState being saved during the Destroy() save call
		private EventHandler_LoadSaveSystem handler;

		// ============================================================================================================

		protected void Reset()
		{
			id = UniqueID.Create(id);
		}

		protected IEnumerator Start()
		{
			handler = GetComponent<EventHandler_LoadSaveSystem>();

			// wait for all components to finish before trying to restore state on them
			yield return null;
			Load();
		}

		protected void OnDestroy()
		{
			// do not bother if game is quitting
			if (false == GameGlobal.HasInstance) return;

			// check if scene change or not. if not then this object being destroyed might need to be persisted
			if (false == Application.isLoadingLevel)
			{
				if (persistDestroyedState)
				{
					GameGlobal.SetBoolKey((customKey == null ? id.ToString() : customKey) + ".destroyed", true);
					DeleteSaveData();
				}
			}

			// else, this is a scene change - save the data to temp store before it is lost
			// do not bother to save if this is a proper session restore (Load was called)
			// I need to do this check cause Destroy is called after LoadLevel was called
			// GameGlobal does do checks in Get/Set to prevent problems but no need to
			// run this object's save unnecessarily
			else if (false == GameGlobal.Instance.isSessionRestore)
			{
				skipActiveState = true;
				Save(null, null);
				skipActiveState = false;
			}

			GameGlobal.RemoveLoadSaveListener(Save, null, null, null);
		}

		public void Save(object sender, object[] args)
		{
			// call components to save their states
			// i call these before going on with rest of persistObject save
			// so that they can change the persistsObject options if needed
			Component[] c = gameObject.GetComponents<Component>();
			for (int i = 0; i < c.Length; i++)
			{
				IPersistable p = c[i] as IPersistable;
				if (p != null) p.Save((customKey == null ? id.ToString() : customKey));
			}

			if (persistPosition) GameGlobal.SetVector3Key((customKey == null ? id.ToString() : customKey) + ".pos", transform.position);
			if (persistRotation) GameGlobal.SetVector3Key((customKey == null ? id.ToString() : customKey) + ".rot", transform.rotation.eulerAngles);
			if (persistScale) GameGlobal.SetVector3Key((customKey == null ? id.ToString() : customKey) + ".scale", transform.localScale);
			if (persistActiveState && !skipActiveState) GameGlobal.SetBoolKey((customKey == null ? id.ToString() : customKey) + ".active", gameObject.activeSelf);

			// save the bloc local vars
			if (persistBloxLocalVars) SaveBloxVars();

			if (handler != null) handler.OnAfterSave();
		}

		public void Load()
		{
			// first check if this object was saved as being destroyed
			if (persistDestroyedState)
			{
				if (GameGlobal.GetBoolKey((customKey == null ? id.ToString() : customKey) + ".destroyed", false))
				{
					gameObject.SetActive(false);
					Object.Destroy(gameObject);
					return;
				}
			}

			// register the save event listener
			GameGlobal.RegisterLoadSaveListener(Save, null, null, null);

			// call components to restore their states
			// i call these before going on with rest of persistObject restore
			// so that they can change the persistsObject options if needed
			Component[] c = gameObject.GetComponents<Component>();
			for (int i = 0; i < c.Length; i++)
			{
				IPersistable p = c[i] as IPersistable;
				if (p != null) p.Load((customKey == null ? id.ToString() : customKey));
			}

			// check if object should be active or not
			if (persistActiveState)
			{
				if (GameGlobal.GetBoolKey((customKey == null ? id.ToString() : customKey) + ".active", objectStartsActive))
				{
					if (false == gameObject.activeSelf) gameObject.SetActive(true);
				}
				else
				{
					if (true == gameObject.activeSelf) gameObject.SetActive(false);
				}
			}

			// restore saved data
			if (persistPosition)
			{
				transform.position = GameGlobal.GetVector3Key((customKey == null ? id.ToString() : customKey) + ".pos", transform.position);
				if (useOffset) transform.position += positionOffset;
			}

			if (persistRotation) transform.rotation = Quaternion.Euler(GameGlobal.GetVector3Key((customKey == null ? id.ToString() : customKey) + ".rot", transform.rotation.eulerAngles));
			if (persistScale) transform.localScale = GameGlobal.GetVector3Key((customKey == null ? id.ToString() : customKey) + ".scale", transform.localScale);

			// restore local variables
			if (persistBloxLocalVars) LoadBloxVars();

			if (handler != null) handler.OnAfterLoad();
		}

		public void DeleteSaveData()
		{
			// delete common data
			if (persistPosition) GameGlobal.DeleteKey((customKey == null ? id.ToString() : customKey) + ".pos");
			if (persistRotation) GameGlobal.DeleteKey((customKey == null ? id.ToString() : customKey) + ".rot");
			if (persistScale) GameGlobal.DeleteKey((customKey == null ? id.ToString() : customKey) + ".scale");
			if (persistActiveState) GameGlobal.DeleteKey((customKey == null ? id.ToString() : customKey) + ".active");

			// delete local variables
			DeleteSavedBloxVars();

			// call components to delete their data
			Component[] c = gameObject.GetComponents<Component>();
			for (int i = 0; i < c.Length; i++)
			{
				IPersistable p = c[i] as IPersistable;
				if (p != null) p.DeleteSaveData((customKey == null ? id.ToString() : customKey));
			}
		}

		// ============================================================================================================

		/// <summary>
		/// Set this to make the object use this key rather than the ID it generated.
		/// Set to null or empty string to stop using custom key.
		/// 
		/// This is useful when you have something specific, like a player, to save
		/// data for. Player Manager for example uses this to set the player object's
		/// save key to "player" by default.
		/// </summary>
		public void UseCustomKey(string key)
		{
			//Debug.Log("UseCustomKey: " + key);
			if (string.IsNullOrEmpty(key)) customKey = null;
			else customKey = key;
		}

		// ============================================================================================================

		private void SaveBloxVars()
		{
			plyBlox[] blox = GetComponents<plyBlox>();
			if (blox.Length == 0) return;
			for (int i = 0; i < blox.Length; i++)
			{
				SaveBloxLovalVars((customKey == null ? id.ToString() : customKey), blox[i]);
			}
		}

		private void LoadBloxVars()
		{
			plyBlox[] blox = GetComponents<plyBlox>();
			if (blox.Length == 0) return;
			for (int i = 0; i < blox.Length; i++)
			{
				LoadBloxLovalVars((customKey == null ? id.ToString() : customKey), blox[i]);
			}
		}

		private void DeleteSavedBloxVars()
		{
			plyBlox[] blox = GetComponents<plyBlox>();
			if (blox.Length == 0) return;
			for (int i = 0; i < blox.Length; i++)
			{
				DeleteSavedBloxLovalVars((customKey == null ? id.ToString() : customKey), blox[i]);
			}
		}

		// ============================================================================================================

		public static void SaveBloxLovalVars(string key, plyBlox blox)
		{
			if (blox == null) return;
			string data = blox.EncodeLocalVariables(false);
			if (string.IsNullOrEmpty(data)) GameGlobal.DeleteKey(key + ".b" + blox.uniqueIdOnObject + ".lvar");
			else GameGlobal.SetStringKey(key + ".b" + blox.uniqueIdOnObject + ".lvar", data);
		}

		public static void LoadBloxLovalVars(string key, plyBlox blox)
		{
			if (blox == null) return;
			string data = GameGlobal.GetStringKey(key + ".b" + blox.uniqueIdOnObject + ".lvar", null);
			blox.DecodeLocalVariables(data);
		}

		public static void DeleteSavedBloxLovalVars(string key, plyBlox blox)
		{
			GameGlobal.DeleteKey(key + ".b" + blox.uniqueIdOnObject + ".lvar");
		}

		public static void DisablePersistenceOn(GameObject go)
		{
			Component[] c = go.GetComponents<Component>();
			for (int i = 0; i < c.Length; i++)
			{
				IPersistable p = c[i] as IPersistable;
				if (p != null) p.DisablePersistence();
			}

			PersistableObject po = go.GetComponent<PersistableObject>();
			if (po != null)
			{
				po.persistDestroyedState = false;
				Object.Destroy(po);
			}
		}

		// ============================================================================================================
	}
}