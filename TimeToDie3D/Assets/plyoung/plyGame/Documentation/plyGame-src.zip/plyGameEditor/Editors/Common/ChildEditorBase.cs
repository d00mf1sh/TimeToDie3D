﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

namespace plyGameEditor
{
	/// <summary> Base class for child editor windows used in the plyGame editor windows like the Main
	///  Editor widow. Also see, ChildEditorAttribute </summary>
	public class ChildEditorBase
	{
		public EditorWindow ed; //!< A reference to the parent editor window. Useful when you want to call a repaint, ed.Repaint();

		/// <summary> Called when this editor is created. It will pass the loaded 
		/// assemblies so that reflection can be done if needed. </summary>
		public virtual void OnCreated(System.Reflection.Assembly[] asm) { }

		/// <summary> Called when this editor is focused. </summary>
		public virtual void OnFocus() { }

		/// <summary> Called when the editor should render. </summary>
		public virtual void OnGUI() { }

		// ============================================================================================================
	}
}