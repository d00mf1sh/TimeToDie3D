﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

namespace plyGameEditor
{
	/// <summary> Attribute for editors that want to appear in the Markers Editor's menu. </summary>
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
	public class EdMenuOptionAttribute : System.Attribute
	{
		public string Name;				//!< Name of editor, shown on the Menu
		public System.Type ParentEd;	//!< The editor window this belongs to

		public EdMenuOptionAttribute(string name, System.Type ParentEd)
		{
			this.Name = name;
			this.ParentEd = ParentEd;
		}

		// ============================================================================================================
	}
}