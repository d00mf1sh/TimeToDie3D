﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyGame;
using plyBloxKit;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[CustomEditor(typeof(PersistableObject))]
	public class PersistableObject_Inspector : Editor
	{
		private Object prefabLink = null;
		private UniqueID prefabUniqueId = null;

		protected void OnEnable() 
		{
			if (false == EditorUtility.IsPersistent(target))
			{
				PersistableObject fab = PrefabUtility.GetPrefabParent(target) as PersistableObject;
				if (fab != null) prefabUniqueId = fab.id;
			}

			if (UniqueIDManager.CheckID(target, ref prefabLink, ref ((PersistableObject)target).id, prefabUniqueId, true, true))
			{
				EditorUtility.SetDirty(target);
			}
		}

		public override void OnInspectorGUI()
		{
			PersistableObject obj = (PersistableObject)target;
			if (UniqueIDManager.CheckID(target, ref prefabLink, ref obj.id, prefabUniqueId, false, true)) GUI.changed = true;

			//DrawDefaultInspector();

			obj.objectStartsActive = EditorGUILayout.Toggle("Object Starts Active", obj.objectStartsActive);
			obj.persistBloxLocalVars = EditorGUILayout.Toggle("Persist Blox LocalVars", obj.persistBloxLocalVars);
			obj.persistPosition = EditorGUILayout.Toggle("Persist Position", obj.persistPosition);
			if (obj.persistPosition)
			{
				EditorGUILayout.BeginHorizontal();
				{
					EditorGUILayout.PrefixLabel("Use Offset");
					obj.useOffset = EditorGUILayout.Toggle(obj.useOffset, GUILayout.Width(25));
					if (obj.useOffset) obj.positionOffset = EditorGUILayout.Vector3Field(GUIContent.none, obj.positionOffset);
				}
				EditorGUILayout.EndHorizontal();
			}
			obj.persistRotation = EditorGUILayout.Toggle("Persist Rotation", obj.persistRotation);
			obj.persistScale = EditorGUILayout.Toggle("Persist Scale", obj.persistScale);
			obj.persistActiveState = EditorGUILayout.Toggle("Persist Active State", obj.persistActiveState);
			obj.persistDestroyedState = EditorGUILayout.Toggle("Persist Destroyed State", obj.persistDestroyedState);

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}
		
		// ============================================================================================================
	}
}
