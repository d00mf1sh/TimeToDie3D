﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEditor;
using plyGame;

namespace plyGameEditor
{
	/// <summary> Base class for LoadSave Provider's editor. All LoadSave Providers should have an
	///  Editor class defined too, even if it will not render any custom options.
	///  
	///  The provider should use the LoadSaveProviderAttribute to define the def.meta data and information
	///  needed by plyGame. </summary>
	public class LoadSaveProviderEdBase
	{
		/// <summary> Called when the options for the LoadSave provider should be drawn. This is optional
		///  and only needed if your LoadSave Provider has options/ settings to configure. </summary>
		/// <param name="ed">   The editor window onto which the GUI elements are drawn. </param>
		/// <param name="data"> The load save provider that should be updated with settings. Remember to
		/// 					call EditorUtility.SetDirty(data); to make sure changes are saved. </param>
		public virtual void OnGUI(EditorWindow ed, LoadSaveProviderBase data)
		{ 
		}

		// ============================================================================================================
	}
}