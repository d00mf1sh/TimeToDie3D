﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	public class MainEditorWindow : EditorWindow
	{
		public const int MenuWidth = 160;
		private GUIContent[] EditorLabels = new GUIContent[0];

		private int currEd = 0;
		private int prevEd = 0;

		// ============================================================================================================

		public static void Show_SystemEditorWindow()
		{
			if (EdGlobal.CheckDataExist())
			{
				EditorWindow.GetWindow<MainEditorWindow>("plyGame");
			}
		}

		protected void OnFocus()
		{
			EditorLabels = new GUIContent[EdGlobal.mainEditors.Length];
			for (int i = 0; i < EdGlobal.mainEditors.Length; i++)
			{
				if (!string.IsNullOrEmpty(EdGlobal.mainEditors[i].icon))
				{
					EditorLabels[i] = new GUIContent(" " + EdGlobal.mainEditors[i].name, plyEdGUI.LoadEditorTexture(plyEdGUI.ResPath + "plyGame/mainEd/"+ EdGlobal.mainEditors[i].icon + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png"));
				}
				else
				{
					EditorLabels[i] = new GUIContent(EdGlobal.mainEditors[i].name);
				}
			}

			if (currEd >= EdGlobal.mainEditors.Length) currEd = 0;

			if (EdGlobal.edData == null)
			{
				EdGlobal.CheckDataExist();
				return;
			}

			EdGlobal.mainEditors[currEd].editor.ed = this;
			EdGlobal.mainEditors[currEd].editor.OnFocus();
		}

		protected void OnGUI()
		{
			if (EdGlobal.edData == null)
			{
				Close();
				GUIUtility.ExitGUI();
				return;
			}

			plyEdGUI.UseSkin();

			currEd = GUILayout.Toolbar(currEd, EditorLabels, plyEdGUI.MainToolbarStyle);
			plyEdGUI.DrawHorizontalLine(2, 0, plyEdGUI.MainToolbarDividerColor, plyEdGUI.FlatWhiteStyle, 0, 2);

			if (prevEd != currEd)
			{
				EdGlobal.mainEditors[currEd].editor.ed = this;
				EdGlobal.mainEditors[currEd].editor.OnFocus();
				GUI.FocusControl("");
				prevEd = currEd;
			}

			EdGlobal.mainEditors[currEd].editor.ed = this;
			EdGlobal.mainEditors[currEd].editor.OnGUI();
		}

		// ============================================================================================================
	}
}