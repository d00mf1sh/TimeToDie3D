﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;

namespace plyGameEditor
{
	public class InputSelectWiz : EditorWindow
	{
		public InputBind bind;
		
		private GeneralCallback callback;
		private object[] args;
		private InputDefinition.InputType inputType;
		private string inputName;

		private bool accepted = false;
		private bool lostFocus = false;

		private string[] keyMouse_Keys;
		private string[] keyMouse_Axis;
		private string[] gamepad_Keys;
		private string[] gamepad_Axis;

		private int selectkeyMouse_Keys = 0;
		private int selectKeyMouse_Axis = 0;
		private int selectGamepad = 0;

		private int sel1 = -1, prev1 = -1;
		private int sel2 = -1, prev2 = -1;
		private bool rightButtonIsAxis = false;

		private Vector2 scroll = Vector2.zero;
		private GUIContent GC_ACCEPT;
		private GUIContent GC_CANCEL;
		private GUIContent GC_BACK;
		private GUIContent GC_Plus;
		private GUIContent GC_UpDown;
		private GUIContent GC_LeftRight;
		private GUIContent GC_Pos;
		private GUIContent GC_Neg;

		private GUIStyle ST_LabelFA;
		private GUIStyle ST_KeyButton;
		private GUIStyle ST_KeyButtonRight;
		private GUIStyle ST_KeyButtonUpDown;
		private GUIStyle ST_KeyButtonAxisSideMid;
		private GUIStyle ST_KeyButtonAxisSideLeft;

		private Texture2D TX_Gamepad;

		public static void Show_Wiz(InputBind currBind, InputDefinition.InputType inputType, string inputName, GeneralCallback callback, object[] args)
		{
			InputSelectWiz wiz = EditorWindow.GetWindow<InputSelectWiz>(true, "Input Selection Wizard", true);

			wiz.callback = callback;
			wiz.args = args;
			wiz.bind = currBind.Copy();
			wiz.inputType = inputType;
			wiz.inputName = inputName;

			wiz.Init();
			wiz.minSize = new Vector2(500, 500);
			wiz.ShowUtility();
		}

		private void Init()
		{
			List<string> strings = new List<string>();
			for (int i = (int)KeyCode.None; i < (int)KeyCode.JoystickButton0; i++)
			{
				string s = System.Enum.GetName(typeof(KeyCode), i);
				if (!string.IsNullOrEmpty(s)) strings.Add(s);
			}			
			keyMouse_Keys = strings.ToArray();

			strings = new List<string>();
			for (int i = (int)KeyCode.JoystickButton0; i <= (int)KeyCode.JoystickButton19; i++)
			{
				string s = System.Enum.GetName(typeof(KeyCode), i);
				if (!string.IsNullOrEmpty(s)) strings.Add(s);
			}
			gamepad_Keys = strings.ToArray();

			keyMouse_Axis = System.Enum.GetNames(typeof(InputBind.MouseAxis));
			gamepad_Axis = System.Enum.GetNames(typeof(InputBind.GamepadAxis));


			if (inputType == InputDefinition.InputType.Button)
			{
				if (bind.device == InputBind.Device.KeyMouse)
				{
					if (bind.key1 == KeyCode.None && bind.mouseAxis != InputBind.MouseAxis.None) rightButtonIsAxis = true;
				}
			}
			else if (inputType == InputDefinition.InputType.Axis)
			{
				if (bind.device == InputBind.Device.KeyMouse)
				{
					if (bind.key1 == KeyCode.None && bind.key2 == KeyCode.None) rightButtonIsAxis = true;
				}
			}

		}

		protected void OnFocus() { lostFocus = false; }
		protected void OnLostFocus() { lostFocus = true; }
		protected void Update()
		{
			if (lostFocus) this.Close();
			if (accepted && callback != null) callback(this, args);
		}

		private void SetSkin()
		{
			plyEdGUI.UseSkin();
			if (ST_LabelFA == null)
			{
				GC_ACCEPT = new GUIContent(" Accept", FA.Ico12(FA.check_circle, plyEdGUI.IconColor));
				GC_CANCEL = new GUIContent(" Cancel", FA.Ico12(FA.times_circle, plyEdGUI.IconColor));
				GC_BACK = new GUIContent(" Back", FA.Ico12(FA.chevron_circle_left, plyEdGUI.IconColor));
				GC_Plus = new GUIContent(FA.plus.ToString());
				GC_UpDown = new GUIContent(FA.arrows_v.ToString(), "Key/ Axis");
				GC_LeftRight = new GUIContent(FA.arrows_h.ToString());
				GC_Pos = new GUIContent(FA.plus.ToString());
				GC_Neg = new GUIContent(FA.minus.ToString());

				TX_Gamepad = plyEdGUI.LoadTextureResource("plyGameEditor.edRes.InputWiz.gamepad.png", typeof(EdGlobal).Assembly);

				ST_LabelFA = new GUIStyle(GUI.skin.label)
				{
					font = FA.Font,
					fontSize = 24,
					margin = new RectOffset(10, 10, 10, 10),
					padding = new RectOffset(10, 10, 10, 10),
				};

				ST_KeyButton = new GUIStyle(GUI.skin.button)
				{
					wordWrap = false,
					fontSize = 20,
					margin = new RectOffset(10, 10, 10, 10),
					padding = new RectOffset(10, 10, 10, 10),
				};
				ST_KeyButtonRight = new GUIStyle(plyEdGUI.ButtonRightStyle)
				{
					wordWrap = false,
					fontSize = 20,
					margin = new RectOffset(0, 10, 10, 10),
					padding = new RectOffset(10, 10, 10, 10),
				};
				ST_KeyButtonUpDown = new GUIStyle(plyEdGUI.ButtonLeftStyle)
				{
					font = FA.Font,
					wordWrap = false,
					fontSize = 18,
					margin = new RectOffset(10, 0, 10, 10),
					padding = new RectOffset(5, 5, 10, 10),
				};
				ST_KeyButtonAxisSideMid = new GUIStyle(plyEdGUI.ButtonMidStyle)
				{
					font = FA.Font,
					wordWrap = false,
					fontSize = 20,
					margin = new RectOffset(0, 0, 10, 10),
					padding = new RectOffset(10, 10, 10, 10),
				};
				ST_KeyButtonAxisSideLeft = new GUIStyle(plyEdGUI.ButtonLeftStyle)
				{
					font = FA.Font,
					wordWrap = false,
					fontSize = 20,
					margin = new RectOffset(10, 0, 10, 10),
					padding = new RectOffset(10, 10, 10, 10),
				};
			}
		}

		protected void OnGUI()
		{
			SetSkin();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Type: " + inputType.ToString() + " [" +inputName+ "]");
				EditorGUILayout.Space();

				GUILayout.Label("Device: ");				
				EditorGUI.BeginChangeCheck();
				bind.device = (InputBind.Device)EditorGUILayout.EnumPopup(bind.device, GUILayout.Width(100));
				if (EditorGUI.EndChangeCheck())
				{
					bind.Reset();
					selectkeyMouse_Keys = 0;
					selectKeyMouse_Axis = 0;
					selectGamepad = 0;
				}
				GUILayout.FlexibleSpace();

				if (selectkeyMouse_Keys == 0 && selectKeyMouse_Axis == 0 && selectGamepad == 0)
				{
					if (GUILayout.Button(GC_ACCEPT, GUILayout.Width(120))) accepted = true;
					if (GUILayout.Button(GC_CANCEL, GUILayout.Width(120))) lostFocus = true;
				}
				else
				{
					if (GUILayout.Button(GC_BACK, GUILayout.Width(120)))
					{
						selectkeyMouse_Keys = 0;
						selectKeyMouse_Axis = 0;
						selectGamepad = 0;
					}
				}
				EditorGUILayout.Space();
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.HLine(10);

			scroll = EditorGUILayout.BeginScrollView(scroll);
			{
				if (inputType == InputDefinition.InputType.Button)
				{
					if (bind.device == InputBind.Device.KeyMouse) Button_KeyMouse();
					else if (bind.device == InputBind.Device.Gamepad) Button_Gamepad();
				}

				else if (inputType == InputDefinition.InputType.Axis)
				{
					if (bind.device == InputBind.Device.KeyMouse) Axis_KeyMouse();
					else if (bind.device == InputBind.Device.Gamepad) Axis_Gamepad();
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndScrollView();
			EditorGUILayout.Space();
		}

		private void Button_KeyMouse()
		{
			if (selectkeyMouse_Keys != 0) SelectKeyMouseKey();
			else if (selectKeyMouse_Axis != 0) SelectKeyMouseAxis();
			else
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Space(20);
					if (GUILayout.Button(bind.keyMod == KeyCode.None ? " " : bind.keyMod.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
					{
						selectkeyMouse_Keys = 3;
						sel1 = prev1 = GetIdx(keyMouse_Keys, bind.keyMod.ToString());
					}

					GUILayout.Label(GC_Plus, ST_LabelFA);

					if (GUILayout.Button(GC_UpDown, ST_KeyButtonUpDown, GUILayout.Height(50)))
					{
						rightButtonIsAxis = !rightButtonIsAxis;
						bind.key1 = KeyCode.None;
						bind.key2 = KeyCode.None;
						bind.mouseAxis = InputBind.MouseAxis.None;
					}

					if (rightButtonIsAxis)
					{
						if (GUILayout.Button(bind.mouseAxisSide == InputBind.AxisSide.Negative ? GC_Neg : GC_Pos, ST_KeyButtonAxisSideMid, GUILayout.Height(50))) bind.mouseAxisSide = bind.mouseAxisSide == InputBind.AxisSide.Negative ? InputBind.AxisSide.Positive : InputBind.AxisSide.Negative;
						if (GUILayout.Button(bind.mouseAxis.ToString(), ST_KeyButtonRight, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectKeyMouse_Axis = 1;
							sel1 = prev1 = GetIdx(keyMouse_Axis, bind.mouseAxis.ToString());
						}
					}
					else
					{
						if (GUILayout.Button(bind.key1.ToString(), ST_KeyButtonRight, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectkeyMouse_Keys = 1;
							sel1 = prev1 = GetIdx(keyMouse_Keys, bind.key1.ToString());
						}
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
			}
		}

		private void Axis_KeyMouse()
		{
			if (selectkeyMouse_Keys != 0) SelectKeyMouseKey();
			else if (selectKeyMouse_Axis != 0) SelectKeyMouseAxis();
			else
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Space(20);
					if (GUILayout.Button(bind.keyMod == KeyCode.None ? " " : bind.keyMod.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
					{
						selectkeyMouse_Keys = 3;
						sel1 = prev1 = GetIdx(keyMouse_Keys, bind.keyMod.ToString());
					}

					GUILayout.Label(GC_Plus, ST_LabelFA);

					EditorGUILayout.BeginVertical();
					{
						EditorGUILayout.BeginHorizontal();
						{
							if (GUILayout.Button(GC_UpDown, ST_KeyButtonUpDown, GUILayout.Height(50)))
							{
								rightButtonIsAxis = !rightButtonIsAxis;
								bind.key1 = KeyCode.None;
								bind.key2 = KeyCode.None;
								bind.mouseAxis = InputBind.MouseAxis.None;
							}

							if (rightButtonIsAxis)
							{
								if (GUILayout.Button(bind.mouseAxis.ToString(), ST_KeyButtonRight, GUILayout.MinWidth(60), GUILayout.Height(50)))
								{
									selectKeyMouse_Axis = 1;
									sel1 = prev1 = GetIdx(keyMouse_Axis, bind.mouseAxis.ToString());
								}
							}
							else
							{
								if (GUILayout.Button(bind.key1.ToString(), ST_KeyButtonRight, GUILayout.MinWidth(60), GUILayout.Height(50)))
								{
									selectkeyMouse_Keys = 1;
									sel1 = prev1 = GetIdx(keyMouse_Keys, bind.key1.ToString());
								}

								GUILayout.Label(GC_LeftRight, ST_LabelFA);

								if (GUILayout.Button(bind.key2.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
								{
									selectkeyMouse_Keys = 2;
									sel1 = prev1 = GetIdx(keyMouse_Keys, bind.key2.ToString());
								}
							}
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						{
							GUILayout.Space(20);
							bind.keyMouseInvert = GUILayout.Toggle(bind.keyMouseInvert, " Inverted");
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
					}
					EditorGUILayout.EndVertical();

					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
			}
		}

		private void Button_Gamepad()
		{
			if (selectGamepad != 0) SelectGamepad();
			else
			{
				EditorGUILayout.BeginHorizontal();
				GUILayout.Space(20);
				{

					if (bind.gamepadAxisMod != InputBind.GamepadAxis.None)
					{
						if (GUILayout.Button(bind.gamepadAxisModSide == InputBind.AxisSide.Negative ? GC_Neg : GC_Pos, ST_KeyButtonAxisSideLeft, GUILayout.Height(50))) bind.gamepadAxisModSide = bind.gamepadAxisModSide == InputBind.AxisSide.Negative ? InputBind.AxisSide.Positive : InputBind.AxisSide.Negative;
						if (GUILayout.Button(bind.gamepadAxisMod.ToString(), ST_KeyButtonRight, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectGamepad = 1;
							sel1 = prev1 = -1;
							sel2 = prev2 = GetIdx(gamepad_Axis, bind.gamepadAxisMod.ToString());
						}
					}
					else
					{
						if (GUILayout.Button(bind.keyMod == KeyCode.None ? " " : bind.keyMod.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectGamepad = 1;
							sel1 = prev1 = GetIdx(gamepad_Keys, bind.keyMod.ToString());
							sel2 = prev2 = -1;
						}
					}

					GUILayout.Label(GC_Plus, ST_LabelFA);

					if (bind.gamepadAxis != InputBind.GamepadAxis.None)
					{
						if (GUILayout.Button(bind.gamepadAxisSide == InputBind.AxisSide.Negative ? GC_Neg : GC_Pos, ST_KeyButtonAxisSideLeft, GUILayout.Height(50))) bind.gamepadAxisSide = bind.gamepadAxisSide == InputBind.AxisSide.Negative ? InputBind.AxisSide.Positive : InputBind.AxisSide.Negative;
						if (GUILayout.Button(bind.gamepadAxis.ToString(), ST_KeyButtonRight, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectGamepad = 2;
							sel1 = prev1 = -1;
							sel2 = prev2 = GetIdx(gamepad_Axis, bind.gamepadAxis.ToString());
						}
					}
					else
					{
						if (GUILayout.Button(bind.key1.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectGamepad = 2;
							sel1 = prev1 = GetIdx(gamepad_Keys, bind.key1.ToString());
							sel2 = prev2 = -1;
						}
					}

				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
			}
		}

		private void Axis_Gamepad()
		{
			if (selectGamepad != 0) SelectGamepad();
			else
			{
				EditorGUILayout.BeginHorizontal();
				GUILayout.Space(20);
				{
					if (bind.gamepadAxisMod != InputBind.GamepadAxis.None)
					{
						if (GUILayout.Button(bind.gamepadAxisModSide == InputBind.AxisSide.Negative ? GC_Neg : GC_Pos, ST_KeyButtonAxisSideLeft, GUILayout.Height(50))) bind.gamepadAxisModSide = bind.gamepadAxisModSide == InputBind.AxisSide.Negative ? InputBind.AxisSide.Positive : InputBind.AxisSide.Negative;
						if (GUILayout.Button(bind.gamepadAxisMod.ToString(), ST_KeyButtonRight, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectGamepad = 1;
							sel1 = prev1 = -1;
							sel2 = prev2 = GetIdx(gamepad_Axis, bind.gamepadAxisMod.ToString());
						}
					}
					else
					{
						if (GUILayout.Button(bind.keyMod == KeyCode.None ? " " : bind.keyMod.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
						{
							selectGamepad = 1;
							sel1 = prev1 = GetIdx(gamepad_Keys, bind.keyMod.ToString());
							sel2 = prev2 = -1;
						}
					}

					GUILayout.Label(GC_Plus, ST_LabelFA);

					EditorGUILayout.BeginVertical();
					{
						EditorGUILayout.BeginHorizontal();
						{
							if (bind.key1 != KeyCode.None || bind.key2 != KeyCode.None)
							{
								if (GUILayout.Button(bind.key1.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
								{
									selectGamepad = 2;
									sel1 = prev1 = GetIdx(gamepad_Keys, bind.key1.ToString());
									sel2 = prev2 = -1;
								}

								GUILayout.Label(GC_LeftRight, ST_LabelFA);

								if (GUILayout.Button(bind.key2.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
								{
									selectGamepad = 3;
									sel1 = prev1 = GetIdx(gamepad_Keys, bind.key2.ToString());
									sel2 = prev2 = -1;
								}
							}
							else
							{
								if (GUILayout.Button(bind.gamepadAxis.ToString(), ST_KeyButton, GUILayout.MinWidth(60), GUILayout.Height(50)))
								{
									selectGamepad = 2;
									sel1 = prev1 = -1;
									sel2 = prev2 = GetIdx(gamepad_Axis, bind.gamepadAxis.ToString());
								}
							}
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						{
							EditorGUILayout.Space();
							bind.gamepadInvert = GUILayout.Toggle(bind.gamepadInvert, " Inverted");
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
					}
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
			}
		}

		// ============================================================================================================

		private int GetIdx(string[] vals, string selected)
		{
			for (int i = 0; i < vals.Length; i++)
			{
				if (vals[i].Equals(selected)) return i;
			}
			return -1;
		}

		private void SelectKeyMouseKey()
		{
			sel1 = GUILayout.SelectionGrid(sel1, keyMouse_Keys, 6);
			if (sel1 != prev1)
			{
				prev1 = sel1;
				KeyCode kc = (KeyCode)System.Enum.Parse(typeof(KeyCode), keyMouse_Keys[sel1]);
				if (selectkeyMouse_Keys == 1) { bind.key1 = kc; bind.mouseAxis = InputBind.MouseAxis.None; }
				else if (selectkeyMouse_Keys == 2) { bind.key2 = kc; bind.mouseAxis = InputBind.MouseAxis.None; }
				else if (selectkeyMouse_Keys == 3) bind.keyMod = kc;				
				selectkeyMouse_Keys = 0;
				GUI.changed = true;
			}
		}

		private void SelectKeyMouseAxis()
		{
			sel1 = GUILayout.SelectionGrid(sel1, keyMouse_Axis, 6);
			if (sel1 != prev1)
			{
				prev1 = sel1;
				bind.mouseAxis = (InputBind.MouseAxis)System.Enum.Parse(typeof(InputBind.MouseAxis), keyMouse_Axis[sel1]);
				bind.key1 = KeyCode.None;
				bind.key2 = KeyCode.None;
				selectKeyMouse_Axis = 0;
				GUI.changed = true;
			}
		}

		private void SelectGamepad()
		{
			sel1 = GUILayout.SelectionGrid(sel1, gamepad_Keys, 5);
			if (sel1 != prev1)
			{
				sel2 = prev2 = -1;
				prev1 = sel1;
				KeyCode kc = (KeyCode)System.Enum.Parse(typeof(KeyCode), gamepad_Keys[sel1]);

				if (selectGamepad == 1)
				{	// select mod button
					bind.keyMod = kc;
					bind.gamepadAxisMod = InputBind.GamepadAxis.None;
				}
				else if (selectGamepad == 2)
				{	// select primary button
					bind.key1 = kc;
					bind.gamepadAxis = InputBind.GamepadAxis.None;
				}
				else if (selectGamepad == 3)
				{	// select secondary button
					bind.key2 = kc;
					bind.gamepadAxis = InputBind.GamepadAxis.None;
				}

				selectGamepad = 0;
				GUI.changed = true;
			}

			sel2 = GUILayout.SelectionGrid(sel2, gamepad_Axis, 5);
			if (sel2 != prev2)
			{
				sel1 = prev1 = -1;
				prev2 = sel2;
				InputBind.GamepadAxis kc = (InputBind.GamepadAxis)System.Enum.Parse(typeof(InputBind.GamepadAxis), gamepad_Axis[sel2]);

				if (selectGamepad == 1)
				{	// select mod button
					bind.keyMod = KeyCode.None;
					bind.gamepadAxisMod = kc;
				}
				else if (selectGamepad == 2)
				{	// select primary button
					bind.key1 = KeyCode.None;
					bind.key2 = KeyCode.None;
					bind.gamepadAxis = kc;
				}
				else if (selectGamepad == 3)
				{	// only primary can be axis
					bind.key1 = KeyCode.None;
					bind.key2 = KeyCode.None;
					bind.gamepadAxis = kc;
				}

				selectGamepad = 0;
				GUI.changed = true;
			}
		}

		// ============================================================================================================
	}
}