﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	public class CustomScreens_Ed : ChildEditorBase
	{
		// ============================================================================================================
		#region vars

		private OnGUIElementsEditor blocksEd = new OnGUIElementsEditor();
		private Vector2[] scroll = { Vector2.zero, Vector2.zero };

		private CustomScreensAsset asset;
		private GUIScreen activeScreen;

		#endregion
		// ============================================================================================================
		#region sys

		public override void OnFocus()
		{
			if (asset == null)
			{
				asset = (CustomScreensAsset)EdGlobal.LoadOrCreateAsset<CustomScreensAsset>(plyEdUtil.DATA_PATH_SYSTEM + "custscr.asset", null);
				activeScreen = null;
			}
			if (activeScreen != null) blocksEd.SetElementList(activeScreen);
		}

		public override void OnGUI()
		{
			if (asset == null) return;
			EditorGUILayout.BeginHorizontal();
			// --------------------------------------------------------------------------------------------------------

			EditorGUILayout.BeginVertical();
			{

				if (plyEdGUI.ItemsList<GUIScreen>(ref activeScreen, asset.screens, false, true, true, false, OnListCallback, ref scroll[0], EdGlobal.HLP_CustomScreenEd, "Add a Screen", GUILayout.Width(ScreensEditor.SidebarWidth + 20), GUILayout.Height(ed.position.height / 4)))
				{
					blocksEd.SetElementList(activeScreen);
					ed.Repaint();
				}

				plyEdGUI.DrawHorizontalLine(2, ScreensEditor.SidebarWidth + 20, Color.white, plyEdGUI.SplitterStyle, 0, 0);

				// Show the Options (property blocks)
				scroll[1] = EditorGUILayout.BeginScrollView(scroll[1], false, true, GUIStyle.none, GUI.skin.verticalScrollbar, GUI.skin.scrollView, GUILayout.Width(ScreensEditor.SidebarWidth + 20));
				GUILayout.Space(10);
				EditorGUILayout.BeginVertical(GUILayout.Width(ScreensEditor.SidebarWidth));
				{
					if (activeScreen != null)
					{
						// Draw Blocks Editor Properties
						blocksEd.DrawProperties(ed, activeScreen, asset);
					}
				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			EditorGUILayout.EndVertical();
			plyEdGUI.DrawVerticalLine(1, 0, Color.white, plyEdGUI.SplitterStyle, 0, 0);
			
			// Draw Blocks Editor main
			if (activeScreen != null)
			{
				blocksEd.DrawMain(ed, activeScreen, asset, null);
			}
			else GUILayout.FlexibleSpace();

			// --------------------------------------------------------------------------------------------------------
			EditorGUILayout.EndHorizontal();
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(asset);
			}

			HandleEvents();
		}

		private void HandleEvents()
		{
			// watch for an undo and repaint window just incase something in it was undone
			if (Event.current.type == EventType.ValidateCommand)
			{
				if (Event.current.commandName == "UndoRedoPerformed")
				{
					blocksEd.SetElementList(activeScreen);
					ed.Repaint();
				}
			}
		}

		private GUIScreen OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:must create and add new, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed, 6:rename current

			if (act == 1)
			{
				activeScreen = new GUIScreen();
				activeScreen.name = "Screen " + (asset.screens.Count + 1);
				activeScreen.id = asset.NextScreenId;
				asset.screens.Add(activeScreen);
				EditorUtility.SetDirty(asset);
				return activeScreen;
			}
			//else if (act == 2)
			//{
			//}
			else if (act == 3)
			{
				activeScreen = null;
			}
			//else if (act == 5)
			//{
			//}
			//else if (act == 4 || act == 5)
			//{
			//}
			else if (act == 6)
			{
				plyTextInputWiz.ShowWiz("Rename Screen", "Enter a unique name", activeScreen.name, OnRenameScreen, null);
				return null;
			}

			EditorUtility.SetDirty(asset);
			return null;
		}

		private void OnRenameScreen(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;

			if (!string.IsNullOrEmpty(wiz.text) && activeScreen != null)
			{
				activeScreen.name = wiz.text;
				EditorUtility.SetDirty(asset);
			}

			wiz.Close();
			ed.Repaint();
		}

		#endregion
		// ============================================================================================================
	}
}