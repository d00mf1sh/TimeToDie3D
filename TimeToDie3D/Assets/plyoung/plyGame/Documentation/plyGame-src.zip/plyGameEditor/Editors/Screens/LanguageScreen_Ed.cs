﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommon;
using plyCommonEditor;

namespace plyGameEditor
{
	public class LanguageScreen_Ed : ChildEditorBase
	{
		// ============================================================================================================
		#region vars

		private OnGUIElementsEditor blocksEd = new OnGUIElementsEditor();
		private Vector2 scroll = Vector2.zero;
		private LangScreenAsset asset;
		private CustomScreensAsset customScrAsset;

		private OnGUIElement defaultLangBlock = null;
		private List<OnGUIElement> langBlocks = new List<OnGUIElement>();

		private int selectedCustomScreen = -1;
		private int selectedCustomScene = -1;
		private string[] customScreenLabels = new string[0];
		private string[] customSceneLabels = new string[0];

		#endregion
		// ============================================================================================================
		#region sys

		public override void OnFocus()
		{
			if (asset == null)
			{
				asset = (LangScreenAsset)EdGlobal.LoadOrCreateAsset<LangScreenAsset>(plyEdUtil.DATA_PATH_SYSTEM + "langscr.asset", "Language Screen Data");
			}

			langBlocks = new List<OnGUIElement>();
			if (LanguageEditor.LanguagesAsset != null)
			{
				for (int i = 0; i < LanguageEditor.LanguagesAsset.languages.Count; i++)
				{
					if (asset.langBlockIds.Count <= i) asset.langBlockIds.Add(-1);
					langBlocks.Add(asset.screenData.GetElement(asset.langBlockIds[i]));
				}
			}

			blocksEd.SetElementList(asset.screenData);
			defaultLangBlock = asset.screenData.GetElement(asset.defaultLangBlockId);

			selectedCustomScreen = -1;
			customScreenLabels = new string[0];
			customScrAsset = AssetDatabase.LoadAssetAtPath(plyEdUtil.DATA_PATH_SYSTEM + "custscr.asset", typeof(CustomScreensAsset)) as CustomScreensAsset;
			if (customScrAsset != null)
			{
				if (customScrAsset.screens.Count > 0)
				{
					customScreenLabels = new string[customScrAsset.screens.Count];
					for (int i = 0; i < customScrAsset.screens.Count; i++)
					{
						customScreenLabels[i] = customScrAsset.screens[i].name;
						if (customScrAsset.screens[i].id == asset.nextScreen) selectedCustomScreen = i;
					}
				}
			}

		}

		private void UpdateScenesList()
		{
			if (customSceneLabels.Length != EditorBuildSettings.scenes.Length)
			{
				customSceneLabels = new string[EditorBuildSettings.scenes.Length];
				for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
				{
					customSceneLabels[i] = EditorBuildSettings.scenes[i].path.Substring(EditorBuildSettings.scenes[i].path.LastIndexOf('/')+1);
					customSceneLabels[i] = customSceneLabels[i].Replace(".unity", "");
					if (asset.nextScene == customSceneLabels[i]) selectedCustomScene = i;
				}
			}
		}

		public override void OnGUI()
		{
			if (asset == null) return;
			EditorGUILayout.BeginHorizontal();
			// --------------------------------------------------------------------------------------------------------

			// Show the Options (property blocks)
			scroll = EditorGUILayout.BeginScrollView(scroll, false, true, GUIStyle.none, GUI.skin.verticalScrollbar, GUI.skin.scrollView, GUILayout.Width(ScreensEditor.SidebarWidth + 20));
			GUILayout.Space(10);
			EditorGUILayout.BeginVertical(GUILayout.Width(ScreensEditor.SidebarWidth));
			{
				EditorGUILayout.BeginHorizontal();
				{
					plyEdGUI.SectionHeading("Settings", false);
					GUILayout.FlexibleSpace();
					if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.FlatIconButtonStyle))
					{
						Application.OpenURL(EdGlobal.HLP_LangScreenEd);
					}
					EditorGUILayout.Space();
				}
				EditorGUILayout.EndHorizontal();
				plyEdGUI.HLine(5);

				//plyEdGUI.SectionHeading("Settings");
				//EditorGUILayout.BeginHorizontal();
				//{
				//	GUILayout.Label("Screen", GUILayout.Width(115));
				//	EditorGUI.BeginChangeCheck();
				//	selectedCustomScreen = EditorGUILayout.Popup(selectedCustomScreen, customScreenLabels);
				//	if (EditorGUI.EndChangeCheck() && customScrAsset != null)
				//	{
				//		asset.nextScreen = customScrAsset.screens[selectedCustomScreen].id;
				//		EditorUtility.SetDirty(asset);
				//	}
				//	if (GUILayout.Button("x", EditorStyles.miniButton, GUILayout.Width(20)))
				//	{
				//		selectedCustomScreen = -1;
				//		asset.nextScreen = -1;
				//	}
				//}
				//EditorGUILayout.EndHorizontal();

				//EditorGUILayout.BeginHorizontal();
				//{
				//	UpdateScenesList();
				//	GUILayout.Label("or Scene", GUILayout.Width(115));
				//	EditorGUI.BeginChangeCheck();
				//	selectedCustomScene = EditorGUILayout.Popup(selectedCustomScene, customSceneLabels);
				//	if (EditorGUI.EndChangeCheck())
				//	{
				//		asset.nextScene = customSceneLabels[selectedCustomScene];
				//		EditorUtility.SetDirty(asset);
				//	}
				//	if (GUILayout.Button("x", EditorStyles.miniButton, GUILayout.Width(20))) 
				//	{
				//		selectedCustomScene = -1;
				//		asset.nextScene = "";
				//	}
				//}
				//EditorGUILayout.EndHorizontal();

				plyEdGUI.LookLikeControls(80);
				EditorGUI.BeginChangeCheck();
				selectedCustomScreen = plyEdGUI.Popup("Screen", selectedCustomScreen, customScreenLabels);
				if (EditorGUI.EndChangeCheck())
				{
					if (customScrAsset != null && selectedCustomScreen != -1)
					{
						asset.nextScreen = customScrAsset.screens[selectedCustomScreen].id;
					}
					else
					{
						selectedCustomScreen = -1;
						asset.nextScreen = -1;
					}
					EditorUtility.SetDirty(asset);
				}

				UpdateScenesList();
				EditorGUI.BeginChangeCheck();
				selectedCustomScene = plyEdGUI.Popup("or Scene", selectedCustomScene, customSceneLabels);
				if (EditorGUI.EndChangeCheck())
				{
					if (selectedCustomScene != -1)
					{
						asset.nextScene = customSceneLabels[selectedCustomScene];
					}
					else
					{
						selectedCustomScene = -1;
						asset.nextScene = "";					
					}
					EditorUtility.SetDirty(asset);
				}

				plyEdGUI.LookLikeControls();
				GUILayout.Label(" ... to show next.");

				EditorGUILayout.Space();
				GUILayout.Label("Language Select Buttons", EditorStyles.boldLabel);

				if (GUILayout.Button("Edit Languages"))
				{
					LanguageEditor.Show_Language_Ed();
				}

				if (plyEdGUI.LabelButton("Default", defaultLangBlock == null ? "-none-" : defaultLangBlock.name, 115, 0))
				{
					plyListSelectWiz.ShowWiz("Select Button", asset.screenData.buttonEles.ConvertAll<object>((x) => { return (object)x; }), true, defaultLangBlock, OnBlockSelected, new object[] { -1 });
				}

				//EditorGUILayout.BeginHorizontal();
				//{
				//	GUILayout.Label("Default", GUILayout.Width(115));
				//	if (GUILayout.Button(defaultLangBlock == null ? "-none-" : defaultLangBlock.name))
				//	{
				//		plyListSelectWiz.ShowWiz("Select Block", asset.screenData.OnGUIElements.ConvertAll<object>((x) => { return (object)x; }), true, defaultLangBlock, OnBlockSelected, new object[] { -1 });
				//	}
				//}
				//EditorGUILayout.EndHorizontal();

				if (LanguageEditor.LanguagesAsset != null)
				{
					for (int i = 0; i < LanguageEditor.LanguagesAsset.languages.Count; i++)
					{
						if (plyEdGUI.LabelButton(LanguageEditor.LanguagesAsset.languages[i], langBlocks[i] == null ? "-none-" : langBlocks[i].name, 115, 0))
						{
							plyListSelectWiz.ShowWiz("Select Button", asset.screenData.buttonEles.ConvertAll<object>((x) => { return (object)x; }), true, langBlocks[i], OnBlockSelected, new object[] { i });
						}

						//EditorGUILayout.BeginHorizontal();
						//{
						//	GUILayout.Label(langAsset.languages[i], GUILayout.Width(115));
						//	if (GUILayout.Button(langBlocks[i] == null ? "-none-" : langBlocks[i].name))
						//	{
						//		if (asset.screenData.OnGUIElements.Count > 0)
						//		{
						//			plyListSelectWiz.ShowWiz("Select Block", asset.screenData.OnGUIElements.ConvertAll<object>((x) => { return (object)x; }), true, langBlocks[i], OnBlockSelected, new object[] { i });
						//		}
						//	}
						//}
						//EditorGUILayout.EndHorizontal();
					}
				}

				// Draw Blocks Editor Properties
				blocksEd.DrawProperties(ed, asset.screenData, asset);
			}
			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();

			plyEdGUI.DrawVerticalLine(1, 0, Color.white, plyEdGUI.SplitterStyle, 0, 0);

			// Draw Blocks Editor main
			blocksEd.DrawMain(ed, asset.screenData, asset, null);

			// --------------------------------------------------------------------------------------------------------
			EditorGUILayout.EndHorizontal();
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(asset);
			}

			HandleEvents();
		}

		private void HandleEvents()
		{
			// watch for an undo and repaint window just incase something in it was undone
			if (Event.current.type == EventType.ValidateCommand)
			{
				if (Event.current.commandName == "UndoRedoPerformed")
				{
					blocksEd.SetElementList(asset.screenData);
					ed.Repaint();
				}
			}
		}

		private void OnBlockSelected(object sender, object[] args)
		{
			plyListSelectWiz wiz = sender as plyListSelectWiz;
			int sel = (int)args[0];

			if (sel < 0)
			{
				defaultLangBlock = wiz.selected as OnGUIElement;
				if (defaultLangBlock == null) asset.defaultLangBlockId = -1;
				else asset.defaultLangBlockId = defaultLangBlock.id;
			}
			else
			{
				langBlocks[sel] = wiz.selected as OnGUIElement;
				if (langBlocks[sel] == null) asset.langBlockIds[sel] = -1;
				else asset.langBlockIds[sel] = langBlocks[sel].id;
			}

			EditorUtility.SetDirty(asset);
			wiz.Close();
			ed.Repaint();
		}

		#endregion
		// ============================================================================================================
	}
}