﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	public class LoadingScreens_Ed : ChildEditorBase
	{
		// ============================================================================================================
		#region vars

		private OnGUIElementsEditor blocksEd = new OnGUIElementsEditor();
		private Vector2[] scroll = { Vector2.zero, Vector2.zero };

		private LoadScreensAsset asset;
		private GUIScreen activeScreen;

		#endregion
		// ============================================================================================================
		#region sys

		public override void OnFocus()
		{
			if (asset == null)
			{
				asset = (LoadScreensAsset)EdGlobal.LoadOrCreateAsset<LoadScreensAsset>(plyEdUtil.DATA_PATH_SYSTEM + "loadscr.asset", null);
				activeScreen = null;
			}
			if (activeScreen != null) blocksEd.SetElementList(activeScreen);
		}

		public override void OnGUI()
		{
			if (asset == null) return;
			EditorGUILayout.BeginHorizontal();
			// --------------------------------------------------------------------------------------------------------

			EditorGUILayout.BeginVertical();
			{

				if (plyEdGUI.ItemsList<GUIScreen>(ref activeScreen, asset.screens, false, false, true, false, OnListCallback, ref scroll[0], EdGlobal.HLP_LoadScreenEd, "Add a Screen", GUILayout.Width(ScreensEditor.SidebarWidth + 20), GUILayout.Height(ed.position.height / 4)))
				{
					blocksEd.SetElementList(activeScreen);
					ed.Repaint();
				}
				plyEdGUI.DrawHorizontalLine(2, ScreensEditor.SidebarWidth + 20, Color.white, plyEdGUI.SplitterStyle, 0, 0);

				// Show the Options (property blocks)
				scroll[1] = EditorGUILayout.BeginScrollView(scroll[1], false, true, GUIStyle.none, GUI.skin.verticalScrollbar, GUI.skin.scrollView, GUILayout.Width(ScreensEditor.SidebarWidth + 20));
				GUILayout.Space(10);
				EditorGUILayout.BeginVertical(GUILayout.Width(ScreensEditor.SidebarWidth));
				{
					EditorGUIUtility.labelWidth = 120;
					asset.minLoadTime = EditorGUILayout.FloatField("Min Load Time", asset.minLoadTime);
					asset.clickToContinue = EditorGUILayout.Toggle("Click to Continue", asset.clickToContinue);
					asset.loadText = EditorGUILayout.TextField("Text", asset.loadText);
					EditorGUIUtility.labelWidth = 0;
					if (activeScreen != null)
					{
						// Draw Blocks Editor Properties
						blocksEd.DrawProperties(ed, activeScreen, asset);
					}
				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			EditorGUILayout.EndVertical();
			plyEdGUI.DrawVerticalLine(1, 0, Color.white, plyEdGUI.SplitterStyle, 0, 0);

			// Draw Blocks Editor main
			if (activeScreen != null)
			{
				blocksEd.DrawMain(ed, activeScreen, asset, null);
			}
			else GUILayout.FlexibleSpace();

			// --------------------------------------------------------------------------------------------------------
			EditorGUILayout.EndHorizontal();
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(asset);
			}

			HandleEvents();
		}

		private void HandleEvents()
		{
			// watch for an undo and repaint window just incase something in it was undone
			if (Event.current.type == EventType.ValidateCommand)
			{
				if (Event.current.commandName == "UndoRedoPerformed")
				{
					blocksEd.SetElementList(activeScreen);
					ed.Repaint();
				}
			}
		}

		private GUIScreen OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:must create and add new, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed,

			if (act == 1)
			{
				activeScreen = new GUIScreen();
				activeScreen.name = "Load Screen " + (asset.screens.Count + 1);
				activeScreen.id = asset.NextScreenId;
				asset.screens.Add(activeScreen);
				EditorUtility.SetDirty(asset);
				return activeScreen;
			}
			//else if (act == 2)
			//{
			//}
			else if (act == 3)
			{
				activeScreen = null;
			}
			//else if (act == 5)
			//{
			//}
			else if (act == 4 || act == 5)
			{
				for (int i = 0; i < asset.screens.Count; i++) asset.screens[i].name = "Load Screen " + (i + 1);
			}

			EditorUtility.SetDirty(asset);
			return null;
		}

		#endregion
		// ============================================================================================================
	}
}