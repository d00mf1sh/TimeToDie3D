﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGameEditor
{
	
	public class UniqueIdNamePair
	{
		public string name;
		public UniqueID id = UniqueID.Empty;

		public override string ToString()
		{
			return name;
		}
	}

	public class IntIdNamePair
	{
		public string name;
		public int id = -1;

		public override string ToString()
		{
			return name;
		}
	}

	public class LoadSaveEdInfo
	{
		public string name;
		public LoadSaveProviderEdBase editor;
		public System.Type providerType;
	}

	public class MainEdInfo
	{
		public int order;
		public string name;
		public string icon;
		public ChildEditorBase editor;
	}

	// ============================================================================================================
}