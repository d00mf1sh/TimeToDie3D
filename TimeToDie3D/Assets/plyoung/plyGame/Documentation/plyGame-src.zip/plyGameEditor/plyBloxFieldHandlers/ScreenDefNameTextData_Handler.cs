﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyBloxKitEditor;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(ScreenDefNameTextData))]
	public class ScreenDefNameTextData_Handler : plyBlockFieldHandler
	{

		private string[] names = new string[0];
		private CustomScreensAsset asset;

		public override object GetCopy(object obj)
		{
			ScreenDefNameTextData target = obj as ScreenDefNameTextData;
			if (target != null) return target.Copy();
			return new ScreenDefNameTextData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			ScreenDefNameTextData target = obj == null ? new ScreenDefNameTextData() : obj as ScreenDefNameTextData;
			CheckNamesArray();
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			ScreenDefNameTextData target = obj == null ? new ScreenDefNameTextData() : obj as ScreenDefNameTextData;

			EditorGUI.BeginChangeCheck();
			target.name = EditorGUILayout.TextField(target.name, plyEdGUI.TextFieldNoLRMarginStyle);
			if (EditorGUI.EndChangeCheck()) ret = true;

			int sel = EditorGUILayout.Popup(-1, names, EditorStyles.miniButtonRight, GUILayout.Width(20));
			if (sel >= 0)
			{
				target.name = names[sel];
				ret = true;
			}

			obj = target;
			return ret;
		}

		private void CheckNamesArray()
		{
			asset = (CustomScreensAsset)EdGlobal.LoadOrCreateAsset<CustomScreensAsset>(plyEdUtil.DATA_PATH_SYSTEM + "custscr.asset", null);
			if (names.Length != asset.screens.Count)
			{
				names = new string[asset.screens.Count];
				for (int i = 0; i < names.Length; i++)
				{
					names[i] = asset.screens[i].name;
				}
			}
		}

		// ============================================================================================================
	}
}