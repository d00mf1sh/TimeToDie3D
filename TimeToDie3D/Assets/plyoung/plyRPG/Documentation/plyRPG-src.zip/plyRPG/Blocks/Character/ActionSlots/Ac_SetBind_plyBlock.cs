﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Action Slot (plyRPG)", "Set InputBind", BlockType.Action, Order = 7,
		Description = "Change the input bind of the specified action slot.")]
	public class Ac_SetBind_plyBlock : plyBlock
	{
		[plyBlockField("Bind ActionSlot", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot Number - Integer", Description = "Slot number to apply to. Slots starts at number 0.")]
		public Int_Value slotVal;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a player object.")]
		public GameObject_Value target;

		[plyBlockField("to", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "Pass empty string to remove any current bind.")]
		public InputDefNameTextData button = new InputDefNameTextData(); // input definition name

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private PlayerBaseController player = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = slotVal != null;
			if (!blockIsValid) Log(LogType.Error, "The slot number field must be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (player == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					player = o.GetComponent<PlayerBaseController>();
					if (player == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Player Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			if (!player.actionSlots.BindToInput(slotVal.RunAndGetInt(), button.name))
			{
				Log(LogType.Error, "Error while trying to bind slot.");
				return BlockReturn.Error;
			}

			if (false == cacheTarget) player = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}