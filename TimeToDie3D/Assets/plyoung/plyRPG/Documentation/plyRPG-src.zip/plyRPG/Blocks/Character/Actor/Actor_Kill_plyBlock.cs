﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Actor (plyRPG)", "Kill Actor", BlockType.Action, Order = 4,
		Description = "This Block will disable control of the character, trigger the death animation (if set), set its health to zero (if health is associated with it) and start the process of destroying the character as set up in the Actor Inspector.")]
	public class Actor_Kill_plyBlock : plyBlock
	{
		[plyBlockField("Kill", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be an object that has the Actor component on it (a character).")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null) actor = o.GetComponent<Actor>();
				if (actor == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find the plyGame related Actor component on it.");
					return BlockReturn.Error;
				}
			}

			actor.Kill();

			if (false == cacheTarget) actor = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}