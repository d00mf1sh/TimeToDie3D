﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Actor (plyRPG)", "Set Essential", BlockType.Action, Order = 4,
		Description = "Sets the Actor to be essential or not.")]
	public class Actor_SetEssential_plyBlock : plyBlock
	{
		public enum SetTo { Essential, NonEssential }

		[plyBlockField("Set", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has Actor component.")]
		public GameObject_Value target;

		[plyBlockField("to", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public SetTo setto = SetTo.Essential;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		private void GetActor()
		{
			GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
			if (o != null)
			{
				actor = o.GetComponent<Actor>();
				if (actor == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor component on it.");
					return;
				}
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (actor == null)
				{
					GetActor();
					if (false == blockIsValid) return BlockReturn.Error;
				}

				actor.essential = (setto == SetTo.Essential);

				if (false == cacheTarget) actor = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}