﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Actor (plyRPG)", "Set Status Towards Player", BlockType.Action, Order = 4, ShowName = "Set Status",
		Description = "Set the status of the Actor towards the Player.\n0 = Friendly\n1 = Neutral\n2 = Hostile")]
	public class StatusToPlayer_Set_plyBlock : plyBlock
	{
		[plyBlockField("of", ShowAfterField="towards Player", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has Actor component.")]
		public GameObject_Value target;

		[plyBlockField("to", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Value - Integer", Description = "The status value must be one of the following and will throw an error if any other value is used.\n0 = Friendly\n1 = Neutral\n2 = Hostile")]
		public Int_Value val;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null) actor = o.GetComponent<Actor>();
				if (actor == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor component on it.");
					return BlockReturn.Error;
				}
			}

			int v = val.RunAndGetInt();
			if (v < 0 || v > 2)
			{
				blockIsValid = false;
				Log(LogType.Error, "The status value is invalid: " + v);
				return BlockReturn.Error;
			}

			actor.overwriteStatus = true;
			actor.statusTowardsPlayer = (StatusTowardsOther)v;

			if (false == cacheTarget) actor = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}