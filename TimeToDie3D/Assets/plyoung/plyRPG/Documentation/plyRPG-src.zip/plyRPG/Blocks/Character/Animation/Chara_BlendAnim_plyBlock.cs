﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Anim", "Character Legacy (plyRPG)", "Blend Anim", BlockType.Action, Order = 5,
		 Description = "Request the target character to blend an animation. The character legacy animation controller will stay in the 'normal' state where it can control idle and movement related animations being played, so a call to 'Go Idle' to restore from 'controlled' mode is not needed. See 'Play Anim' and 'Go Idle' blocks for more information.")]
	public class Chara_BlendAnim_plyBlock : plyBlock
	{
		[plyBlockField("Blend character anim", ShowIfTargetFieldInvalid = "aniName", ShowName = true, ShowValue = true, Description = "Either add a String Block (containing the clip name) or enter the clip/ animation name directly in the properties.")]
		public String_Value aniNameStr;

		[plyBlockField("Blend character anim:", CustomValueStyle = "plyBlox_BoldLabel")]
		public CharaAniClipNameData aniName = new CharaAniClipNameData();

		[plyBlockField("on", SubName = "Target - GameObject", EmptyValueName = "-self-", ShowName = true, ShowValue = true, Description = "The character.")]
		public GameObject_Value targetChara;

		[plyBlockField("Reverse", SubName = "Reverse - Boolean", Description = "Should the animation be played in reverse?")]
		public bool reverse = false;

		[plyBlockField("Speed", SubName = "Speed - Boolean", Description = "Playback speed. 1 is default speed that the animation was imported at.")]
		public float speed = 1f;

		[plyBlockField("WrapMode", SubName = "WrapMode", Description = "What should happen when the animation reaches it end.")]
		public WrapMode wrapMode = WrapMode.Default;

		[plyBlockField("Layer", SubName = "Layer - Integer", Description = "Animations in higher layers will have their weights distributed first, before lower layers.")]
		public int layer = 1;

		[plyBlockField("BlendMode", SubName = "BlendMode", Description = "Blend mode to use.")]
		public AnimationBlendMode blendMode = AnimationBlendMode.Blend;

		[plyBlockField("Target Weight", SubName = "Target Weight - Float", Description = "Weight to reach over time.")]
		public float targetWeight = 1.0f;

		[plyBlockField("Fade Length", SubName = "Fade Length - Float", Description = "Fade occur over a period of time in seconds.")]
		public float fadeLength = 0.3f;

		[plyBlockField("Cache target", Description = "Tell plyBlox whether it may cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private LegacyAnimControl animController;
		private string clipName = null;

		public override void Created()
		{
			blockIsValid = true;
			if (targetChara == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (animController == null)
			{
				GameObject go = targetChara == null ? owningBlox.gameObject : targetChara.RunAndGetGameObject();
				if (go == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Target is invalid.");
					return BlockReturn.Error;
				}

				animController = go.GetComponent<LegacyAnimControl>();
				if (animController == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target does not have a legacy animation controller.");
					return BlockReturn.Error;
				}

				if (animController.ani == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The legacy animation controller's animation field is not valid.");
					return BlockReturn.Error;
				}
			}

			if (clipName == null)
			{
				// check if the animation clip is present
				bool found = false;
				clipName = aniName.IsValid() ? aniName.name : (aniNameStr == null ? null : aniNameStr.RunAndGetString());
				if (!string.IsNullOrEmpty(clipName))
				{
					foreach (AnimationState state in animController.ani)
					{
						if (state.name.Equals(clipName)) { found = true; break; }
					}
				}

				if (!found)
				{
					blockIsValid = false;
					Log(LogType.Error, "The named animation was not found.");
					return BlockReturn.Error;
				}
			}

			if (reverse) animController.ani[clipName].time = animController.ani[clipName].length;
			animController.ani[clipName].speed = reverse ? (-speed) : speed;
			animController.ani[clipName].wrapMode = wrapMode;
			animController.ani[clipName].blendMode = blendMode;
			animController.ani[clipName].layer = layer;
			animController.BlendAnimation(clipName, targetWeight, fadeLength);

			if (!cacheTarget) { animController = null; clipName = null; }
			else if (!aniName.IsValid()) clipName = null; // do not cache name if using aniNameStr

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}