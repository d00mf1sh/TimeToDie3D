﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Anim", "Character Legacy (plyRPG)", "Set AniGroup", BlockType.Action, Order = 5, ShowName="Set AniGroup",
		 Description = "Set the active Animation Group that the animation controller should be using.")]
	public class Chara_SetAniGroup_plyBlock : plyBlock
	{
		[plyBlockField("to", SubName = "Group Name - String", DefaultObject=typeof(String_Value), ShowName = true, ShowValue = true, Description = "Group name as defined in the animation controller's inspector.")]
		public String_Value groupName;

		[plyBlockField("on", SubName = "Target - GameObject", EmptyValueName = "-self-", ShowName = true, ShowValue = true, Description = "The character.")]
		public GameObject_Value targetChara;

		[plyBlockField("Cache target", Description = "Tell plyBlox whether it may cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private LegacyAnimControl animController;

		public override void Created()
		{
			stopAllOnError = false;
			blockIsValid = groupName != null;
			if (!blockIsValid) Log(LogType.Error, "Group name must be set.");
			if (targetChara == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (animController == null)
			{
				GameObject go = targetChara == null ? owningBlox.gameObject : targetChara.RunAndGetGameObject();
				if (go == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Target is invalid.");
					return BlockReturn.Error;
				}

				animController = go.GetComponent<LegacyAnimControl>();
				if (animController == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target does not have a legacy animation controller.");
					return BlockReturn.Error;
				}
			}

			animController.SetActiveGroup(groupName.RunAndGetString());
			if (!cacheTarget) animController = null;
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}