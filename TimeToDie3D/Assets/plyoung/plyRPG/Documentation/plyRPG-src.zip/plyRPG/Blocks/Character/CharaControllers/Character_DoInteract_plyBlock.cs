﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Do Interact", BlockType.Action, Order = 5, ShowName = "Do Interact",
		Description = "Player will try Interact with its current target, or select one in range to interact with. This is the same as the player using the button bound to interaction (default: E)")]
	public class Character_DoInteract_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			Player.Instance.HandleButtonInteract(true);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}