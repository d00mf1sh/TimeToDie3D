﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Set Selected", BlockType.Action, Order = 5, ShowName = "Set selected",
		Description = "Sets the target (selected object) of the Actor (Character). This can be any targetable type object, like a Character or Item. Will fail if the target is not a targetable type.")]
	public class Character_SetSelected_plyBlock : plyBlock
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has a plyGame Character Controller component, like the Player or NPC Controllers.")]
		public GameObject_Value target;

		[plyBlockField("to", ShowName = true, ShowValue = true, SubName = "To be Selected - GameObject", Description = "The object to be selected. Should be a targetable type like a Character or an Item. Leave this -null- to clear any selection/ target.")]
		public GameObject_Value targetedObject;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private CharacterControllerBase character = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = true; // targetedObject != null;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			//if (!blockIsValid) Log(LogType.Error, "The object to be selected should be specified.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (character == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					character = o.GetComponent<CharacterControllerBase>();
					if (character == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Character Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			GameObject tg = targetedObject == null ? null : targetedObject.RunAndGetGameObject();

			if (tg == null) character.ClearTarget();
			else character.SelectTarget(tg);

			if (false == cacheTarget) character = null;
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}