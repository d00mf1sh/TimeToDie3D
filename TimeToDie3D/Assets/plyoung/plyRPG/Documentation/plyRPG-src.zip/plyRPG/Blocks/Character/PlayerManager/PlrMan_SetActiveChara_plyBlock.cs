﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "PlayerMan (plyRPG)", "Set Player", BlockType.Action, Order = 2,
		Description = "Set the 'active' player prefab in Player Manager from the list of defined prefabs. This is the player that will be instantiated when 'Spawn Player' is called.")]
	public class PlrMan_SetActiveChara_plyBlock : plyBlock
	{

		[plyBlockField("Set Active Player", ShowAfterField = "in Player Manager", ShowName = true, ShowValue = true, DefaultObject=typeof(Int_Value), SubName = "Index - Integer", Description = "The index into the list of defined Actor Prefabs, starting at (0)")]
		public Int_Value idx;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = idx != null;
			if (!blockIsValid) Log(LogType.Error, "The index field must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			PlayerManager.Instance.SetActivePlayer(idx.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}