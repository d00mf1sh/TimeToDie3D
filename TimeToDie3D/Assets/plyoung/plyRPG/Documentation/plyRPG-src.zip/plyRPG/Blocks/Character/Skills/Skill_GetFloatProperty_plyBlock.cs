﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Get Skill Property", BlockType.Variable, Order = 6, ShowName = "Get Skill",
		ReturnValueString = "Return - Float", ReturnValueType = typeof(Float_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Get a property of a Skill on the specified Actor.")]
	public class Skill_GetFloatProperty_plyBlock : Float_Value
	{
		public enum PropType
		{
			ExecutionTime,
			CooldownTime,
			HitHeightPercentage,
			HitDelay,
			
			MaxProjectiles,
			CreateDelay,
			BetweenCreateDelay,
			MoveSpeed,
			CollisionRayWidth,
			MaxLiveTime,

			MaxTargetSelect,
			MaxDistanceFromSelf,
			TargetRangeAngle,
			TargetRangeRadius,

			MaxSecondaryTargets,
			SecondaryRangeRadius,

		}

		[plyBlockField("Property", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public PropType propType = PropType.ExecutionTime;

		[plyBlockField("of Skill", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill.")]
		public SystemObject_Value targetSkill;

		[plyBlockField("on", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = targetSkill != null;
			if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = 0.0f;
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
						return BlockReturn.Error;
					}
				}
			}

			Skill skill = targetSkill.RunAndGetSystemObject() as Skill;
			if (skill == null)
			{
				Log(LogType.Error, "The Skill value is invalid.");
				return BlockReturn.Error;
			}

			Skill knownSkill = actor.GetKnownSkill(skill);
			if (knownSkill != null)
			{				
				switch (propType)
				{
					case PropType.ExecutionTime: { value = knownSkill.executionTimeout; } break;
					case PropType.CooldownTime: { value = knownSkill.cooldownTimeout; } break;
					case PropType.HitHeightPercentage: { value = knownSkill.hitHeightPercentage; } break;
					case PropType.HitDelay: { value = knownSkill.instantHitDelay; } break;

					case PropType.MaxProjectiles: { value = knownSkill.maxEffects; } break;
					case PropType.CreateDelay: { value = knownSkill.projectileCreateDelay; } break;
					case PropType.BetweenCreateDelay: { value = knownSkill.projectileCreateDelayBetween; } break;
					case PropType.MoveSpeed: { value = knownSkill.projectileMoveSpeed; } break;
					case PropType.CollisionRayWidth: { value = knownSkill.collisionRayWidth; } break;
					case PropType.MaxLiveTime: { value = knownSkill.maxLiveTime; } break;

					case PropType.MaxTargetSelect: { value = knownSkill.maxEffects; } break;
					case PropType.MaxDistanceFromSelf: { value = knownSkill.targetingDistance; } break;
					case PropType.TargetRangeAngle: { value = knownSkill.targetingAngle; } break;
					case PropType.TargetRangeRadius: { value = knownSkill.targetingRadius; } break;

					case PropType.MaxSecondaryTargets: { value = knownSkill.secondaryMaxTargets; } break;
					case PropType.SecondaryRangeRadius: { value = knownSkill.secondaryRadius; } break;
				}
			}
			else
			{
				Log(LogType.Error, "The Skill is not known by the Actor.");
				return BlockReturn.Error;
			}

			if (false == cacheTarget) actor = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}