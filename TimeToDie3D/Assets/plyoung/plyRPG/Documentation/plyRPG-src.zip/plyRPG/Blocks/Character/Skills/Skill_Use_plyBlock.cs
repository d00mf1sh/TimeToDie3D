﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Use Skill", BlockType.Action, Order = 6,
		Description = "Make an Actor use the specified Skill. It will fail if the Actor does not know that Skill. The Skill will be queued by the Actor for use as soon as possible since the Skill might still be on cool-down or another Skill might be executing.")]
	public class Skill_Use_plyBlock : plyBlock
	{
		[plyBlockField("Let", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
		public GameObject_Value target;

		[plyBlockField("use Skill", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill to perform.")]
		public SystemObject_Value val;

		[plyBlockField("Auto-learn", Description = "Set this to True if you want the Skill user to auto-learn the Skill if it does not yet know the Skill. Only known Skills can be used.")]
		public bool learn = false;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = val != null;
			if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
						return BlockReturn.Error;
					}
				}
			}

			Skill skill = val.RunAndGetSystemObject() as Skill;
			if (skill == null)
			{
				Log(LogType.Error, "The Skill value is invalid.");
				return BlockReturn.Error;
			}

			//Debug.Log("actor.QueueSkillForExecution("+skill+","+learn+")");
			actor.QueueSkillForExecution(skill, learn);

			if (false == cacheTarget) actor = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}