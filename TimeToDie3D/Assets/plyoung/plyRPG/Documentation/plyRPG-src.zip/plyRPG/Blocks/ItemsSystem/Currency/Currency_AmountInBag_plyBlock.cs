﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Currency (plyRPG)", "Amount in Bag", BlockType.Variable, Order = 2, ShowName = "Currency in Bag",
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Return how much currency is present in the Bag.")]
	public class Currency_AmountInBag_plyBlock : Int_Value
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			value = bag.currency;

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}