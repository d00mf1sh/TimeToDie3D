﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	public class EquipSlotData
	{
		public string name = "";

		public override string ToString()
		{
			return string.IsNullOrEmpty(name) ? "-invalid-" : name;
		}

		public EquipSlotData Copy()
		{
			EquipSlotData o = new EquipSlotData();
			o.name = this.name;
			return o;
		}

		// ============================================================================================================
	}
}