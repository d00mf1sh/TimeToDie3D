﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	public class SkillFieldData : IBlockValidate
	{
		public string id = ""; // skill unique id
		public string cachedName = "";

		public override string ToString()
		{
			if (string.IsNullOrEmpty(cachedName)) return "-invalid-";
			return string.IsNullOrEmpty(cachedName) ? "-invalid-" : cachedName;
		}

		public SkillFieldData Copy()
		{
			SkillFieldData o = new SkillFieldData();
			o.id = this.id;
			o.cachedName = this.cachedName;
			return o;
		}

		public bool IsValid()
		{
			return (false == string.IsNullOrEmpty(id));
		}

		// ============================================================================================================
	}
}