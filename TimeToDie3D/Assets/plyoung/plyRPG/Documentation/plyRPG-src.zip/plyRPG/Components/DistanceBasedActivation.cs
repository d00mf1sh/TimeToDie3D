﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("plyGame/Misc/Distance Based Activation")]
	public class DistanceBasedActivation : MonoBehaviour
	{
		public float inactivePlayerDistance = 100f;	// The object is disabled when the player is further away than this
		public float distanceCheckTimout = 10f;		// How long to wait before checking if player is in range (seconds)

		private Transform _tr;
		private float playerDistance = 0f;
		private float checkTime = 0f;
		private float inactivePlayerDistanceSqr = 0f;
		private bool skipFrame = true;

		protected void Start()
		{
			inactivePlayerDistanceSqr = inactivePlayerDistance * inactivePlayerDistance;
			_tr = transform;
		}

		protected void LateUpdate()
		{
			if (skipFrame)
			{	// need to skip a frame before potentially disabling the persistObject
				// if i disable it too soon the object's Load() will not run
				skipFrame = false;
				return;
			}

			if (false == Player.IsReady)
			{
				// no player to check distance against, do nothing and check again later
				Invoke("CheckIfShouldEnable", 0.3f);
				return;
			}

			// check if should disable
			if (Time.time > checkTime)
			{
				checkTime = Time.time + distanceCheckTimout;
				playerDistance = (Player.Instance.transform.position - _tr.position).sqrMagnitude;
				if (playerDistance >= inactivePlayerDistanceSqr)
				{	// player is too far from object, disable the object
					// setup an invoke to check when object should become active again
					Invoke("CheckIfShouldEnable", distanceCheckTimout);
					gameObject.SetActive(false);
				}
			}
		}

		private void CheckIfShouldEnable()
		{
			if (Player.Instance == null)
			{	// no player object, will check again a bit later
				Invoke("CheckIfShouldEnable", distanceCheckTimout);
				return;
			}

			playerDistance = (Player.Instance.transform.position - _tr.position).sqrMagnitude;
			if (playerDistance < inactivePlayerDistanceSqr)
			{
				checkTime = Time.time + distanceCheckTimout;
				gameObject.SetActive(true);
			}
			else
			{	// not in range, wait some more
				Invoke("CheckIfShouldEnable", distanceCheckTimout);
			}
		}

		// ============================================================================================================
	}
}