﻿//// -= plyGame =-
//// www.plyoung.com
//// Copyright (c) Leslie Young
//// ====================================================================================================================

//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using plyCommon;
//using plyBloxKit;

//namespace plyGame
//{
//	/// <summary> All defined Factions. </summary>
//	[System.Serializable]
//	public class ActorFactionsAsset : ScriptableObject
//	{
//		[HideInInspector]
//		public List<ActorFaction> factions = new List<ActorFaction>();		//!< List of defined factions

//		[HideInInspector]
//		public List<FactionVarList> varTypes = new List<FactionVarList>();	//!< The variable types use by factions

//		[HideInInspector]
//		public bool persistVars = true;										//!< should variables be persisted?

//		[HideInInspector]
//		public GameObject bloxObjectFab = null;								//!< Prefab of the object that holds the plyBlox component to handle Faction events

//		// ============================================================================================================

//		/// <summary> Get Faction definition by its Id. Return null if not found. </summary>
//		public ActorFaction GetDefinition(UniqueID id)
//		{
//			if (id.IsEmpty) return null;
//			for (int i = 0; i < factions.Count; i++)
//			{
//				if (factions[i].id == id) return factions[i];
//			}
//			return null;
//		}

//		/// <summary> Get Faction index in the factions list by its Id. Return -1 if not found. </summary>
//		public int GetDefinitionIdx(UniqueID id)
//		{
//			if (id.IsEmpty) return -1;
//			for (int i = 0; i < factions.Count; i++)
//			{
//				if (factions[i].id == id) return i;
//			}
//			return -1;
//		}

//		/// <summary> Get Faction screen name by its Id. Return "-invalid-" if not found. </summary>
//		public string GetScreenName(UniqueID id)
//		{
//			if (id.IsEmpty) return "-invalid-";
//			for (int i = 0; i < factions.Count; i++)
//			{
//				if (factions[i].id == id) return factions[i].def.screenName;
//			}
//			return "-invalid-";
//		}

//		/// <summary> Returns a list of names of all defined factions. </summary>
//		public string[] GetNames()
//		{
//			string[] n = new string[factions.Count];
//			for (int i = 0; i < n.Length; i++) n[i] = factions[i].def.screenName;
//			return n;
//		}

//		// ============================================================================================================
//	}
//}