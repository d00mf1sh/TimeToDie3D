﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> Selectors used by player. </summary>
	[System.Serializable]
	public class PlayerSelectorsAsset : ScriptableObject
	{
		[HideInInspector] public UniqueID friendlyNPC = UniqueID.Empty;		//!< marker used when NPC is selected that player is hostile towards
		[HideInInspector] public UniqueID neutralNPC = UniqueID.Empty;		//!< marker used when NPC is selected that player is neutral towards
		[HideInInspector] public UniqueID hostileNPC = UniqueID.Empty;		//!< marker used when NPC is selected that player is friendly towards
		[HideInInspector] public UniqueID interactObject = UniqueID.Empty;	//!< marker used when intractable object is selected
		[HideInInspector] public UniqueID item = UniqueID.Empty;			//!< marker used when item is selected

		// ============================================================================================================
	}
}