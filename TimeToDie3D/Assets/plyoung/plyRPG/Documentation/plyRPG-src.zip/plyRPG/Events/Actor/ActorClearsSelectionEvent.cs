﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Actor", "On Actor clears Selection",
		Description = "Called when the Actor (Character) clears the selection it previously made of a Targetable object like a Character, Object or Item. This Event will trigger in Blox on the Character Object and child objects of it. You can also use this with an NPC as this event will be triggered when the NPC selects a target (engages the target)\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>target</b>: The cleared GameObject.\n" +
		"- <b>targetData</b>: Data (System.Object) of the object. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n" +
		"- <b>targetType</b>: An Integer value, indicating what type of object was targeted. 0=Unknown, 1=Character, 2=Object, 3=Item.\n"
	)]
	public class ActorClearsSelectionEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Targeting);
		}

		// ============================================================================================================
	}
}