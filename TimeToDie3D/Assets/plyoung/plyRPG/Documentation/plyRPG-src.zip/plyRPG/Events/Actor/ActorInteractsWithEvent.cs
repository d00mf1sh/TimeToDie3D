﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Actor", "On Actor Starts Interaction",
		Description = "Called when the Actor (Character) starts Interaction with a Targetable object like a Character, Object or Item. This is normally only used to check when the Player starts interaction. You might also want to use the 'Object > On Interact' Event which is triggered on the object that is interacted with. This Event will trigger in Blox on the Character Object and child objects of it. \n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>target</b>: The targeted GameObject that is being Interacted with.\n"+
		"- <b>targetData</b>: Data (System.Object) of the object. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n" +
		"- <b>targetType</b>: An Integer value, indicating what type of object was targeted. 0=Unknown, 1=Character, 2=Object, 3=Item.\n"
		)]
	public class ActorInteractsWithEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Targeting);
		}

		// ============================================================================================================
	}
}