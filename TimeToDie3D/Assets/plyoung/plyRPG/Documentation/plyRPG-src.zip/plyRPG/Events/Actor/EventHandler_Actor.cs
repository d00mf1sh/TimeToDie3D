﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_Actor : plyEventHandler
	{
		private List<plyEvent> deathEvents = new List<plyEvent>(0);
		private List<plyEvent> restoreEvents = new List<plyEvent>(0);
		private bool stateChanged = false;

		// ============================================================================================================

		public override void StateChanged()
		{
			deathEvents = new List<plyEvent>(0);
			restoreEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Actor Death"))
			{
				deathEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Actor Restored"))
			{
				restoreEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (deathEvents.Count > 0) || (restoreEvents.Count > 0);

			deathEvents.TrimExcess();
			restoreEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnActorDeath()
		{
			if (deathEvents.Count == 0) return;
			stateChanged = false;
			for (int i = 0; i < deathEvents.Count; i++)
			{
				bloxObject.RunEvent(deathEvents[i]);
				if (stateChanged) break; // don't execute any further Events if State changed
			}
		}

		public void OnActorRestored()
		{
			if (restoreEvents.Count == 0) return;
			stateChanged = false;
			for (int i = 0; i < restoreEvents.Count; i++)
			{
				bloxObject.RunEvent(restoreEvents[i]);
				if (stateChanged) break; // don't execute any further Events if State changed
			}
		}

		// ============================================================================================================
	}
}
