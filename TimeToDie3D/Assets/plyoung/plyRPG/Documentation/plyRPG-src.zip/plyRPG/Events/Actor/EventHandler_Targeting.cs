﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_Targeting : plyEventHandler
	{
		private List<plyEvent> selectionEvents = new List<plyEvent>(0);
		private List<plyEvent> clearEvents = new List<plyEvent>(0);
		private List<plyEvent> interactWithEvents = new List<plyEvent>(0);
		private List<plyEvent> interactStopEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			selectionEvents = new List<plyEvent>(0);
			clearEvents = new List<plyEvent>(0);
			interactWithEvents = new List<plyEvent>(0);
			interactStopEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Actor makes Selection"))
			{
				selectionEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Actor clears Selection"))
			{
				clearEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Actor Starts Interaction"))
			{
				interactWithEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Actor Stopped Interaction"))
			{
				interactStopEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (selectionEvents.Count > 0 || clearEvents.Count > 0 || interactWithEvents.Count > 0 || interactStopEvents.Count > 0);

			selectionEvents.TrimExcess();
			clearEvents.TrimExcess();
			interactWithEvents.TrimExcess();
			interactStopEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnTargetSelected(Targetable target)
		{
			if (selectionEvents.Count == 0) return;
			RunEvents(selectionEvents,
				new plyEventArg("target", target.gameObject),
				new plyEventArg("targetData", target.DataObject()),
				new plyEventArg("targetType", (target.TargetableType() == Targetable.Type.Character ? (int)1 : target.TargetableType() == Targetable.Type.Object ? (int)2 : target.TargetableType() == Targetable.Type.Item ? (int)3 : (int)0))
			);
		}

		public void OnTargetCleared(Targetable target)
		{
			if (clearEvents.Count == 0) return;
			RunEvents(clearEvents,
				new plyEventArg("target", target.gameObject),
				new plyEventArg("targetData", target.DataObject()),
				new plyEventArg("targetType", (target.TargetableType() == Targetable.Type.Character ? (int)1 : target.TargetableType() == Targetable.Type.Object ? (int)2 : target.TargetableType() == Targetable.Type.Item ? (int)3 : (int)0))
			);
		}

		public void OnInteractStarted(Targetable target)
		{
			if (interactWithEvents.Count == 0) return;
			RunEvents(interactWithEvents,
				new plyEventArg("target", target.gameObject),
				new plyEventArg("targetData", target.DataObject()),
				new plyEventArg("targetType", (target.TargetableType() == Targetable.Type.Character ? (int)1 : target.TargetableType() == Targetable.Type.Object ? (int)2 : target.TargetableType() == Targetable.Type.Item ? (int)3 : (int)0))
			);
		}

		public void OnInteractStopped(Targetable target)
		{
			if (interactStopEvents.Count == 0) return;
			RunEvents(interactStopEvents,
				new plyEventArg("target", target.gameObject),
				new plyEventArg("targetData", target.DataObject()),
				new plyEventArg("targetType", (target.TargetableType() == Targetable.Type.Character ? (int)1 : target.TargetableType() == Targetable.Type.Object ? (int)2 : target.TargetableType() == Targetable.Type.Item ? (int)3 : (int)0))
			);
		}

		// ============================================================================================================
	}
}
