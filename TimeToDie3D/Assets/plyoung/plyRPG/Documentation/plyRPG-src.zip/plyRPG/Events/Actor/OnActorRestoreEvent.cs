﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Actor", "On Actor Restored",
		Description = "Called when the Actor (Character) is restored. This is called as soon as the restoration is done. This Event will trigger in Blox on the Character Object.\n")]
	public class OnActorRestoreEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Actor);
		}

		// ============================================================================================================
	}
}