﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_TATrigger : plyEventHandler
	{

		private List<plyEvent> enterEvents = new List<plyEvent>(0);
		private List<plyEvent> exitEvents = new List<plyEvent>(0);
		private List<plyEvent> stayEvents = new List<plyEvent>(0);
		//private bool stateChanged = false;
		private AreaTrigger at = null;

		// ============================================================================================================

		public override void StateChanged()
		{
			enterEvents = new List<plyEvent>(0);
			exitEvents = new List<plyEvent>(0);
			stayEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On AreaTrigger Enter"))
			{
				enterEvents.Add(e);
				bloxObject.NeedObjectActive = true;
			}
			else if (e.uniqueIdent.Equals("On AreaTrigger Exit"))
			{
				exitEvents.Add(e);
				bloxObject.NeedObjectActive = true;
			}
			else if (e.uniqueIdent.Equals("On AreaTrigger Stay"))
			{
				stayEvents.Add(e);
				bloxObject.NeedObjectActive = true;
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (exitEvents.Count > 0 || enterEvents.Count > 0 || stayEvents.Count > 0);

			exitEvents.TrimExcess();
			enterEvents.TrimExcess();
			stayEvents.TrimExcess();
		}

		// ============================================================================================================

		protected void Start()
		{
			at = gameObject.GetComponent<AreaTrigger>();
			if (at == null)
			{
				Debug.LogError("The Area Trigger Events can only function if they are in a Blox object placed on an Area Trigger.");
			}
		}

		protected void OnTriggerEnter(Collider collider)
		{
			if (at == null) return;
			if (enterEvents.Count == 0) return;
			int type = 0; // 0: unknown, 1: player, 2: npc
			CharacterControllerBase c = collider.gameObject.GetComponent<CharacterControllerBase>();
			if (c != null)
			{
				if (c.IsPlayer()) type = 1; else type = 2;
				if (at.triggerOnlyOn == AreaTrigger.TriggerOnlyOn.Player && type == 2) return;
				else if (at.triggerOnlyOn == AreaTrigger.TriggerOnlyOn.NPC && type == 1) return;
			}
			else
			{
				if (at.triggerOnlyOn != AreaTrigger.TriggerOnlyOn.Any) return;
			}
			RunEvents(enterEvents, new plyEventArg("type", type), new plyEventArg("obj", collider.gameObject) );
		}

		protected void OnTriggerExit(Collider collider)
		{
			if (at == null) return;
			if (exitEvents.Count == 0) return;
			int type = 0; // 0: unknown, 1: player, 2: npc
			CharacterControllerBase c = collider.gameObject.GetComponent<CharacterControllerBase>();
			if (c != null)
			{
				if (c.IsPlayer()) type = 1; else type = 2;
				if (at.triggerOnlyOn == AreaTrigger.TriggerOnlyOn.Player && type == 2) return;
				else if (at.triggerOnlyOn == AreaTrigger.TriggerOnlyOn.NPC && type == 1) return;
			}
			else
			{
				if (at.triggerOnlyOn != AreaTrigger.TriggerOnlyOn.Any) return;
			}
			RunEvents(exitEvents, new plyEventArg("type", type), new plyEventArg("obj", collider.gameObject));
		}

		protected void OnTriggerStay(Collider collider)
		{
			if (at == null) return;
			if (stayEvents.Count == 0) return;
			int type = 0; // 0: unknown, 1: player, 2: npc
			CharacterControllerBase c = collider.gameObject.GetComponent<CharacterControllerBase>();
			if (c != null)
			{
				if (c.IsPlayer()) type = 1; else type = 2;
				if (at.triggerOnlyOn == AreaTrigger.TriggerOnlyOn.Player && type == 2) return;
				else if (at.triggerOnlyOn == AreaTrigger.TriggerOnlyOn.NPC && type == 1) return;
			}
			else
			{
				if (at.triggerOnlyOn != AreaTrigger.TriggerOnlyOn.Any) return;
			}
			RunEvents(stayEvents, new plyEventArg("type", type), new plyEventArg("obj", collider.gameObject));
		}

		// ============================================================================================================
	}
}
