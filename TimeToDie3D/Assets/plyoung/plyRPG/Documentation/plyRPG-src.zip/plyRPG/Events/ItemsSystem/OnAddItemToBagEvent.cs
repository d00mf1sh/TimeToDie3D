﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Items", "On Add Item to Bag",
		Description = "Called when an Item was successfully added to a Bag. You can use this Event in the plyBlox of an Item or object that has an Item Bag component. The Event trigger first for the Bag and then for the Item." +
		"\n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>bagSlot</b>: The bag slot (int) in which the Item was placed.\n" +
		"- <b>item</b>: The Item (System.Object) that was placed in the bag. It is an instance of the Item in the Bag. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>owner</b>: The owner (GameObject) of the bag the Item was added to.\n"
		)]
	public class OnAddItemToBagEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Item);
		}

		// ============================================================================================================
	}
}