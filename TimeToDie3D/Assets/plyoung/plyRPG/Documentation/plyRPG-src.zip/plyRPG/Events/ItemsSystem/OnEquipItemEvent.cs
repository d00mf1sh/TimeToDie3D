﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Items", "On Equip Item",
		Description = "Called when an Item is Equipped. You can use this Event in the plyBlox of an Item or the object that has the Equipment Slots component on it. The Event will first trigger for the Equipment Slots and then for the Item." +
		"\n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>equipSlot</b>: The slot (int) in which the Item was equipped.\n" +
		"- <b>item</b>: The Item (System.Object) that was equipped. This is an instance of the Item object that exist in the scene (on the character). This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>owner</b>: The owner (GameObject) of the Slot the Item was equipped to.\n"
		)]
	public class OnEquipItemEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Item);
		}

		// ============================================================================================================
	}
}