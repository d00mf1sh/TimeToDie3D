﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_NPC : plyEventHandler
	{
		private List<plyEvent> thinkEvents = new List<plyEvent>(0);
		private List<plyEvent> detectionEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			thinkEvents = new List<plyEvent>(0);
			detectionEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On AI Think"))
			{
				thinkEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Detect Characters"))
			{
				detectionEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (thinkEvents.Count > 0 || detectionEvents.Count > 0);

			thinkEvents.TrimExcess();
			detectionEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnAIThink()
		{
			if (thinkEvents.Count == 0) return;
			RunEvents(thinkEvents);

			//stateChanged = false;
			//for (int i = 0; i < thinkEvents.Count; i++)
			//{
			//	bloxObject.RunEvent(thinkEvents[i]);
			//	if (stateChanged) break; // don't execute any further Events if State changed
			//}
		}

		public void OnDetectCharacters(List<NPCController.DetectedTarget> detectedCharas)
		{
			if (detectionEvents.Count == 0) return;
			RunEvents(detectionEvents,
				new plyEventArg("closest", detectedCharas[0].chara.gameObject),
				new plyEventArg("total", detectedCharas.Count)
			);

			//bloxObject.SetTempVarValue("closest", detectedCharas[0].chara.gameObject);
			//bloxObject.SetTempVarValue("total", detectedCharas.Count);

			//stateChanged = false;
			//for (int i = 0; i < detectionEvents.Count; i++)
			//{
			//	bloxObject.RunEvent(detectionEvents[i]);
			//	if (stateChanged) break; // don't execute any further Events if State changed
			//}
		}

		// ============================================================================================================
	}
}
