﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_SpawnPoint : plyEventHandler
	{
		private List<plyEvent> npcCreatedEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			npcCreatedEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Created NPC"))
			{
				npcCreatedEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (npcCreatedEvents.Count > 0);

			npcCreatedEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnCreatedNPC(NPCController npc)
		{
			if (npcCreatedEvents.Count == 0) return;
			RunEvents(npcCreatedEvents, new plyEventArg("npc", npc.gameObject), new plyEventArg("npcData", npc.DataObject()));

			//bloxObject.SetTempVarValue("npc", npc.gameObject);
			//bloxObject.SetTempVarValue("npcData", npc.DataObject());

			//stateChanged = false;
			//for (int i = 0; i < npcCreatedEvents.Count; i++)
			//{
			//	bloxObject.RunEvent(npcCreatedEvents[i]);
			//	if (stateChanged) break; // don't execute any further Events if State changed
			//}
		}
		
		// ============================================================================================================
	}
}
