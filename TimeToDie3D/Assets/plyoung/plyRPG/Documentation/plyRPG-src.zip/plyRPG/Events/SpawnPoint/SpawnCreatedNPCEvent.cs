﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/SpawnPoint", "On Created NPC",
		Description = "This Event is triggered in the SpawnPoint's Blox when the SpawnPoint created a new NPC (character).\n\n" + 
		"The following Temporary Variables will be set:\n\n"+
		"- <b>npc</b>: The NPC (GameObject) that was created.\n"+
		"- <b>npcData</b>: Data (System.Object) of NPC. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n"
		)]
	public class SpawnCreatedNPCEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_SpawnPoint);
		}

		// ============================================================================================================
	}
}