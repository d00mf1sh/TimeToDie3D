﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> work-in-progress </summary>
	[System.Serializable]
	public class ActorFaction
	{
		[HideInInspector] public UniqueID id = new UniqueID();	//!< Unique Id of the Actor. Same for all instances of same Actor/ Character prefab
		public CommonDefinitionData def = new CommonDefinitionData();	//!< common data

		public List<StatusTowardsOther> statusTo = new List<StatusTowardsOther>();	//!< Indexed according to order that Factions appears at in definitions list
		public List<FactionVarList> varListDef = new List<FactionVarList>();		//!< Do not use at runtime. Use the provided functions. The var list is a list if variables that are associated with each defined faction

		// ============================================================================================================

		private int _idx = -1;
		public int idx { get { return _idx; } } // index into list of factions. inited in Init()

		private Dictionary<string, List<plyVar>> vars;
		private plyBlox blox = null;
		private EventHandler_Factions eventHandler = null;
		
		// ============================================================================================================

		public override string ToString()
		{
			return def.screenName;
		}

		public ActorFaction Copy()
		{
			ActorFaction obj = new ActorFaction();
			this.CopyTo(obj);
			return obj;
		}

		public void CopyTo(ActorFaction o)
		{
			o.id = this.id.Copy();
			o.def = this.def.Copy();
			o.statusTo = new List<StatusTowardsOther>();
			for (int i = 0; i < this.statusTo.Count; i++) o.statusTo.Add(this.statusTo[i]);
			o.varListDef = new List<FactionVarList>();
			for (int i = 0; i < this.varListDef.Count; i++) o.varListDef.Add(this.varListDef[i].Copy());
		}

		// ============================================================================================================

		public void Init(int idx, plyBlox blox)
		{
			this._idx = idx;
			this.blox = blox;
			vars = new Dictionary<string, List<plyVar>>(varListDef.Count);
			for (int i = 0; i < varListDef.Count; i++)
			{
				vars.Add(varListDef[i].name, varListDef[i].vars);
			}

			if (blox != null)
			{
				eventHandler = blox.gameObject.GetComponent<EventHandler_Factions>();
			}

		}

		/// <summary>
		/// Set Status of this faction towards another
		/// </summary>
		public void SetStatusTowards(ActorFaction targetFaction, StatusTowardsOther status)
		{
			if (targetFaction.idx < 0) return;
			if (targetFaction.idx >= statusTo.Count)
			{
				Debug.LogError("Failed to update Status of Faction towards another. This error should not have occurred, please contact support.");
				return;
			}

			statusTo[targetFaction.idx] = status;
	
			if (eventHandler != null)
			{
				eventHandler.OnStatusChange(this, targetFaction, status, this.idx, targetFaction.idx);
			}
		}

		/// <summary>
		/// Returns Status of this faction towards another
		/// </summary>
		public StatusTowardsOther GetStatusTowards(ActorFaction targetFaction)
		{
			if (targetFaction.idx < 0) return StatusTowardsOther.Friendly;
			if (targetFaction.idx >= statusTo.Count)
			{
				Debug.LogError("Failed to get Status of Faction towards another. This error should not have occurred, please contact support.");
				return StatusTowardsOther.Friendly;
			}

			return statusTo[targetFaction.idx];
		}

		/// <summary> Return a reference to the named Faction Variable. Will return null if the variable does
		///  not exist. targetFaction is the faction that the variable is related to. All faction variables
		///  belongs to a faction and is related to another faction as seen in the factions editor var grid. </summary>
		public plyVar GetFactionVariable(string name, ActorFaction targetFaction)
		{
			if (string.IsNullOrEmpty(name)) return null;
			if (!vars.ContainsKey(name)) return null;

			List<plyVar> v = vars[name];
			if (targetFaction.idx < 0) return null;
			if (targetFaction.idx >= v.Count)
			{
				Debug.LogError("Failed to get Faction Variable. This error should not have occurred, please contact support."); 
				return null;
			}

			return v[targetFaction.idx];
		}

		/// <summary> Return the value of a Faction Variable. Return null if it does not exist. Keep in mind
		///  that the value might simply be null. targetFaction is the faction that the variable is related to.
		///  All faction variables belongs to a faction and is related to another faction as seen in the
		///  factions editor var grid. </summary>
		public object GetFactionVarValue(string name, ActorFaction targetFaction)
		{
			if (string.IsNullOrEmpty(name)) return null;
			if (!vars.ContainsKey(name)) return null;

			List<plyVar> v = vars[name];
			if (targetFaction.idx < 0) return null;
			if (targetFaction.idx >= v.Count)
			{
				Debug.LogError("Failed to get Faction Variable Value. This error should not have occurred, please contact support.");
				return null;
			}

			return v[targetFaction.idx].GetValue();
		}

		/// <summary> Set the value of a Faction Variable. Will fail if variable doe snot exist.
		/// targetFaction is the faction that the variable is related to. All faction variables
		/// belongs to a faction and is related to another faction as seen in the factions
		/// editor var grid. </summary>
		public void SetFactionVarValue(string name, object val, ActorFaction targetFaction)
		{
			if (string.IsNullOrEmpty(name)) return;
			if (!vars.ContainsKey(name)) return;

			List<plyVar> v = vars[name];
			if (targetFaction.idx < 0) return;
			if (targetFaction.idx >= v.Count)
			{
				Debug.LogError("Failed to set Faction Variable Value. This error should not have occurred, please contact support.");
				return;
			}

			v[targetFaction.idx].SetValue(val);

			if (eventHandler != null)
			{
				eventHandler.OnVariableChange(this, targetFaction, v[targetFaction.idx], idx, targetFaction.idx);
			}

		}

		// ============================================================================================================
	}
}