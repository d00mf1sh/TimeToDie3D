﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> The Default NPC Controller and AI </summary>
	[AddComponentMenu("plyGame/Character/NPC/NPC Controller")]
	public class NPCController : CharacterControllerBase
	{
		/// <summary> What the NPC does while not using Skills </summary>
		public enum IdleMode 
		{ 
			Stay,	//!< Do not move around
			Wander,	//!< Wander in specified radius round spawn point
			Patrol,	//!< Follow a specified path
			Follow, //!< Follow a specified object
		}

		public enum WanderArea
		{
			Circular,
			Rectangular,
		}

		public float runSpeed = 6f;					//!< The run speed used when chasing something - to get into range faster
		public float thinkInterval = 1f;			//!< How often the 'AI Think' event is called

		public IdleMode idleMode = IdleMode.Stay;	//!< What the NPC does while not using Skills
		public WanderArea wanderArea = WanderArea.Circular; //!< Type of wander area
		public float wanderRadius = 10f;			//!< [IdleMode.Wander] Radius around spawn point. With WanderArea.Rectangular this is angle of rectangle
		public Vector2 wanderWH = Vector2.one;		//!< [IdleMode.Wander] Width & Height of wander area when WanderArea.Rectangular
		public float wanderDelayMin = 0.5f;			//!< [IdleMode.Wander] Min time, in Randomiser, to wait before choosing a new spot to move to
		public float wanderDelayMax = 2.0f;			//!< [IdleMode.Wander] Max time, in Randomiser, to wait before choosing a new spot to move to
		public WaypointPath path;					//!< [IdleMode.Patrol] Path to follow
		public Transform followObject;				//!< [IdleMode.Follow] Object to follow around
		public float minFollowDistance = 5f;		//!< Do not get too close
		public float maxFollowDistance = 10f;		//!< Get closer when too far

		public bool canDetectPlayer = false;		//!< Must be turned on to detect the player. For performance, turn this off if the NPC to not have to detect the player
		public bool canDetectNPCs = false;			//!< Must be turned on to detect other NPCs. For performance, turn this off if the NPC will never attack other NPCs
		
		public StatusTowardsOther whenStatusTowardsPlayer = StatusTowardsOther.Hostile; //!< Will only detect the player if status towards player is this or higher
		//public bool checkFactionToPlayer = false;	//!< Check the NPC factions' status towards player?
		//public StatusTowardsOther whenFactionTowardPlayer = StatusTowardsOther.Hostile; //!< Will only do detect the player if the status of the factions of this NPC is this or higher towards the faction(s) the player is in
		public StatusTowardsOther whenStatusTowardNPC = StatusTowardsOther.Hostile;	//!< Will only do detect a target NPC if the status of the factions of this NPC is this or higher towards the faction(s) the target NPC is in
		public bool ignoreEssentialActor = true;	//!< Ignore detection of an Actor that is set to be essential

		public float detectionTimeout = 1f;			//!< How many seconds to wait before attempting the next detection
		public bool skipIfEngaged = true;			//!< Do not run detection if it has a target
		public bool autoEngageClosest = true;		//!< Should closest detected be automatically set as targeted? This will happen AFTER the 'On Detect Characters' Event, if set True.

		public float detection360Distance = 5f;		//!< The radius used to detect the Player or other NPCs around this NPC
		public float detectionForwardDistance = 8f;	//!< The distance in direction the NPC is facing (in combination with detectionForwardAngle), used to detect the Player and other NPCs
		public float detectionForwardAngle = 30f;	//!< The angle/ range in direction the NPC is facing (in combination with detectionForwardDistance), used to detect the Player or other NPCs.
		public LayerMask detectionObstacleMask = (1 << GameGlobal.LayerMapping.Floor); //!< What is considered in way of detecting
		public LayerMask detectionFwObstacleMask = (1 << GameGlobal.LayerMapping.Floor | 1 << GameGlobal.LayerMapping.Wall); //!< What is considered in way of detecting (for forward detection)
		public float obstacleCheckOffsetY = 1f;		//!< Height at which to cast ray from (eye level)

		public float engagedMinDistance = 2f;			//!< Set this to the minimum distance the NPC can be from its engaged target. NPC will run closed if needed and not executing a skill.
		public float engagedMaxDistance = 5f;			//!< Set this to the maximum distance the NPC can be from its engaged target. NPC will move away from target if closer than this to target and not executing a skill.

		public float disengageDistanceHome = 35f;		//!< Disengage the selectedTarget when further than this distance from SpawnPoint, Follow Target, or Patrolled Path. Set to 0 to disable this.
		public float disengageDistanceTarget = 10f;		//!< also check if at least this far from target, else stay on target

		// ============================================================================================================

		public Vector3 spawnLocation { get; set; }
		public NPCMoveBase navi { get; set; }

		public SpawnPoint spawnPoint { get; set; }
		public int spawnGroupIdx { get; set; }

		private float activeMoveSpeed = 0f;
		private float thinkTimer = 0f;
		private float idleTimer = 0f;
		private float followTimer = 0f;
		private float engagedFollowTimer = 0f;
		private bool wanderGoIdle = false;
		private int currPatrolPoint = 0;
		private float detectionTimer = 0f;
		private float detectionAngle = 0f;		// = detectionForwardAngle / 2f
		private float maxDetectDistance = 0f;	// the bigger between detectionForwardDistance & detection360Distance
		private bool callbacksReged = false;
		private EventHandler_NPC eventHandler = null;
		private List<DetectedTarget> lastDetectedCharacters = new List<DetectedTarget>();

		public class DetectedTarget
		{
			public CharacterControllerBase chara;
			public float distance;
		}

		// ============================================================================================================

		protected void Reset()
		{
			moveSpeed = 3.0f;
			turnSpeed = 10.0f;

			gameObject.layer = GameGlobal.LayerMapping.NPC;
			if (navi == null) navi = GetComponent<NPCMoveBase>();

			if (navi)
			{
				if (navi.GetType() == typeof(NPCMovePro)) turnSpeed = 180f;
			}
		}

		new protected void Awake()
		{
			base.Awake();
			GameGlobal.Create(); // make sure global is available, in case user is running scene via Unity play button.
			spawnLocation = _tr.position;

			gameObject.layer = GameGlobal.LayerMapping.NPC;
			if (navi == null) navi = GetComponent<NPCMoveBase>();

			if (navi == null)
			{
				Debug.LogError("[NPCController] No movement controller found. You need to add one of the components from plyGame > Character > NPC > Movement.");
				enabled = false;
				return;
			}

		}

		new protected void Start()
		{
			base.Start();
			eventHandler = gameObject.GetComponent<EventHandler_NPC>();
			thinkTimer = thinkInterval;
			detectionTimer = detectionTimeout;
			detectionAngle = detectionForwardAngle / 2f;
			maxDetectDistance = Mathf.Max(detection360Distance, detectionForwardDistance);
			activeMoveSpeed = moveSpeed;
			callbacksReged = false;
		}

		private void RegisterCallback()
		{
			callbacksReged = true;
			// can only do this after Start() is done
			if (actor.actorClass != null)
			{
				if (actor.actorClass.HP != null)
				{
					actor.actorClass.HP.RegisterChangeListener(OnHPChange);
				}
			}
		}

		// ============================================================================================================

		protected void Update()
		{
			if (!callbacksReged) RegisterCallback();
			if (GameGlobal.Paused) return;
			if (!controlEnabled) return;
			//speed = Velocity().magnitude;

			UpdateIdleAI();
			UpdateDetection(null);
			UpdateEngagedFollow();
			ThinkUpdate();
		}
		
		private void UpdateIdleAI()
		{
			if (selectedTarget != null) return; // not in 'idle' mode if engaged with a target

			// *** Stay
			if (idleMode == IdleMode.Stay) return;
			
			// *** Wander
			if (idleMode == IdleMode.Wander)
			{
				if (navi.IsMovingOrPathing()) return; // is moving, nothing to do for now
				if (wanderGoIdle)
				{	// detected that is just stopped and need to idle for a bit before deciding on new point to move to
					wanderGoIdle = false;
					idleTimer = Random.Range(wanderDelayMin, wanderDelayMax);
					return;
				}

				idleTimer -= Time.deltaTime;
				if (idleTimer <= 0.0f)
				{
					wanderGoIdle = true; // should go idle for a while after moving
					activeMoveSpeed = moveSpeed;
					Vector3 p = spawnLocation + (wanderArea == WanderArea.Circular ? plyUtil.PickPointInCircle(wanderRadius) : plyUtil.PointInRotatedRectangle(wanderWH, wanderRadius));
					navi.MoveTo(p, activeMoveSpeed, turnSpeed);
				}

			}

			// *** Patrol
			else if (idleMode == IdleMode.Patrol)
			{
				if (navi.IsMovingOrPathing()) return; // is moving, nothing to do for now
				if (path == null)
				{
					Debug.LogError("[NPCController] NPC set to patrol but no path specified.");
					idleMode = IdleMode.Stay;
					return;
				}

				activeMoveSpeed = moveSpeed;
				navi.MoveTo(path[currPatrolPoint].position, activeMoveSpeed, turnSpeed);
				currPatrolPoint = (currPatrolPoint + 1 < path.Length ? currPatrolPoint + 1 : 0);
			}

			// *** Follow
			else if (idleMode == IdleMode.Follow)
			{
				if (followObject == null)
				{
					Debug.Log("[NPCController] NPC set to follow but no object to follow was specified. Reverting to Stay mode.");
					idleMode = IdleMode.Stay;
					return;
				}

				// do not continuously do the follow checks, run it on a timer
				followTimer -= Time.deltaTime;
				if (followTimer < 0.0f)
				{
					followTimer = 0.3f;

					// check how far from target. if too far then use run to get closer, else use walk.
					Vector3 dir = (followObject.position - _tr.position);
					float distance = dir.magnitude; 

					// if too close try and move away
					if (distance < minFollowDistance)
					{
						dir.Normalize();
						Vector3 p = followObject.position + (dir * -minFollowDistance);
						activeMoveSpeed = moveSpeed;
						navi.MoveTo(p, activeMoveSpeed, turnSpeed);
					}

					// run closer when too far
					else if (distance > maxFollowDistance)
					{
						dir.Normalize();
						Vector3 p = followObject.position + (dir * -minFollowDistance);
						activeMoveSpeed = runSpeed;
						navi.MoveTo(p, activeMoveSpeed, turnSpeed);
					}
				}
			}
		}

		private void UpdateDetection(GameObject exludeThis)
		{
			if (!canDetectPlayer && !canDetectNPCs) return;
			if (skipIfEngaged && selectedTarget != null) return; // skip if engaged with a target already

			if (actor.executingSkill != null)
			{	// do not update detection if NPC is busy executing a skill
				if (actor.executingSkill.IsExecuting()) return;
			}

			// update detection timer and decide if time to do a detection check
			detectionTimer -= Time.deltaTime;
			if (detectionTimer > 0.0f) return;
			detectionTimer = detectionTimeout;

			float distance = 0f;
			lastDetectedCharacters = new List<DetectedTarget>();

			// run player detection
			if (canDetectPlayer && Player.IsReady)
			{
				if (false == Player.Instance.actor.IsDead())
				{
					if (false == ignoreEssentialActor || false == Player.Instance.actor.essential)
					{
						// check if player in range to be target
						if (actor.HighestStatusToTarget(Player.Instance.actor) >= whenStatusTowardsPlayer)
						{
							if (InRange(Player.Instance.transform.position, out distance))
							{
								lastDetectedCharacters.Add(new DetectedTarget() { chara = Player.Instance, distance = distance });
							}
						}
					}
				}
			}

			// run NPC detection
			if (canDetectNPCs)
			{
				Collider[] hits = Physics.OverlapSphere(_tr.position, maxDetectDistance);// , (1 << GameGlobal.LayerMapping.NPC));
				for (int i = 0; i < hits.Length; i++)
				{
					// do not include self
					if (hits[i].transform == _tr) continue;

					// get character component
					CharacterControllerBase chara = hits[i].transform.gameObject.GetComponent<CharacterControllerBase>();
					if (chara != null)
					{
						if (chara.actor.IsDead()) continue;
						if (false == ignoreEssentialActor || false == chara.actor.essential)
						{
							// check status of faction before doing range check
							if (actor.HighestStatusToTarget(chara.actor) >= whenStatusTowardNPC)
							{
								if (InRange(hits[i].transform.position, out distance))
								{
									lastDetectedCharacters.Add(new DetectedTarget() { chara = chara, distance = distance });
								}
							}
						}
					}
				}
			}

			if (lastDetectedCharacters.Count > 0)
			{
				lastDetectedCharacters.Sort(delegate(DetectedTarget a, DetectedTarget b) { return a.distance.CompareTo(b.distance); });
				gameObject.BroadcastMessage("OnDetectCharacters", lastDetectedCharacters, SendMessageOptions.DontRequireReceiver);
				if (autoEngageClosest)
				{
					engagedFollowTimer = 0f;
					for (int i = 0; i < lastDetectedCharacters.Count; i++)
					{
						if (exludeThis == lastDetectedCharacters[i].chara.gameObject) continue;
						SelectTarget(lastDetectedCharacters[i].chara.gameObject);
						break;
					}
				}
			}

			if (selectedTarget != null)
			{
				Stop();
			}
		}

		private void UpdateEngagedFollow()
		{
			if (selectedTarget == null) return;

			engagedFollowTimer -= Time.deltaTime;
			if (actor.executingSkill != null)
			{	// do not update detection if NPC is busy executing a skill
				if (actor.executingSkill.IsExecuting()) return;
			}

			// do not continuously do the follow checks, run it on a timer
			if (engagedFollowTimer < 0.0f && false == navi.IsMovingOrPathing())
			{
				engagedFollowTimer = 0.5f;

				// check how far from target. if too far then use run to get closer, else use walk.
				Vector3 dir = (selectedTarget.transform.position - _tr.position);
				float distance = dir.magnitude;

				// if too close try and move away
				if (distance < engagedMinDistance)
				{
					if (actor.queuedSkill != null)
					{	// do not move it when queued skill is ready as skill takes priority about NPC position and direction
						if (actor.queuedSkill.IsReady()) return;
					}

					dir.Normalize();
					Vector3 p = selectedTarget.transform.position + (dir * -engagedMinDistance);
					activeMoveSpeed = runSpeed;
					navi.MoveTo(p, activeMoveSpeed, turnSpeed);
				}

				// run closer when too far
				else if (distance > engagedMaxDistance)
				{
					dir.Normalize();
					Vector3 p = selectedTarget.transform.position + (dir * -engagedMinDistance);
					activeMoveSpeed = runSpeed;
					navi.MoveTo(p, activeMoveSpeed, turnSpeed);
				}
			}
		}

		private void ThinkUpdate()
		{
			thinkTimer -= Time.deltaTime;
			if (thinkTimer <= 0.0f)
			{
				thinkTimer = thinkInterval;
				DisengageCheck(); // check if should disengage current before triggering Think Event
				if (eventHandler != null) eventHandler.OnAIThink();
			}
		}

		private void DisengageCheck()
		{
			if (!canDetectPlayer && !canDetectNPCs) return;
			if (selectedTarget == null) return;

			// in follow mode i need to force disengage if follow target too far
			if (idleMode == IdleMode.Follow && followObject != null)
			{
				if ((followObject.transform.position - _tr.position).magnitude >= maxFollowDistance)
				{
					lastDetectedCharacters = new List<DetectedTarget>();
					ClearTarget();
					return;
				}
			}

			//bool targetDead = ((CharacterControllerBase)selectedTarget).actor.IsDead();
			//if (targetDead || disengageDistanceHome > 0.0f || idleMode == IdleMode.Follow)
			//{
			//	// still in range of selected target?
			//	float dist = (selectedTarget.transform.position - _tr.position).magnitude;
			//	if (!targetDead && dist <= disengageDistanceTarget)
			//	{
			//		return;
			//	}

			//	// disengage
			//	GameObject lastTarget = selectedTarget.gameObject;
			//	lastDetectedCharacters = new List<DetectedTarget>();
			//	ClearTarget();

			//	// find new target
			//	UpdateDetection(lastTarget);

			//	// else go home
			//	if (selectedTarget == null)
			//	{
			//		Vector3 home = _tr.position;
			//		float homeDistance = 0f;

			//		if (idleMode == IdleMode.Stay || idleMode == IdleMode.Wander)
			//		{
			//			home = spawnLocation;
			//			homeDistance = (home - _tr.position).magnitude;
			//		}
			//		else if (idleMode == IdleMode.Follow)
			//		{
			//			if (followObject != null)
			//			{
			//				home = followObject.position;
			//				homeDistance = (home - _tr.position).magnitude;
			//			}
			//		}
			//		else if (idleMode == IdleMode.Patrol)
			//		{
			//			if (path != null)
			//			{
			//				home = path[currPatrolPoint].position;
			//				homeDistance = (home - _tr.position).magnitude;
			//			}
			//		}

			//		if (homeDistance > 0)//disengageDistanceHome)
			//		{
			//			ClearTarget();
			//			RequestMoveTo(home, false);
			//		}
			//	}
			//}

			bool do_it = false;
			Vector3 home = _tr.position;
			bool targetDead = ((CharacterControllerBase)selectedTarget).actor.IsDead();

			// check if current target dead
			if (targetDead)
			{
				do_it = true;
			}

			// check if target ran too far from this NPC
			else if (disengageDistanceTarget > 0.0f)
			{
				if ((selectedTarget.transform.position - _tr.position).magnitude >= disengageDistanceTarget)
				{
					do_it = true;
				}
			}

			// check if too far from home (also find the home point to move to if need to move home)
			if (disengageDistanceHome > 0.0f || do_it)
			{
				float homeDistance = 0f;
				if (idleMode == IdleMode.Stay || idleMode == IdleMode.Wander)
				{
					home = spawnLocation;
					homeDistance = (home - _tr.position).magnitude;
				}
				else if (idleMode == IdleMode.Follow)
				{
					if (followObject != null)
					{
						home = followObject.position;
						homeDistance = (home - _tr.position).magnitude;
					}
				}
				else if (idleMode == IdleMode.Patrol)
				{
					if (path != null)
					{
						home = path[currPatrolPoint].position;
						homeDistance = (home - _tr.position).magnitude;
					}
				}

				if (homeDistance >= disengageDistanceHome)
				{
					// too far from home - disengage now					
					lastDetectedCharacters = new List<DetectedTarget>();
					ClearTarget();
					RequestMoveTo(home, false);
					return;
				}
			}

			// disengage
			if (do_it)
			{
				// not too far from home, so first find a new target
				GameObject old = selectedTarget.gameObject;
				ClearTarget();
				UpdateDetection(old);

				// nothing found, go home
				if (selectedTarget == null)
				{
					RequestMoveTo(home, false);
				}
			}

		}

		private bool InRange(Vector3 targetLocation, out float distance)
		{
			Vector3 direction = targetLocation - _tr.position;
			distance = direction.magnitude;

			if (distance <= detection360Distance)
			{
				if (detectionObstacleMask != 0)
				{
					Vector3 pos = _tr.position + (obstacleCheckOffsetY * Vector3.up);
					Vector3 checkDir = ((targetLocation + (obstacleCheckOffsetY * Vector3.up)) - pos).normalized;
					if (false == Physics.Raycast(pos, checkDir, distance, detectionObstacleMask))
					{
						return true;
					}
				}
				else return true;
			}

			if (distance <= detectionForwardDistance && detectionForwardDistance != 0.0f)
			{
				if (detectionAngle >= Vector3.Angle(direction.normalized, transform.forward))
				{
					if (detectionFwObstacleMask != 0)
					{
						Vector3 pos = _tr.position + (obstacleCheckOffsetY * Vector3.up);
						Vector3 checkDir = ((targetLocation + (obstacleCheckOffsetY * Vector3.up)) - pos).normalized;
						if (false == Physics.Raycast(pos, checkDir, distance, detectionFwObstacleMask))
						{
							return true;
						}
					}
					else return true;
				}
			}

			return false;
		}
		
		// ============================================================================================================

		public override bool RequestFaceDirection(Vector3 direction, float delayAfter)
		{
			navi.FaceDirection(direction, turnSpeed);
			return true;
		}

		public override bool RequestMoveTo(Vector3 position, bool useFasterMovement)
		{
			activeMoveSpeed = useFasterMovement ? runSpeed : moveSpeed;
			navi.MoveTo(position, activeMoveSpeed, turnSpeed);
			return true;
		}

		public override float MoveSpeed()
		{
			float f = navi.DesiredVelocity().magnitude;
			if (f > activeMoveSpeed) return activeMoveSpeed;
			else return f;
		}

		public override bool Grounded()
		{
			return navi.Grounded();
		}

		public override Vector3 Velocity()
		{
			return navi.Velocity();
		}

		public override Vector3 Movement()
		{
			return navi.DesiredVelocity();
		}

		public override void OnDeath()
		{
			base.OnDeath();

			// inform spawn point that the character was killed
			if (spawnPoint != null)
			{
				spawnPoint.OnCharacterKilled(spawnGroupIdx);
			}
		}

		public override void OnRestore()
		{
			base.OnRestore();

			if (spawnPoint != null)
			{
				Debug.LogError("Restore should not be used on NPCs that where created by a Spawn Point.");
			}
		}

		public override void Stop()
		{
			navi.Stop();
		}

		private void OnHPChange(object sender, object[] args)
		{
			if (skipIfEngaged && selectedTarget != null) return;
			if (actor.actorClass.HP.lastInfluence == null) return;
			if (actor.actorClass.HP.lastConsumableValue > actor.actorClass.HP.ConsumableValue)
			{
				// HP decreased, something attacked me
				SelectTarget(actor.actorClass.HP.lastInfluence);
			}
		}

		// ============================================================================================================

		public void SetPatrolPath(WaypointPath p, int pointOnPath)
		{
			path = p;
			currPatrolPoint = pointOnPath;
			if (currPatrolPoint < 0) currPatrolPoint = 0;
			if (currPatrolPoint >= path.points.Count) currPatrolPoint = path.points.Count - 1;
		}

		// ============================================================================================================

		/// <summary>
		/// Return the total number of characters that where detected in the last detection action.
		/// </summary>
		public int LastDetectedTotal()
		{
			return lastDetectedCharacters.Count;
		}

		/// <summary>
		/// Return the detected character that is at position 'idx' in the list of detected characters. 
		/// The characters are sorted from closest to furthest from the NPC.
		/// </summary>
		public CharacterControllerBase GetDetected(int idx)
		{
			if (idx < 0 || idx >= lastDetectedCharacters.Count) return null;
			return lastDetectedCharacters[idx].chara;
		}

		/// <summary>
		/// Return distance the detected character, at index idx, is from the NPC
		/// The characters are sorted from closest to furthest from the NPC.
		/// Return -1 if index is invalid.
		/// </summary>
		public float GetDetectedDistance(int idx)
		{
			if (idx < 0 || idx >= lastDetectedCharacters.Count) return -1f;
			return lastDetectedCharacters[idx].distance;

		}

		// ============================================================================================================


		// ============================================================================================================
	}
}