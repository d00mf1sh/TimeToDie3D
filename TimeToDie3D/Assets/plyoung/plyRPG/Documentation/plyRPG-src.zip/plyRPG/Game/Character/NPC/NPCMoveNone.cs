﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> For an NPC that will not move. </summary>
	[AddComponentMenu("plyGame/Character/NPC/Movement/No-Move")]
	public class NPCMoveNone : NPCMoveBase
	{

		// ============================================================================================================
	}
}