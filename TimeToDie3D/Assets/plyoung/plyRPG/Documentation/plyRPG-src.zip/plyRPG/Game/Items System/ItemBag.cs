﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Items are things that characters can pick up and use. They can be held in this "bag".
	/// The Bag component can be placed on characters that should be able to carry items. 
	/// Bags work with either weight or slots (or no limit) as configured in ItemsAsset.storageMethod </summary>
	[System.Serializable]
	[AddComponentMenu("plyGame/Item System/Item Bag")]
	public class ItemBag : MonoBehaviour, IPersistable
	{
		public enum ItemDropOption
		{
			andDestroy, toScene, alwaysDestroy, alwaysToScene
		}

		public float maxWeight = 100f;
		public int slotsWidth = 10;
		public int slotsHeight = 5;
		public bool allowMultiStackSame = true;
		public bool autoSortOnAddRemove = false;

		public bool persistenceOn = true;

		// ============================================================================================================

		public class ItemInBag
		{
			public Item item;		//!< reference to the Item instance in the bag. for stacked items only one such instance is created.
			public int stack;		//!< stack size of this kind of item (How many in same slot)
			public int slot;		//!< slot the item is in (main slot: upper-left)
			public List<int> spanSlots = new List<int>(0);	//!< slots this item span, if bigger than one slot
		}

		public int currency { get; private set; }
		public float currWeight { get; private set; }

		public List<ItemInBag> items { get; set; }
		private ItemsAsset cfg;
		private EventHandler_Item eventHandler;

		private Transform bagTR = null;
		private int maxSlotSaveHelper = 0;

		// ============================================================================================================

		protected void Awake()
		{
			currency = 0;
			currWeight = 0.0f;
			items = new List<ItemInBag>(0);

			GameObject go = new GameObject("Item Bag");
			bagTR = go.transform;
			bagTR.parent = gameObject.transform;
			bagTR.localPosition = Vector3.zero;
		}

		protected void Start()
		{
			cfg = (ItemsAsset)GameGlobal.Instance.GetAsset<ItemsAsset>();
			eventHandler = gameObject.GetComponent<EventHandler_Item>();
		}

		// ============================================================================================================

		public void Save(string key)
		{
			//Debug.Log("Item Bag Save: " + key);
			if (!persistenceOn) return;
			string data = "";
			for (int i = 0; i < items.Count; i++)
			{
				data += items[i].item.prefabId.ToString() + (char)30 + items[i].slot.ToString() + (char)30 + items[i].stack.ToString() + (char)31;
			}

			key = key + ".bag";
			GameGlobal.SetIntKey(key + ".c", currency);
			GameGlobal.SetStringKey(key, data);
			//Debug.Log("... save: [" + key + "] => " + data);

			DeleteVarKeys(key);
			maxSlotSaveHelper = 0;

			// save variable data for each item that has such variables to save
			for (int i = 0; i < items.Count; i++)
			{
				if (maxSlotSaveHelper < items[i].slot) maxSlotSaveHelper = items[i].slot;

				// item vars are only saved when they do not stack
				if (items[i].item.maxStack <= 1 && items[i].item.blox != null)
				{
					string bagKey = key + "." + items[i].slot.ToString();
					string varData = items[i].item.blox.EncodeLocalVariables(false);
					if (false == string.IsNullOrEmpty(varData)) GameGlobal.SetStringKey(bagKey, varData);
				}
			}
		}

		public void Load(string key)
		{
			//Debug.Log("Item Bag Load: " + key);
			if (!persistenceOn) return;
			key = key + ".bag";
			currency = GameGlobal.GetIntKey(key + ".c", currency);
			string data_s = GameGlobal.GetStringKey(key, null);
			//Debug.Log("... load: [" + key + "] => " + data_s);

			// note, test for null and not empty string since if there was an empty string entry it simply mans there is nothing in the bag
			if (data_s != null)
			{
				items = new List<ItemInBag>(); // first clear bag
				string[] data = data_s.Split((char)31);
				for (int i = 0; i < data.Length; i++)
				{
					if (string.IsNullOrEmpty(data[i])) continue;
					string[] v = data[i].Split((char)30);
					if (v.Length == 3)
					{
						Item it = ItemsAsset.Instance.GetDefinition(new UniqueID(v[0]));
						int slot = int.Parse(v[1]);
						ItemInBag iib = LoadItemToBagSlot(it, slot, int.Parse(v[2]));
						if (iib != null)
						{
							if (maxSlotSaveHelper < slot) maxSlotSaveHelper = slot;

							// only bother if maxStack < 1 since this is only kind of item that can save vars
							if (iib.item.maxStack <= 1)
							{
								// decode variables if any
								string bagKey = key + "." + slot.ToString();
								string varData = GameGlobal.GetStringKey(bagKey, null);
								if (iib.item.blox != null) iib.item.blox.DecodeLocalVariables(varData);
							}
						}
					}
				}
			}
		}

		public void DeleteSaveData(string key)
		{
			if (!persistenceOn) return;
			key = key + ".bag";
			GameGlobal.DeleteKey(key);
			GameGlobal.DeleteKey(key + ".c");
			DeleteVarKeys(key);
		}

		public void DisablePersistence()
		{
			persistenceOn = false;
		}

		private void DeleteVarKeys(string key)
		{
			for (int i = 0; i < maxSlotSaveHelper; i++)
			{
				string bagKey = key + "." + i.ToString();
				GameGlobal.DeleteKey(bagKey);
			}
		}

		private ItemInBag LoadItemToBagSlot(Item itemPrefab, int addToSlot, int addStack)
		{
			if (itemPrefab == null)
			{
				Debug.LogWarning("[ItemBag] Load error: Item definition could not be found.");
				return null;
			}

			ItemInBag iib = GetItemInSlot(addToSlot);

			if (iib == null)
			{
				Item it = CreateBagItemInstance(itemPrefab);
				iib = new ItemInBag()
				{
					item = it,
					slot = addToSlot,
					stack = addStack,
				};

				if (cfg.storageMethod == ItemsAsset.StorageMethod.Slots && (it.vSlots > 1 || it.hSlots > 1))
				{
					int s = iib.slot;
					for (int y = 0; y < it.vSlots; y++)
					{
						s = iib.slot + (y * slotsWidth);
						for (int x = 0; x < it.hSlots; x++)
						{
							iib.spanSlots.Add(s);
							s++;
						}
					}
				}

				if (cfg.storageMethod == ItemsAsset.StorageMethod.Weight)
				{	// check if weight is fine
					if (it.weight + currWeight > maxWeight)
					{
						Debug.LogWarning("[ItemBag] Load error: Bag weight exceeded.");
						return null;
					}
					currWeight += it.weight;
				}

				items.Add(iib);
			}
			else
			{
				if (iib.item.prefabId != itemPrefab.prefabId)
				{
					Debug.LogWarning("[ItemBag] Load error: There is another type of Item in the specified slot.");
					return null;
				}

				if (iib.stack + addStack > iib.item.maxStack)
				{
					Debug.LogWarning("[ItemBag] Load error: The stack in the specified slot exceeded.");
					return null;
				}

				iib.stack += addStack;
			}
			return iib;
		}

		private Item CreateBagItemInstance(Item original)
		{
			Item it = Item.CreateItem(original.prefabId, Item.ItemLocation.Bag, Vector3.zero, Quaternion.identity, null);
			it.gameObject.transform.parent = bagTR;
			it.gameObject.transform.position = Vector3.zero;
			return it;
		}

		// ============================================================================================================

		/// <summary> Return the number of slots the Bag has. Even if the storage method is not slot based the Items 
		/// are still stacked in slots and this info could be useful when visually laying out the Items. </summary>
		public int GetSlotCount()
		{
			int count = 0;

			if (cfg.storageMethod == ItemsAsset.StorageMethod.Slots)
			{
				count = slotsWidth * slotsHeight;
			}
			else
			{	// find the highest number, that will be the slot count in this case
				for (int i = 0; i < items.Count; i++)
				{
					if (items[i].slot > count) count = items[i].slot;
				}
			}

			return count;
		}

		public void ChangeMaxWeightBy(int val)
		{
			if (cfg.storageMethod != ItemsAsset.StorageMethod.Weight)
			{
				Debug.LogWarning("The bag is not using a weight based system. Check items storage method setting.");
				return;
			}

			maxWeight += val;
		}

		// ============================================================================================================

		/// <summary> Add an amount of currency. </summary>
		public void AddCurrency(int amount)
		{
			if (amount < 0) amount *= -1;
			currency += amount;

			// call event on bag
			if (eventHandler)
			{
				eventHandler.OnCurrencyAddedToBag(new EventHandler_Item.Message()
				{
					slot = amount, // hi-jack slot var to hold amount value
					owner = gameObject
				});
			}
		}

		/// <summary> Remove an amount of currency. Return false if did not have enough currency and thus nothing was done. </summary>
		public bool RemoveCurrency(int amount)
		{
			if (amount < 0) amount *= -1;
			if (currency < amount) return false;
			currency -= amount;

			// call event on bag
			if (eventHandler)
			{
				eventHandler.OnCurrencyRemovedFromBag(new EventHandler_Item.Message()
				{
					slot = amount, // hi-jack slot var to hold amount value
					owner = gameObject
				});
			}

			return true;
		}

		/// <summary> Return true if has an amount of currency. </summary>
		public bool HasCurrencyAmount(int amount)
		{
			return currency >= amount;
		}

		// ============================================================================================================

		public void AddItemToBag(Item it, int count)
		{
			if (it == null) return;
			if (count <= 0) return;
			for (int i = 0; i < count; i++)
			{
				if (false == AddItemToBag(it)) return;
			}
		}

		/// <summary> Add a copy of the item to the bag. Return false if failed to add, perhaps bag is full. </summary>
		public bool AddItemToBag(Item it)
		{
			if (it == null) return false;
			if (autoSortOnAddRemove) Sort();

			// check if there is existing stack that it can be added to
			// done here since the slots space check can use the info
			// or check if allowMultiStackSame not allowed
			int addToStack = -1;
			bool hasStack = false;
			ItemInBag iib = null;
			if (it.maxStack > 1 || !allowMultiStackSame)
			{
				for (int i = 0; i < items.Count; i++)
				{
					if (items[i].item.prefabId == it.prefabId)
					{
						hasStack = true;
						if (it.maxStack > 1)
						{
							if (items[i].stack < it.maxStack) 
							{
								addToStack = i;
								break;
							}
						}
						if (!allowMultiStackSame) break;
					}
				}
			}

			if (addToStack >= 0)
			{
				if (cfg.storageMethod == ItemsAsset.StorageMethod.Weight)
				{	// check if weight is fine
					if (it.weight + currWeight > maxWeight) return false;
					currWeight += it.weight;
				}

				items[addToStack].stack++;
				iib = items[addToStack];
			}
			else
			{
				if (!allowMultiStackSame && hasStack) return false; // do not allow new stack to be created
				int addToSlot = FindBagSlotFor(it);
				if (addToSlot < 0) return false;

				if (cfg.storageMethod == ItemsAsset.StorageMethod.Weight)
				{	// check if weight is fine
					if (it.weight + currWeight > maxWeight) return false;
					currWeight += it.weight;
				}

				// Create bag item instance
				Item itemInstance = CreateBagItemInstance(it);

				// Copy variables and restore State
				if (itemInstance.blox != null && it.blox != null)
				{
					foreach (plyVar v in it.blox.LocalVars.Values) itemInstance.blox.SetLocalVarValue(v.name, v.GetValue());
					itemInstance.blox.SetCurrentState(it.blox.CurrentState, true);
				}

				iib = new ItemInBag()
				{
					item = itemInstance,
					slot = addToSlot,
					stack = 1
				};

				if (cfg.storageMethod == ItemsAsset.StorageMethod.Slots && (it.vSlots > 1 || it.hSlots > 1))
				{
					int s = iib.slot;
					for (int y = 0; y < it.vSlots; y++)
					{
						s = iib.slot + (y * slotsWidth);
						for (int x = 0; x < it.hSlots; x++)
						{
							iib.spanSlots.Add(s);
							s++;
						}
					}
				}

				items.Add(iib);
			}

			if (maxSlotSaveHelper < iib.slot) maxSlotSaveHelper = iib.slot;

			// queue events to be triggered
			EventHandler_Item.Message msg = new EventHandler_Item.Message()
			{
				slot = iib.slot,
				item = iib.item,
				owner = gameObject
			};

			StartCoroutine("TriggePickupEvent", msg);
			
			return true;
		}

		/// <summary> Remove 1 copy of the item from bag. return false if item not found. use one of the other
		/// functions if you want better control over which item in bag is removed since this will grab the
		/// first one that is valid. </summary>
		public bool RemoveItemFromBag(Item it, ItemDropOption opt, bool triggerEvents)
		{
			ItemInBag iib = FindItem(it);
			return RemoveItemFromBag(iib, opt, triggerEvents);
		}

		/// <summary> Remove 1 copy of the item from the specific bag slot. return false if failed - item not found in slot. </summary>
		public bool RemoveItemFromBag(int bagSlot, ItemDropOption opt, bool triggerEvents)
		{
			ItemInBag iib = GetItemInSlot(bagSlot);
			return RemoveItemFromBag(iib, opt, triggerEvents);
		}

		/// <summary> Remove 1 copy of the item from bag. return false if item not found. </summary>
		public bool RemoveItemFromBag(ItemInBag iib, ItemDropOption opt, bool triggerEvents)
		{
			if (iib == null) return false;
			if (items.Contains(iib))
			{
				GameObject destroyInstance = null;
				Item droppedItem = iib.item;
				iib.stack--;
				if (iib.stack <= 0)
				{
					destroyInstance = iib.item.gameObject;
					items.Remove(iib);
				}

				currWeight -= iib.item.weight;
				if (currWeight < 0) currWeight = 0;

				// create Item in scene. in front of bag owner.
				if (opt == ItemDropOption.toScene || opt == ItemDropOption.alwaysToScene)
				{
					Vector3 startPos = transform.position + (Vector3.up * 1.5f);
					Item it = Item.CreateItem(iib.item.prefabId, Item.ItemLocation.Scene, startPos, Quaternion.identity, null, true, transform.forward);
					if (it == null) return false;

					// check if should restore the item's local variables
					if (iib.item.maxStack <= 1 && iib.item.blox != null)
					{
						GameObject go = it.gameObject;
						plyBlox targetBlox = go.GetComponent<plyBlox>();
						if (targetBlox != null)
						{
							PersistableObject p = go.GetComponent<PersistableObject>();
							if (p != null)
							{
								foreach (plyVar v in iib.item.blox.LocalVars.Values) targetBlox.SetLocalVarValue(v.name, v.GetValue());								
							}
							targetBlox.SetCurrentState(iib.item.blox.CurrentState, true);
						}
					}
				}

				// trigger events
				if (triggerEvents)
				{
					EventHandler_Item.Message msg = new EventHandler_Item.Message()
					{
						slot = iib.slot,
						item = droppedItem,
						owner = gameObject
					};

					// call event on bag
					if (eventHandler) eventHandler.OnItemRemovedFromBag(msg);

					// call event on item
					if (msg.item.eventHandler) msg.item.eventHandler.OnItemRemovedFromBag(msg);
				}

				// destroy instance of item in bag
				if (destroyInstance != null)
				{
					Destroy(destroyInstance);
				}

				if (autoSortOnAddRemove) Sort();
				return true;
			}
			return false;
		}

		private IEnumerator TriggePickupEvent(EventHandler_Item.Message msg)
		{
			// skip two frames to give Item chance to init properly
			yield return null;
			yield return null;

			// call event on Bag
			if (eventHandler) eventHandler.OnItemAddedToBag(msg);

			// call event on item
			if (msg.item.eventHandler) msg.item.eventHandler.OnItemAddedToBag(msg);
		}

		/// <summary> Return the item at specified slot or slot occupied by an item 
		/// that spans more than one slot. Null if no Item available. </summary>
		public ItemInBag GetItemInSlot(int bagSlot)
		{
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].slot == bagSlot) return items[i];
				// dont do the following as it makes it harder for designer to figure out if an item should go in the slot
				//if (cfg.storageMethod == ItemsAsset.StorageMethod.Slots)
				//{	
				//	// check if item span the specified slot
				//	for (int j = 0; j < items[i].spanSlots.Count; j++)
				//	{
				//		if (items[i].spanSlots[j] == bagSlot) return items[i];
				//	}
				//}
			}
			return null;
		}

		/// <summary> Return first occurrence of Item in Bag. Null if not found. </summary>
		public ItemInBag FindItem(Item it)
		{
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].item.prefabId == it.prefabId)
				{
					return items[i];
				}
			}
			return null;
		}

		/// <summary> Return first occurrence of Item in Bag. Null if not found. </summary>
		public ItemInBag FindItem(UniqueID itemFabId)
		{
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].item.prefabId == itemFabId)
				{
					return items[i];
				}
			}
			return null;
		}

		/// <summary> Return how many copies of the Item is present in the Bag.</summary>
		public int ItemCount(Item it)
		{
			int cnt = 0;
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].item.prefabId == it.prefabId) cnt += items[i].stack;
			}
			return cnt;
		}

		/// <summary> Return True if at least one copy of the Item exist in the Bag.</summary>
		public bool HasItem(Item it)
		{
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].item.prefabId == it.prefabId) return true;
			}
			return false;
		}

		// ============================================================================================================

		/// <summary> Will check if the item exists and then use it. Will return false if failed (for example item not found)
		/// Will only trigger use if item is equipped when set to canEquip. Will only trigger use on item in bag if 
		/// not set to canEquip. </summary>
		public bool UseItem(Item it)
		{
			ItemInBag iib = FindItem(it);
			return UseItem(iib);
		}

		public bool UseItem(UniqueID itemFabId)
		{
			ItemInBag iib = FindItem(itemFabId);
			return UseItem(iib);
		}

		/// <summary> Trigger use on specific Item in bag </summary>
		public bool UseItem(int bagSlot)
		{
			ItemInBag iib = GetItemInSlot(bagSlot);
			return UseItem(iib);
		}

		/// <summary> Trigger use on specific Item in bag </summary>
		public bool UseItem(ItemInBag iib)
		{
			if (iib == null) return false;
			if (false == items.Contains(iib)) return false;

			EventHandler_Item.Message msg = new EventHandler_Item.Message()
			{
				slot = iib.slot,
				item = iib.item,
				owner = gameObject
			};

			// call event on Bag
			if (eventHandler) eventHandler.OnItemUse(msg);

			// call event in item
			if (msg.item.eventHandler) msg.item.eventHandler.OnItemUse(msg);

			// remove from bag, triggering remove events
			if (iib.item.consumeOnUse)
			{
				RemoveItemFromBag(iib, ItemDropOption.andDestroy, true);
			}

			return true;
		}

		public void Sort()
		{
			bool found;
			bool done;
			int slot;
			do
			{
				done = true;

				// find an open slot that can be used
				slot = 0;
				do
				{
					found = true;
					for (int i = 0; i < items.Count; i++)
					{
						if (items[i].slot == slot)
						{
							found = false;
							slot++;
							break;
						}
					}
				} while (!found);

				// find first item that is above this slot number
				ItemInBag it = null;
				for (int i = 0; i < items.Count; i++)
				{
					if (items[i].slot > slot)
					{
						it = items[i];
						break;
					}
				}

				// place item in new slot
				if (it != null)
				{
					done = false; // might be more to sort
					it.slot = slot;
				}

			} while (!done);

			maxSlotSaveHelper = 0;
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].slot > maxSlotSaveHelper) maxSlotSaveHelper = items[i].slot;
			}
		}

		public bool IsFull()
		{
			if (cfg.storageMethod == ItemsAsset.StorageMethod.Weight)
			{
				return (currWeight >= maxWeight); // full if curr weight is equal to max
			}
			else if (cfg.storageMethod == ItemsAsset.StorageMethod.Slots)
			{
				int max = slotsWidth * slotsHeight;
				for (int i = 0; i < max; i++)
				{
					if (BagSlotIsOpen(i)) return false; // not full
				}
				return true; // is full
			}

			return false; // not full
		}

		// ============================================================================================================

		private int FindBagSlotFor(Item it)
		{
			if (cfg.storageMethod == ItemsAsset.StorageMethod.Slots)
			{
				// find a slot for the item, also checking if item will fit into space if need more than one slot
				int slot = 0;
				for (int y = 0; y < slotsHeight; y++)
				{
					for (int x = 0; x < slotsWidth; x++)
					{
						if (BagSlotIsOpen(slot))
						{	// this 'starting' slot is open, now check if item will fit if using more than one slot
							if (it.hSlots > 1 || it.vSlots > 1)
							{
								if (y + it.vSlots >= slotsHeight) return -1; // reached bottom and item will not fit
								if (x + it.hSlots <= slotsWidth)
								{	// not over side of bag yet
									return slot;
								}
							}
							else
							{
								return slot;
							}
						}
						slot++;
					}
				}
				return -1;
			}
			else
			{
				// for other storage methods the items takes up only one slot at a time
				// find first open slot for the item. simply increase counter and check
				// each time against stored items till an open slot number is found
				int slot = 0;
				bool done = true;
				do
				{
					done = true;
					for (int i = 0; i < items.Count; i++)
					{
						if (slot == items[i].slot)
						{
							slot++;
							done = false;
							break;
						}
					}
				} while (!done);
				return slot;
			}
		}

		private bool BagSlotIsOpen(int slot)
		{
			if (slot >= slotsWidth * slotsHeight) return false;

			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].slot == slot) return false;
				if (items[i].item.vSlots > 1 || items[i].item.hSlots > 1)
				{
					int s = 0;
					for (int y = 0; y < items[i].item.vSlots; y++)
					{
						s = (items[i].slot + (y * slotsWidth));
						if (slot == s) return false;
						if (items[i].item.hSlots > 1)
						{
							for (int x = 1; x < items[i].item.hSlots; x++)
							{
								s++;
								if (slot == s) return false;
							}
						}
					}
				}
			}
			return true;
		}

		// ============================================================================================================
	}
}
