﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("plyGame/Objects/Interact Object")]
	public class InteractObject : Targetable
	{
		public CommonDefinitionData def = new CommonDefinitionData();	//!< common data

		// ============================================================================================================

		protected void Reset()
		{
			gameObject.layer = GameGlobal.LayerMapping.plyObject;
		}

		protected void Awake()
		{
			gameObject.layer = GameGlobal.LayerMapping.plyObject;
		}

		public override Type TargetableType()
		{
			return Type.Object;
		}

		public override object DataObject()
		{
			return this;
		}

		// ============================================================================================================
	}
}