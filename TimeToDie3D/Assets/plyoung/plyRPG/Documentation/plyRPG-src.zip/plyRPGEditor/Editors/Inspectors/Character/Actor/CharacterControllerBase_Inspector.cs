﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	public class CharacterControllerBase_Inspector : Editor
	{
		private CharacterControllerBase Target;

		// --------------------------------------------

		protected void OnEnable()
		{
			Target = (CharacterControllerBase)target;
			if (Target.persistenceOn)
			{	// make sure the PersistableObject is present
				PersistableObject p = Target.gameObject.GetComponent<PersistableObject>();
				if (p == null)
				{
					Target.gameObject.AddComponent<PersistableObject>();
					EditorUtility.SetDirty(Target.gameObject);
				}
			}
		}

		public override void OnInspectorGUI()
		{
			plyEdGUI.UseSkin();

			Target = (CharacterControllerBase)target;
			PersistenceInfo();

			if (Target.persistenceOn)
			{
				EditorGUI.indentLevel--;
				plyEdGUI.HLine(0);
			}

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}

			DrawDefaultInspector();
		}

		protected virtual void PersistenceInfo()
		{
			EditorGUI.BeginChangeCheck();
			Target.persistenceOn = EditorGUILayout.Toggle("Persistence On", Target.persistenceOn);
			if (EditorGUI.EndChangeCheck())
			{
				if (Target.persistenceOn)
				{	// make sure the PersistableObject is present
					PersistableObject p = Target.gameObject.GetComponent<PersistableObject>();
					if (p == null)
					{
						Target.gameObject.AddComponent<PersistableObject>();
						EditorUtility.SetDirty(Target.gameObject);
					}
				}
			}

			if (Target.persistenceOn)
			{
				EditorGUI.indentLevel++;
				Target.persistSpeed = EditorGUILayout.Toggle("Speed Data", Target.persistSpeed);
			}
		}

		// ============================================================================================================
	}
}
