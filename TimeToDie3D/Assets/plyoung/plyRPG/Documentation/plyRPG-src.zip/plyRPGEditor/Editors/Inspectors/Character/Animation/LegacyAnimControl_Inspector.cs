﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(LegacyAnimControl))]
	public class LegacyAnimControl_Inspector : Editor
	{

		private LegacyAnimControl Target;
		private string[] clips = new string[0];
		
		private LegacyAnimGroup curr = null;
		private int currSel = 0;
		private string[] groupNames = new string[0];

		private GUIContent GC_Add_AnimDef;

		protected void OnEnable() 
		{
			Target = (LegacyAnimControl)target;
			if (Target.ani != null) UpdateAniClipCache(Target.ani.gameObject);

			if (Target.aniGroups.Count == 0)
			{
				LegacyAnimGroup gr = new LegacyAnimGroup();
				gr.name = "Default";
				gr.deathAnim.wrapMode = WrapMode.Once;
				gr.jumpAnim.wrapMode = WrapMode.Once;
				gr.fallAnim.wrapMode = WrapMode.Once;
				gr.landAnim.wrapMode = WrapMode.Once;
				gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Walk", speedDetect = 4 });
				gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Run", speedDetect = 999 });
				Target.aniGroups.Add(gr);
				EditorUtility.SetDirty(target);
			}

			curr = Target.aniGroups[0];

			groupNames = new string[Target.aniGroups.Count];
			for (int i=0; i < Target.aniGroups.Count; i++) groupNames[i] = Target.aniGroups[i].name;
		}

		private void CheckGUIContent()
		{
			plyEdGUI.UseSkin();
			if (GC_Add_AnimDef == null)
			{
				GC_Add_AnimDef = new GUIContent(" Add Movement Definition", FA.Ico12(FA.plus, plyEdGUI.IconColor));
			}
		}
		
		public override void OnInspectorGUI()
		{
			CheckGUIContent();
			Target = (LegacyAnimControl)target;

			EditorGUI.BeginChangeCheck();
			Target.ani = (Animation)EditorGUILayout.ObjectField("Animation", Target.ani, typeof(Animation), true);
			if (EditorGUI.EndChangeCheck())
			{
				if (Target.ani != null) UpdateAniClipCache(Target.ani.gameObject);
			}

			Target.chara = (CharacterControllerBase)EditorGUILayout.ObjectField("Character Controller", Target.chara, typeof(CharacterControllerBase), true);
			Target.minSpeedDetect = EditorGUILayout.FloatField("Min Speed Detect", Target.minSpeedDetect);
			Target.useBodyRot = EditorGUILayout.Toggle("Use low-body rotation", Target.useBodyRot);
			if (Target.useBodyRot)
			{
				Target.bip = (Transform)EditorGUILayout.ObjectField("Hub/ Bip", Target.bip, typeof(Transform), true);
				Target.spine = (Transform)EditorGUILayout.ObjectField("Upper Spine", Target.spine, typeof(Transform), true);
			}
			EditorGUILayout.Space();

			EditorGUILayout.BeginHorizontal();
			{
				currSel = EditorGUILayout.Popup(currSel, groupNames);
				curr = Target.aniGroups[currSel];
				if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.IconButtonLeftStyle, GUILayout.Width(25)))
				{
					plyTextInputWiz.ShowWiz("Add Animation Group", "Enter a unique name", "", AddAniGroup, new object[] { target } );
				}

				if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.IconButtonMidStyle, GUILayout.Width(25)))
				{
					if (Target.aniGroups.Count == 1)
					{
						EditorUtility.DisplayDialog("Error", "Can't remove. There must be at least one animation group defined.", "OK");
					}
					else
					{
						Target.aniGroups.RemoveAt(currSel);
						EditorUtility.SetDirty(Target);
						if (currSel >= Target.aniGroups.Count) currSel--;
						curr = Target.aniGroups[currSel];
						groupNames = new string[Target.aniGroups.Count];
						for (int i = 0; i < Target.aniGroups.Count; i++) groupNames[i] = Target.aniGroups[i].name;
					}
				}

				if (GUILayout.Button(plyEdGUI.GC_Rename, plyEdGUI.IconButtonRightStyle, GUILayout.Width(25)))
				{
					plyTextInputWiz.ShowWiz("Rename Animation Group", "Enter a unique name", curr.name, RenameAniGroup, new object[] { target });
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Animation", EditorStyles.largeLabel, GUILayout.Width(110));
				GUILayout.Label("Clip", EditorStyles.largeLabel, GUILayout.MinWidth(70));
				GUILayout.Label("Mode", EditorStyles.largeLabel, GUILayout.Width(70));
				GUILayout.Label("Speed", EditorStyles.largeLabel, GUILayout.Width(50));
				GUILayout.Label("R", EditorStyles.largeLabel, GUILayout.Width(20));
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.DrawHorizontalLine(1, 0, plyEdGUI.DividerColor, plyEdGUI.HLineStyle, 1, 5);

			AnimClipDef("Idle", curr.idleAnim);
			AnimClipDef("Death", curr.deathAnim);
			AnimClipDef("Jump", curr.jumpAnim);
			AnimClipDef("Fall", curr.fallAnim);
			AnimClipDef("Land", curr.landAnim);
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Space(15);
				plyEdGUI.LookLikeControls(100, 40);
				curr.jumpDelay = EditorGUILayout.FloatField("Jump delay", curr.jumpDelay);
				GUILayout.Space(10);
				plyEdGUI.LookLikeControls(105, 40);
				curr.landMoveMulti = EditorGUILayout.FloatField("Land-Move Multi", curr.landMoveMulti);
				plyEdGUI.LookLikeControls(0, 0);
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.DrawHorizontalLine(1, 0, plyEdGUI.DividerColor, plyEdGUI.HLineStyle, 1, 5);

			int del = -1;
			for (int i = 0; i < curr.moveDefs.Count; i++)
			{
				EditorGUILayout.BeginHorizontal();
				{
					if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle))
					{
						del = i;
					}
					GUILayout.Space(5);
					if (GUILayout.Button(plyEdGUI.GC_Rename, plyEdGUI.FlatIconButtonSmallStyle))
					{
						plyTextInputWiz.ShowWiz("Rename Movement Definition", "Enter unique definition name", curr.moveDefs[i].name, OnInputDefName, new object[] { 1, curr.moveDefs[i] });
					}
					GUILayout.Space(5);
					GUILayout.Label(curr.moveDefs[i].name);
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.BeginHorizontal();
				{
					plyEdGUI.LookLikeControls(105, 60);
					GUILayout.Space(10);
					curr.moveDefs[i].speedDetect = EditorGUILayout.FloatField("Speed Detect", curr.moveDefs[i].speedDetect);
					GUILayout.FlexibleSpace();
					plyEdGUI.LookLikeControls(0, 0);
				}
				EditorGUILayout.EndHorizontal();

				AnimClipDef("Forward", curr.moveDefs[i].forward);
				AnimClipDef("Forward Right", curr.moveDefs[i].forwardRight);
				AnimClipDef("Forward Left", curr.moveDefs[i].forwardLeft);

				if (Target.useBodyRot)
				{
					EditorGUILayout.BeginHorizontal();
					{
						GUILayout.Space(15);
						plyEdGUI.LookLikeControls(115, 40);
						curr.moveDefs[i].lrfRotateBody = EditorGUILayout.Toggle("Use body-rotation", curr.moveDefs[i].lrfRotateBody);
						GUILayout.Space(10);
						GUI.enabled = curr.moveDefs[i].lrfRotateBody;
						plyEdGUI.LookLikeControls(70, 40);
						curr.moveDefs[i].lrfMaxAngle = EditorGUILayout.FloatField("Max angle", curr.moveDefs[i].lrfMaxAngle);
						GUI.enabled = true;
						plyEdGUI.LookLikeControls(0, 0);
						GUILayout.FlexibleSpace();
					}
					EditorGUILayout.EndHorizontal();
				}

				GUILayout.Space(2);
				AnimClipDef("Backward", curr.moveDefs[i].backward);
				AnimClipDef("Backward Right", curr.moveDefs[i].backwardRight);
				AnimClipDef("Backward Left", curr.moveDefs[i].backwardLeft);

				if (Target.useBodyRot)
				{
					EditorGUILayout.BeginHorizontal();
					{
						GUILayout.Space(15);
						plyEdGUI.LookLikeControls(115, 40);
						curr.moveDefs[i].lrbRotateBody = EditorGUILayout.Toggle("Use body-rotation", curr.moveDefs[i].lrbRotateBody);
						GUILayout.Space(10);
						GUI.enabled = curr.moveDefs[i].lrbRotateBody;
						plyEdGUI.LookLikeControls(70, 40);
						curr.moveDefs[i].lrbMaxAngle = EditorGUILayout.FloatField("Max angle", curr.moveDefs[i].lrbMaxAngle);
						GUI.enabled = true;
						plyEdGUI.LookLikeControls(0, 0);
						GUILayout.FlexibleSpace();
					}
					EditorGUILayout.EndHorizontal();
				}

				plyEdGUI.DrawHorizontalLine(1, 0, plyEdGUI.DividerColor, plyEdGUI.HLineStyle);
			}

			if (GUILayout.Button(GC_Add_AnimDef, GUILayout.Width(180)))
			{
				plyTextInputWiz.ShowWiz("Add Movement Definition", "Enter unique definition name", "", OnInputDefName, new object[] { 0 });
			}
			EditorGUILayout.Space();

			if (del >= 0)
			{
				curr.moveDefs.RemoveAt(del);
				EditorUtility.SetDirty(target);
			}
		
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		private void AddAniGroup(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s))
			{
				Target = (LegacyAnimControl)args[0];
				bool found = false;
				for (int i = 0; i < Target.aniGroups.Count; i++)
				{
					if (Target.aniGroups[i].name.Equals(s)) { found = true; break; }
				}

				if (!found)
				{
					LegacyAnimGroup gr = new LegacyAnimGroup();
					gr.name = s;
					gr.deathAnim.wrapMode = WrapMode.Once;
					gr.jumpAnim.wrapMode = WrapMode.Once;
					gr.fallAnim.wrapMode = WrapMode.Once;
					gr.landAnim.wrapMode = WrapMode.Once;
					gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Walk", speedDetect = 4 });
					gr.moveDefs.Add(new LegacyAnimMoveDef() { name = "Run", speedDetect = 999 });
					Target.aniGroups.Add(gr);
					EditorUtility.SetDirty(Target);

					currSel = Target.aniGroups.Count - 1;
					curr = Target.aniGroups[currSel];
					groupNames = new string[Target.aniGroups.Count];
					for (int i = 0; i < Target.aniGroups.Count; i++) groupNames[i] = Target.aniGroups[i].name;
				}
				else EditorUtility.DisplayDialog("Error", "The group name must be unique", "OK");
			}

			Repaint();
		}

		private void RenameAniGroup(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s) && !curr.name.Equals(s))
			{
				Target = (LegacyAnimControl)args[0];
				bool found = false;
				for (int i = 0; i < Target.aniGroups.Count; i++)
				{
					if (Target.aniGroups[i].name.Equals(s)) { found = true; break; }
				}

				if (!found)
				{
					curr.name = s;
					EditorUtility.SetDirty(Target);
					groupNames = new string[Target.aniGroups.Count];
					for (int i = 0; i < Target.aniGroups.Count; i++) groupNames[i] = Target.aniGroups[i].name;
				}
				else EditorUtility.DisplayDialog("Error", "The group name must be unique", "OK");
			}

			Repaint();
		}

		private void AnimClipDef(string label, LegacyAnimClipDef def)
		{
			EditorGUIUtility.labelWidth = 105;
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Space(10);
				EditorGUILayout.PrefixLabel(label);

				def.clipName = EditorGUILayout.TextField(def.clipName, plyEdGUI.TextFieldNoLRMarginStyle);
				int sel = EditorGUILayout.Popup(-1, clips, EditorStyles.miniButtonRight, GUILayout.Width(20));
				if (sel >= 0)
				{
					def.clipName = clips[sel];
					GUI.changed = true;
				}

				def.wrapMode = (WrapMode)EditorGUILayout.EnumPopup(def.wrapMode, GUILayout.Width(70));
				def.playbackSpeed = EditorGUILayout.FloatField(def.playbackSpeed, GUILayout.Width(50));
				def.reverse = EditorGUILayout.Toggle(def.reverse, GUILayout.Width(20));
			}
			EditorGUILayout.EndHorizontal();
			EditorGUIUtility.labelWidth = 0;
		}

		private void UpdateAniClipCache(GameObject go)
		{
			if (go == null)
			{
				clips = new string[0];
				return;
			}

#if UNITY5
			Animation a = go.GetComponent<Animation>();
			if (a != null)
			{
				List<string> tmp = new List<string>();
				foreach (AnimationState state in a)
				{
					tmp.Add(state.name);
				}
				clips = tmp.ToArray();
			}
			else
			{
				clips = new string[0];
			}
#else
			if (go.animation != null)
			{
				List<string> tmp = new List<string>();
				foreach (AnimationState state in go.animation)
				{
					tmp.Add(state.name);
				}
				clips = tmp.ToArray();
			}
			else
			{
				clips = new string[0];
			}
#endif
		}

		private void OnInputDefName(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (string.IsNullOrEmpty(s)) return;

			int opt = (int)args[0];
			if (opt == 0)	// new
			{
				for (int i = 0; i < curr.moveDefs.Count; i++)
				{
					if (curr.moveDefs[i].name == s)
					{
						EditorUtility.DisplayDialog("Error!", "You need to enter a unique name.", "Close");
						return;
					}
				}

				curr.moveDefs.Add(new LegacyAnimMoveDef() { name = s });
			}
			else			// rename
			{
				LegacyAnimMoveDef def = (LegacyAnimMoveDef)args[1];
				if (def.name == s) return; // did not actually rename
				for (int i = 0; i < curr.moveDefs.Count; i++)
				{
					if (curr.moveDefs[i].name == s)
					{
						EditorUtility.DisplayDialog("Error!", "You need to enter a unique name.", "Close");
						return;
					}
				}

				def.name = s;
			}

			plyEdGUI.ClearFocus();
			EditorUtility.SetDirty(target);
			Repaint();
		}

		// ============================================================================================================
	}
}
