﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(EquipmentSlots))]
	public class EquipSlots_Inspector : Editor
	{
		private static bool showDebugInfo = false;
		private ItemsAsset asset;

		protected void OnEnable()
		{
			if (asset == null)
			{
				asset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "items.asset", "Item Definitions");
			}
		}

		public override void OnInspectorGUI()
		{
			plyEdGUI.UseSkin();
			EquipmentSlots Target = (EquipmentSlots)target;

			Target.persistenceOn = EditorGUILayout.Toggle("Persistence On", Target.persistenceOn);

			if (GUI.changed)
			{
				EditorUtility.SetDirty(target);
				GUI.changed = false;
			}

			if (false == EditorApplication.isPlaying) return;

			GUI.color = Color.red;
			if (plyEdGUI.ToggleButton(showDebugInfo, "Show Debug Info", GUI.skin.button)) showDebugInfo = !showDebugInfo;
			GUI.color = Color.white;

			if (false == showDebugInfo) return;

			EditorGUILayout.BeginVertical(GUI.skin.box);
			{
				plyEdGUI.SectionHeading("Equipped");
				EditorGUI.indentLevel++;
				for (int i = 0; i < asset.equipSlots.Count; i++)
				{
					string itemName = "-";
					if (Target.items != null)
					{
						for (int j = 0; j < Target.items.Count; j++)
						{
							if (Target.items[j].slot == i)
							{
								itemName = Target.items[j].item.def.screenName;
								break;
							}
						}
					}

					EditorGUILayout.LabelField((i < 10 ? "0" : "") + i.ToString() + ": " + asset.equipSlots[i], itemName);
				}
				EditorGUI.indentLevel--;
			}
			EditorGUILayout.EndVertical();
			Repaint();
		}
	}
}
