﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(ItemInScene))]
	public class ItemInScene_Inspector : Editor
	{
		public override void OnInspectorGUI()
		{
		}
	}
}
