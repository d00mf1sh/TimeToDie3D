﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[CustomEditor(typeof(Item))]
	public class Item_Inspector : Editor
	{
		private ItemsAsset _itemsAsset = null;
		private ItemsAsset itemsAsset
		{
			get
			{
				if (_itemsAsset == null)
				{
					DataAsset dataAsset = EdGlobal.GetDataAsset();
					_itemsAsset = (ItemsAsset)dataAsset.GetAsset<ItemsAsset>();
					if (_itemsAsset == null)
					{
						_itemsAsset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "items.asset", "Items System");
						if (dataAsset.AddAsset(_itemsAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
				return _itemsAsset;
			}
		}

		private Item Target;
		private Object prefabLink = null;
		private bool doListCheck = true;
		private int activeImg = 0;
		private int imgEd = 0;

		private string[] itemTypes = new string[0];
		private string[] itemSubTypes = new string[0];
		private string[] slotNames = new string[0];

		private static GUIContent GC_SlotOff;
		private static GUIContent GC_SlotOn;
		private static GUIStyle SlotStyle;
		private UniqueID prefabUniqueId = null;

		protected void OnEnable()
		{
			Target = (Item)target;

			if (false == EditorUtility.IsPersistent(target))
			{
				Item fab = PrefabUtility.GetPrefabParent(target) as Item;
				if (fab != null) prefabUniqueId = fab.prefabId;
			}

			if (UniqueIDManager.CheckID(target, ref prefabLink, ref Target.prefabId, prefabUniqueId, true, false))
			{
				EditorUtility.SetDirty(target);
			}

			UpdatePopupText();

			if (Target.persistenceOn)
			{	// make sure the PersistableObject is present
				PersistableObject p = Target.gameObject.GetComponent<PersistableObject>();
				if (p == null)
				{
					Target.gameObject.AddComponent<PersistableObject>();
					EditorUtility.SetDirty(Target.gameObject);
				}
			}

			// should check if this item is in list and if not, add it
			doListCheck = true;
		}

		private void UpdatePopupText()
		{
			if (slotNames.Length != itemsAsset.equipSlots.Count)
			{
				slotNames = itemsAsset.equipSlots.ToArray();
			}

			if (itemTypes.Length != itemsAsset.itemTypes.Count)
			{
				itemTypes = new string[itemsAsset.itemTypes.Count];
				for (int i = 0; i < itemsAsset.itemTypes.Count; i++)
				{
					itemTypes[i] = itemsAsset.itemTypes[i].name;
				}
			}

			if (Target.itemType >= 0 && Target.itemType < itemTypes.Length)
			{
				if (itemSubTypes.Length != itemsAsset.itemTypes[Target.itemType].subTypes.Count)
				{
					itemSubTypes = new string[itemsAsset.itemTypes[Target.itemType].subTypes.Count];
					for (int i = 0; i < itemsAsset.itemTypes[Target.itemType].subTypes.Count; i++)
					{
						itemSubTypes[i] = itemsAsset.itemTypes[Target.itemType].subTypes[i];
					}
				}
			}
			else itemSubTypes = new string[0];
		}

		private void InitGUI()
		{
			UpdatePopupText();
			plyEdGUI.UseSkin();
			if (SlotStyle == null)
			{
				GC_SlotOff = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.itemslots_0.png", typeof(EdGlobal).Assembly));
				GC_SlotOn = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.itemslots_1.png", typeof(EdGlobal).Assembly));
				SlotStyle = new GUIStyle()
				{
					padding = new RectOffset(0, 0, 0, 0),
					margin = new RectOffset(0, 0, 0, 0)
				};
			}
		}

		public override void OnInspectorGUI()
		{
			Target = (Item)target;
			InitGUI();

			if (doListCheck && plyRPGEdGlobal.edData != null)
			{
				// needed to wait for edData to become valid as it is loaded later
				doListCheck = false;
				CheckItemFab(Target);
			}

			if (UniqueIDManager.CheckID(target, ref prefabLink, ref Target.prefabId, prefabUniqueId, false, false))
			{
				EditorUtility.SetDirty(target);
			}

			PersistenceInfo();
			CommonDefinitionDataDrawer.Draw(Target.def, ref activeImg);
			plyEdGUI.HLine(1, 5); 
			ItemInfo();

			EditorGUILayout.Space();
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		private void PersistenceInfo()
		{
			EditorGUI.BeginChangeCheck();
			Target.persistenceOn = EditorGUILayout.Toggle("Persistence On", Target.persistenceOn);
			if (EditorGUI.EndChangeCheck())
			{
				if (Target.persistenceOn)
				{	// make sure the PersistableObject is present
					PersistableObject p = Target.gameObject.GetComponent<PersistableObject>();
					if (p == null)
					{
						Target.gameObject.AddComponent<PersistableObject>();
						EditorUtility.SetDirty(Target.gameObject);
					}
				}
			}
		}

		private void CheckItemFab(Item it)
		{
			Object obj = EditorUtility.IsPersistent(it) ? it : PrefabUtility.GetPrefabParent(it);
			if (obj != null)
			{
				it = (Item)obj;
				if (false == itemsAsset.itemFabs.Contains(it.gameObject))
				{
					itemsAsset.itemFabs.Add(it.gameObject);
					EditorUtility.SetDirty(itemsAsset);
					itemsAsset.UpdateItemCache();
				}
			}
		}

		private void ItemInfo()
		{
			EditorGUI.BeginChangeCheck();
			Target.itemType = plyEdGUI.Popup("Type", Target.itemType, itemTypes);
			if (EditorGUI.EndChangeCheck())
			{
				GUI.changed = true;
				if (Target.itemType < 0)
				{
					itemSubTypes = new string[0];
				}
				else
				{
					itemSubTypes = new string[itemsAsset.itemTypes[Target.itemType].subTypes.Count];
					for (int i = 0; i < itemsAsset.itemTypes[Target.itemType].subTypes.Count; i++)
					{
						itemSubTypes[i] = itemsAsset.itemTypes[Target.itemType].subTypes[i];
					}
				}
			}

			if (Target.itemType >= 0)
			{
				Target.itemSubType = plyEdGUI.Popup(" ", Target.itemSubType, itemSubTypes);
			}

			GUILayout.Label("Art");
			EditorGUI.indentLevel++;
			Target.floorArt = (GameObject)EditorGUILayout.ObjectField("Item on Floor", Target.floorArt, typeof(GameObject), true);
			Target.heldArt = (GameObject)EditorGUILayout.ObjectField("Item Held", Target.heldArt, typeof(GameObject), true);
			EditorGUI.indentLevel--;
			EditorGUILayout.Space();

			GUILayout.Label("Interact");
			EditorGUI.indentLevel++;
			Target.isCurrency = EditorGUILayout.Toggle("Is Currency", Target.isCurrency);
			if (Target.isCurrency)
			{
				Target.minCurrency = EditorGUILayout.IntField("Min Value", Target.minCurrency);
				Target.maxCurrency = EditorGUILayout.IntField("Max Value", Target.maxCurrency);
			}
			else
			{
				Target.baseValue = EditorGUILayout.IntField("Base Value", Target.baseValue);
			}

			bool ap = Target.autoPickupDist > 0.0f;
			EditorGUI.BeginChangeCheck();
			ap = EditorGUILayout.Toggle("Auto-pickup", ap);
			if (EditorGUI.EndChangeCheck()) { Target.autoPickupDist = ap ? 2.0f : 0.0f; EditorUtility.SetDirty(itemsAsset); }
			if (ap)
			{
				EditorGUI.indentLevel++;
				Target.autoPickupDist = EditorGUILayout.FloatField("Distance", Target.autoPickupDist);
				EditorGUI.indentLevel--;
			}
			Target.freezeRotWhenDrop = EditorGUILayout.Toggle("Drop-rot-freeze", Target.freezeRotWhenDrop);
			EditorGUI.indentLevel--;
			EditorGUILayout.Space();

			if (false == Target.isCurrency)
			{
				GUILayout.Label("Use");
				EditorGUI.indentLevel++;
				Target.consumeOnUse = EditorGUILayout.Toggle("Consumed on Use", Target.consumeOnUse);
				Target.canEquip = EditorGUILayout.Toggle("Can be Equipped", Target.canEquip);

				if (Target.canEquip)
				{
					Target.equipSlot = plyEdGUI.Popup("Slot", Target.equipSlot, slotNames);
				}
				else
				{
					if (Target.equipSlot != -1)
					{
						Target.equipSlot = -1;
						GUI.changed = true;
					}
				}

				EditorGUI.indentLevel--;
				EditorGUILayout.Space();

				GUILayout.Label("Bag");
				EditorGUI.indentLevel++;
				Target.maxStack = EditorGUILayout.IntField("Stack Size", Target.maxStack);

				if (itemsAsset.storageMethod == ItemsAsset.StorageMethod.Weight)
				{
					Target.weight = EditorGUILayout.FloatField("Weight", Target.weight);
				}
				else if (itemsAsset.storageMethod == ItemsAsset.StorageMethod.Slots)
				{
					GUILayout.Label("    Slots Layout: " + Target.hSlots + " x " + Target.vSlots);

					EditorGUILayout.BeginHorizontal();
					GUILayout.Space(30);
					for (int x = 0; x < 6; x++)
					{
						EditorGUILayout.BeginVertical();
						for (int y = 0; y < 6; y++)
						{
							if (GUILayout.Button(Target.hSlots > x && Target.vSlots > y ? GC_SlotOn : GC_SlotOff, SlotStyle))
							{
								Target.hSlots = x + 1;
								Target.vSlots = y + 1;
								EditorUtility.SetDirty(itemsAsset);
							}
						}
						EditorGUILayout.EndVertical();
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				EditorGUI.indentLevel--;
				EditorGUILayout.Space();
			}
		}

		// ============================================================================================================
	}
}
