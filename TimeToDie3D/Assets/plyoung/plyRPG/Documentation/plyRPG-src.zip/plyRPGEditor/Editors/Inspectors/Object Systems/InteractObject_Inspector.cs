﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(InteractObject))]
	public class InteractObject_Inspector : Editor
	{
		private InteractObject Target;
		private int activeImg = 0;
		private int imgEd = 0;

		// --------------------------------------------

		protected void OnEnable() 
		{
			Target = (InteractObject)target;
		}

		public override void OnInspectorGUI()
		{
			plyEdGUI.UseSkin();
			Target = (InteractObject)target;
			BasicInfo();
		}

		private void BasicInfo()
		{
			CommonDefinitionDataDrawer.Draw(Target.def, ref activeImg);
		}

		// ============================================================================================================
	}
}
