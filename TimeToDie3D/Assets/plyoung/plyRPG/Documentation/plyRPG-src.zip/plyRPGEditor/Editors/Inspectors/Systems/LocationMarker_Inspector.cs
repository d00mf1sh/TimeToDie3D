﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;
using plyBloxKit;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[CustomEditor(typeof(LocationMarker))]
	public class LocationMarker_Inspector : Editor
	{
		// ============================================================================================================

		protected void OnEnable() 
		{
			Texture2D icon = plyEdUtil.LoadIcon("sv_label_0");
			plyEdUtil.SetIconForObject(((LocationMarker)target).gameObject, icon);
		}

		public override void OnInspectorGUI()
		{
			LocationMarker Target = (LocationMarker)target;

			//EditorGUILayout.LabelField("ID", ((Marker)target).id.ToString());
			
			Target.ident = EditorGUILayout.IntField("ident", Target.ident);

			EditorGUILayout.BeginHorizontal();
			EditorGUILayout.PrefixLabel("Notes");
			Target.notes = EditorGUILayout.TextArea(Target.notes);
			EditorGUILayout.EndHorizontal();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		// ============================================================================================================
	}
}
