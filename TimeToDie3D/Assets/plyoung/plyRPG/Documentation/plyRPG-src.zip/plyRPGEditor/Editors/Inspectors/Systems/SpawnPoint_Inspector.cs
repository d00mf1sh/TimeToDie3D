﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyGame;
using plyBloxKit;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[CustomEditor(typeof(SpawnPoint))]
	public class SpawnPoint_Inspector : Editor
	{
		private SpawnPoint Target;
		private GUIContent GC_Add;
		private GUIContent GC_Del;
		private GUIContent GC_Exp;
		private int ed_opts = -1;

		// ============================================================================================================

		protected void OnEnable() 
		{
			Target = (SpawnPoint)target;
			if (Target.persistenceOn)
			{
				PersistableObject po = Target.gameObject.GetComponent<PersistableObject>();
				if (po == null)
				{
					po = Target.gameObject.AddComponent<PersistableObject>();
					po.persistPosition = false;
					po.persistDestroyedState = false;
					po.persistActiveState = false;
					EditorUtility.SetDirty(po);
					EditorUtility.SetDirty(Target.gameObject);
				}
			}

			if (UpdateEdHlp()) EditorUtility.SetDirty(target);
		}

		private void CheckGUIContent()
		{
			plyEdGUI.UseSkin();
			if (GC_Add == null)
			{
				GC_Add = new GUIContent(" Add Character", FA.Ico16(FA.plus, plyEdGUI.IconColor));
				GC_Del = new GUIContent(FA.minus.ToString(), "Remove Character from Group");
				GC_Exp = new GUIContent(FA.cog.ToString(), "Show/Hide more options");
			}
		}

		public override void OnInspectorGUI()
		{
			CheckGUIContent();

			Target.persistenceOn = EditorGUILayout.Toggle("Persistence On", Target.persistenceOn);
			EditorGUILayout.Space();

			Target.ident = EditorGUILayout.IntField("ident", Target.ident);
			EditorGUILayout.BeginHorizontal();
			EditorGUILayout.PrefixLabel("Notes");
			Target.notes = EditorGUILayout.TextArea(Target.notes);
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			GUILayout.Label("Spawner (De)activation");
			EditorGUI.indentLevel++;
			Target.activePlayerDistance = EditorGUILayout.FloatField("Player Distance", Target.activePlayerDistance);
			Target.activeCheckTimout = EditorGUILayout.FloatField("Check Interval (seconds)", Target.activeCheckTimout);
			EditorGUI.indentLevel--;

			GUILayout.Label("Player Detection");
			EditorGUI.indentLevel++;
			Target.spawnWhenPlayerDistance = EditorGUILayout.FloatField("Player Distance", Target.spawnWhenPlayerDistance);
			Target.plrDistanceCheckInterval = EditorGUILayout.FloatField("Check Interval (seconds)", Target.plrDistanceCheckInterval);
			EditorGUI.indentLevel--;

			Target.spawnMethod = (SpawnPoint.SpawnMethod)EditorGUILayout.EnumPopup("Spawn Method", Target.spawnMethod);
			Target.spawnRate = EditorGUILayout.FloatField(Target.spawnMethod == SpawnPoint.SpawnMethod.GroupContinues ? "Rate (sec)" : "Min wait time (sec)", Target.spawnRate);
			Target.rateBetweenSpawn = EditorGUILayout.FloatField("Rate between (sec)", Target.rateBetweenSpawn);

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Space(43);
				GUILayout.Label("Max", EditorStyles.largeLabel, GUILayout.Width(40));
				GUILayout.Label("Prefab", EditorStyles.largeLabel, GUILayout.MinWidth(110));
				GUILayout.Label("Lv", EditorStyles.largeLabel, GUILayout.Width(40));
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.DrawHorizontalLine(1, 0, plyEdGUI.DividerColor, plyEdGUI.HLineStyle, 1, 5);

			int del = -1;
			for (int i = 0; i < Target.spawnGroup.Count; i++)
			{
				EditorGUILayout.BeginHorizontal();
				{
					if (GUILayout.Button(GC_Del, plyEdGUI.MiniIconButtonLeftStyle, GUILayout.Width(20))) del = i;
					if (GUILayout.Button(GC_Exp, plyEdGUI.MiniIconButtonMidStyle, GUILayout.Width(20))) ed_opts = (ed_opts == i ? -1 : i);

					Target.spawnGroup[i].max = EditorGUILayout.IntField(Target.spawnGroup[i].max, GUILayout.Width(40));

					EditorGUI.BeginChangeCheck();
					Target.spawnGroup[i].fab = (GameObject)EditorGUILayout.ObjectField(Target.spawnGroup[i].fab, typeof(GameObject), false);
					if (EditorGUI.EndChangeCheck())
					{
						if (Target.spawnGroup[i].fab != null)
						{
							Actor a = Target.spawnGroup[i].fab.GetComponent<Actor>();
							if (a != null)
							{
								if (a.character != null)
								{
									if (a.character.IsPlayer())
									{
										Target.spawnGroup[i].fab = null;
										EditorUtility.DisplayDialog("Error", "Invalid prefab. Only non-player characters allowed.", "OK");
									}
								}
								else
								{
									Target.spawnGroup[i].fab = null;
									EditorUtility.DisplayDialog("Error", "Invalid prefab. The character is not correctly set up.", "OK");
								}
							}
							else
							{
								Target.spawnGroup[i].fab = null;
								EditorUtility.DisplayDialog("Error", "Invalid prefab. It must be a plyGame Character.", "OK");
							}
						}

						UpdateEdHlp();
					}

					Target.spawnGroup[i].initLevel = EditorGUILayout.IntField(Target.spawnGroup[i].initLevel, GUILayout.Width(40));
				}
				EditorGUILayout.EndHorizontal();

				if (ed_opts == i)
				{
					EditorGUILayout.BeginHorizontal();
					{
						GUILayout.Space(40);
						Target.spawnGroup[i].idleMode = (NPCController.IdleMode)EditorGUILayout.EnumPopup(Target.spawnGroup[i].idleMode, GUILayout.Width(80));

						if (Target.spawnGroup[i].idleMode == NPCController.IdleMode.Wander)
						{
							Target.spawnGroup[i].wanderArea = (NPCController.WanderArea)EditorGUILayout.EnumPopup(Target.spawnGroup[i].wanderArea);
							if (Target.spawnGroup[i].wanderArea == NPCController.WanderArea.Circular)
							{
								GUILayout.Label("Rad:", GUILayout.Width(30));
								Target.spawnGroup[i].wanderRadius = EditorGUILayout.FloatField(Target.spawnGroup[i].wanderRadius, GUILayout.Width(40));
							}
							else
							{
								GUILayout.Label("Size:", GUILayout.Width(30));
								Target.spawnGroup[i].wanderWH = EditorGUILayout.Vector2Field(GUIContent.none, Target.spawnGroup[i].wanderWH);
								EditorGUILayout.EndHorizontal();
								EditorGUILayout.BeginHorizontal();
								GUILayout.Space(40);
								GUILayout.Label("Ang:", GUILayout.Width(30));
								Target.spawnGroup[i].wanderRadius = EditorGUILayout.Slider(Target.spawnGroup[i].wanderRadius, 0, 180);
							}
							GUILayout.Label("Del:", GUILayout.Width(30));
							Target.spawnGroup[i].wanderDelayMin = EditorGUILayout.FloatField(Target.spawnGroup[i].wanderDelayMin, GUILayout.Width(40));
							GUILayout.Label("-", GUILayout.Width(8));
							Target.spawnGroup[i].wanderDelayMax = EditorGUILayout.FloatField(Target.spawnGroup[i].wanderDelayMax, GUILayout.Width(40));
						}
						else if (Target.spawnGroup[i].idleMode == NPCController.IdleMode.Patrol)
						{
							Target.spawnGroup[i].path = (WaypointPath)EditorGUILayout.ObjectField(Target.spawnGroup[i].path, typeof(WaypointPath), true);
						}
						else if (Target.spawnGroup[i].idleMode == NPCController.IdleMode.Follow)
						{
							Target.spawnGroup[i].followObject = (Transform)EditorGUILayout.ObjectField(Target.spawnGroup[i].followObject, typeof(Transform), true);
							GUILayout.Label("Dist:", GUILayout.Width(30));
							Target.spawnGroup[i].minFollowDistance = EditorGUILayout.FloatField(Target.spawnGroup[i].minFollowDistance, GUILayout.Width(40));
							GUILayout.Label("-", GUILayout.Width(8));
							Target.spawnGroup[i].maxFollowDistance = EditorGUILayout.FloatField(Target.spawnGroup[i].maxFollowDistance, GUILayout.Width(40));
						}
						else
						{
							GUILayout.FlexibleSpace();
						}
					}
					EditorGUILayout.EndHorizontal();
					GUILayout.Space(5);
				}
			}

			EditorGUILayout.Space();
			if (GUILayout.Button(GC_Add, GUILayout.Width(180)))
			{
				Target.spawnGroup.Add(new SpawnPoint.SpawnInfo());
				GUI.changed = true;
			}
			EditorGUILayout.Space();

			if (del >= 0)
			{
				Target.spawnGroup.RemoveAt(del);
				UpdateEdHlp();
				GUI.changed = true;
			}

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		protected void OnSceneGUI()
		{
			if (ed_opts < 0)
			{
				Handles.color = new Color(0.4f, 1f, 0.9f, 0.1f);
				Handles.DrawSolidDisc(Target.transform.position, Vector3.up, Target.spawnWhenPlayerDistance);
				Handles.color = new Color(0.4f, 1f, 0.9f, 1f);
				Handles.DrawWireDisc(Target.transform.position, Vector3.up, Target.spawnWhenPlayerDistance);
			}
			else OnSceneGUI_IdleMode();
		}

		protected void OnSceneGUI_IdleMode()
		{
			if (ed_opts >= Target.spawnGroup.Count) ed_opts = -1;
			if (ed_opts < 0) return;

			// *** IdleMode
			if (Target.spawnGroup[ed_opts].idleMode == NPCController.IdleMode.Wander)
			{
				Vector3 p = Target.transform.position;
				if (Target.spawnGroup[ed_opts].wanderArea == NPCController.WanderArea.Circular)
				{
					Handles.color = new Color(0.4f, 1f, 0.9f, 0.1f);
					Handles.DrawSolidDisc(p, Vector3.up, Target.spawnGroup[ed_opts].wanderRadius);
					Handles.color = new Color(0.4f, 1f, 0.9f, 1f);
					Handles.DrawWireDisc(p, Vector3.up, Target.spawnGroup[ed_opts].wanderRadius);
				}
				else
				{
					Vector3[] verts = plyUtil.RotatedRectangle(p, Target.spawnGroup[ed_opts].wanderWH, Target.spawnGroup[ed_opts].wanderRadius);
					Handles.color = Color.white;
					Handles.DrawSolidRectangleWithOutline(verts, new Color(0.4f, 1f, 0.9f, 0.1f), new Color(0.4f, 1f, 0.9f, 1f));
				}

			}
			else if (Target.spawnGroup[ed_opts].idleMode == NPCController.IdleMode.Patrol)
			{
				if (Target.spawnGroup[ed_opts].path != null)
				{
					Handles.color = new Color(0.4f, 1f, 0.9f, 1f);
					Handles.DrawLine(Target.transform.position + Vector3.up * 0.3f, Target.spawnGroup[ed_opts].path.transform.position + Vector3.up * 0.3f);
				}
			}
			else if (Target.spawnGroup[ed_opts].idleMode == NPCController.IdleMode.Follow)
			{
				if (Target.spawnGroup[ed_opts].followObject != null)
				{
					Handles.color = new Color(0.4f, 1f, 0.9f, 1f);
					Handles.DrawLine(Target.transform.position + Vector3.up * 0.3f, Target.spawnGroup[ed_opts].followObject.position + Vector3.up * 0.3f);
				}
			}
		}

		private bool UpdateEdHlp()
		{
			int hlp = 1;
			for (int i = 0; i < Target.spawnGroup.Count; i++)
			{
				if ( Target.spawnGroup[i].fab == null) continue;
				Actor a = Target.spawnGroup[i].fab.GetComponent<Actor>();
				if (a != null)
				{
					if (a.statusTowardsPlayer == StatusTowardsOther.Friendly && hlp == 1) hlp = 2;
					else if (a.statusTowardsPlayer != StatusTowardsOther.Friendly)
					{
						hlp = 3;
						break;
					}
				}
			}

			if (hlp != Target._edHlp)
			{
				Target._edHlp = hlp;
				return true;
			}

			return false;
		}

		// ============================================================================================================
	}
}
