﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyGame;
using plyBloxKit;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[ChildEditor("Skills", Order = -99973, Icon="skill")]
	public class Skill_Ed : ChildEditorBase
	{
		private DataAsset dataAsset;
		private SkillsAsset skillsAsset;
		private Skill currSkill = null;
		
		private Vector2[] scroll = { Vector2.zero, Vector2.zero };
		private int activeImg = 0;
		private int imgEd = 0;
		private int activefab = 0;

		private static GUIContent GC_plyBlox;
		private static GUIContent GC_plyBloxVars;
		private static GUIContent[] projectileImg = new GUIContent[3];

		// ============================================================================================================

		public override void OnFocus()
		{
			if (skillsAsset == null)
			{
				currSkill = null;
				dataAsset = EdGlobal.GetDataAsset();
				skillsAsset = (SkillsAsset)dataAsset.GetAsset<SkillsAsset>();
				if (skillsAsset == null)
				{
					skillsAsset = (SkillsAsset)EdGlobal.LoadOrCreateAsset<SkillsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "skills.asset", "Skill Definitions");
					if (skillsAsset.skillFabs.Count > 0)
					{	// make sure the asset is in the data asset if there is data defined
						if (dataAsset.AddAsset(skillsAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
			}
			skillsAsset.UpdateCache();
		}

		private void CheckGUIContent()
		{
			plyBloxGUI.UseSkin();
			if (GC_plyBlox == null)
			{
				GC_plyBlox = new GUIContent(" Edit Events", plyBloxGUI.LogoIcon16, "Open plyBlox Editor");
				GC_plyBloxVars = new GUIContent(" Edit Variables", FA.Ico16(FA.code, plyEdGUI.IconColor), "Edit Local plyBlox variables of object");
				projectileImg[0] = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.skillproj0.png", typeof(EdGlobal).Assembly));
				projectileImg[1] = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.skillproj1.png", typeof(EdGlobal).Assembly));
				projectileImg[2] = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.skillproj2.png", typeof(EdGlobal).Assembly));
			}
		}

		public override void OnGUI()
		{
			if (skillsAsset == null) return;

			CheckGUIContent();

			EditorGUILayout.BeginHorizontal();
			{
				if (plyEdGUI.ItemsList<Skill>(ref currSkill, skillsAsset.skills, true, false, true, false, OnListCallback, ref scroll[0], plyRPGEdGlobal.HLP_ClassesEd, "No Skills Defined", GUILayout.Width(230)))
				{
					plyEdGUI.ClearFocus();
				}

				if (currSkill != null)
				{
					scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
					EditorGUILayout.BeginVertical();
					{
						BasicInfo();
						plyBloxEdButtons();
						Settings();
						plyEdGUI.HLine(20);
					}
					EditorGUILayout.Space();
					EditorGUILayout.EndVertical();
					EditorGUILayout.EndScrollView(); 
				}
				else GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			// --------------------------------------------------------------------------------------------------------
			if (GUI.changed)
			{
				GUI.changed = false;
				if (currSkill != null) EditorUtility.SetDirty(currSkill);
				EditorUtility.SetDirty(skillsAsset);
			}
		}

		private Skill OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:add, 2:copied, 3:deleted, 4:called after delete (return default), 5:position changed, 6:rename

			if (act == 1)
			{
				UniqueID id = UniqueID.Create();
				string fn = plyRPGEdGlobal.DATA_PATH_SKILLS + id.ToString() + ".prefab";
				plyRPGEdGlobal.CheckDataPaths();

				//AssetDatabase.CopyAsset(EdGlobal.PACKAGE_PATH + "System/skilltemplate.prefab", fn);
				//GameObject skillFab = (GameObject)AssetDatabase.LoadAssetAtPath(fn, typeof(GameObject));
				GameObject skillFab = plyEdUtil.CreatePrefab<Skill>("Skill", fn);
				AssetDatabase.Refresh();

				currSkill = skillFab.GetComponent<Skill>();
				currSkill.id = id;
				currSkill.def.screenName = "Skill " + skillsAsset.skillFabs.Count;
				EditorUtility.SetDirty(skillFab);

				skillsAsset.skillFabs.Add(skillFab);
				EditorUtility.SetDirty(skillsAsset);

				skillsAsset.skills.Add(currSkill);
				if (dataAsset.AddAsset(skillsAsset)) EditorUtility.SetDirty(dataAsset);
				return currSkill;
			}
			else if (act == 2)
			{
				Skill a = args[1] as Skill;

				UniqueID id = UniqueID.Create();
				string fn = plyRPGEdGlobal.DATA_PATH_SKILLS + id.ToString() + ".prefab";
				plyRPGEdGlobal.CheckDataPaths();

				//AssetDatabase.CopyAsset(EdGlobal.PACKAGE_PATH + "System/skilltemplate.prefab", fn);
				//GameObject skillFab = (GameObject)AssetDatabase.LoadAssetAtPath(fn, typeof(GameObject));
				GameObject skillFab = plyEdUtil.CreatePrefab<Skill>("Skill", fn);
				AssetDatabase.Refresh();

				currSkill = skillFab.GetComponent<Skill>();
				a.CopyTo(currSkill);
				currSkill.id = id;
				currSkill.def.screenName = currSkill.def.screenName + " (copy)";

				skillsAsset.skillFabs.Add(skillFab);
				EditorUtility.SetDirty(skillFab);
				EditorUtility.SetDirty(skillsAsset);

				skillsAsset.skills.Add(currSkill);

				if (dataAsset.AddAsset(skillsAsset)) EditorUtility.SetDirty(dataAsset);
				return currSkill;
			}
			else if (act == 3)
			{
				plyRPGEdGlobal.CheckDataPaths();
				Skill a = args[1] as Skill;
				string fn = plyRPGEdGlobal.DATA_PATH_SKILLS + a.id.ToString() + ".prefab";
				//skillsAsset.skills.Remove(a); < the plyEdGUI.ItemsList does this, do not do it here
				skillsAsset.skillFabs.Remove(a.gameObject);
				EditorUtility.SetDirty(skillsAsset);
				AssetDatabase.DeleteAsset(fn);
				AssetDatabase.Refresh();
				return null;
			}
			else if (act == 4)
			{
				currSkill = skillsAsset.skills.Count > 0 ? skillsAsset.skills[0] : null;

				if (skillsAsset.skillFabs.Count == 0)
				{	// remove from dataAsset if no data defined
					if (dataAsset.RemoveAsset(skillsAsset)) EditorUtility.SetDirty(dataAsset);
				} 

				return currSkill;
			}
			else if (act == 5)
			{
				skillsAsset.skillFabs = new List<GameObject>();
				for (int i = 0; i < skillsAsset.skills.Count; i++) skillsAsset.skillFabs.Add(skillsAsset.skills[i].gameObject);
			}

			EditorUtility.SetDirty(skillsAsset);
			return null;
		}

		private void BasicInfo()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Skill Definition");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				CommonDefinitionDataDrawer.Draw(currSkill.def, ref activeImg);
			}
			EditorGUILayout.EndVertical();
		}

		private void Settings()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Basic");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				currSkill.executionTimeout = EditorGUILayout.FloatField("Execution Time", currSkill.executionTimeout);
				currSkill.cooldownTimeout = EditorGUILayout.FloatField("Cool-down Time", currSkill.cooldownTimeout);
				currSkill.mayPerformWhileMove = EditorGUILayout.Toggle("Perform while move", currSkill.mayPerformWhileMove);
				currSkill.forceStop = EditorGUILayout.Toggle("Force Stop", currSkill.forceStop);
				currSkill.canBeQueued = EditorGUILayout.Toggle("Can be queued", currSkill.canBeQueued);
				EditorGUI.indentLevel++;
				GUI.enabled = currSkill.canBeQueued;
				currSkill.autoQueue = EditorGUILayout.Toggle("Auto-queue", currSkill.autoQueue);
				GUI.enabled = true;
				EditorGUI.indentLevel--;
			}
			EditorGUILayout.EndVertical();

			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Activation");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				currSkill.activation = (Skill.Activation)EditorGUILayout.EnumPopup("Activation", currSkill.activation);
				if (currSkill.activation == Skill.Activation.Passive)
				{
					EditorGUILayout.Space();
					GUILayout.Label("Passive skills has nothing else to edit.");
					EditorGUILayout.EndVertical();
					return;
				}

				currSkill.deliveryMethod = (Skill.DeliveryMethod)EditorGUILayout.EnumPopup("Delivery", currSkill.deliveryMethod);
				EditorGUILayout.Space();
				currSkill.targetingMethodMask = (Skill.TargetingMethod)EditorGUILayout.EnumMaskField("Target Methods", currSkill.targetingMethodMask);
				currSkill.validTargetsMask = (Skill.ValidTargets)EditorGUILayout.EnumMaskField("Valid Target(s)", currSkill.validTargetsMask);
				EditorGUILayout.Space();
				currSkill.obstacleCheckMask = plyEdGUI.LayerMaskField("Obstacle Check", currSkill.obstacleCheckMask, 0);
				if (currSkill.obstacleCheckMask != 0)
				{
					currSkill.obstacbleCheckHeight = EditorGUILayout.FloatField("Check height offset", currSkill.obstacbleCheckHeight);
				}
			}
			EditorGUILayout.EndVertical();

			switch (currSkill.deliveryMethod)
			{
				case Skill.DeliveryMethod.Instant: InstantDelivery(); break;
				case Skill.DeliveryMethod.Projectile: ProjectileDelivery(); break;
				//case Skill.DeliveryMethod.Pathing: PathingDelivery(); break;
			}

			SecondaryHit();
		}

		private void ShowTargetingRange(bool force360)
		{
			EditorGUILayout.BeginHorizontal();
			EditorGUILayout.BeginVertical(GUILayout.Width(EditorGUIUtility.labelWidth));
			{
				GUILayout.Label("Targeting Range");
			}
			EditorGUILayout.EndVertical();
			EditorGUILayout.BeginVertical();
			{
				plyEdGUI.LookLikeControls(60);
				if (force360)
				{
					GUI.enabled = false;
					plyEdGUI.AngleField("Angle", 360, 10, 360, plyEdGUI.ColorTealTrans, 200, 100, currSkill.targetingRadius, 20);
					GUI.enabled = true;
					currSkill.targetingRadius = EditorGUILayout.IntSlider("Radius", currSkill.targetingRadius, 1, 20, GUILayout.Width(200));
				}
				else currSkill.targetingAngle = plyEdGUI.AngleField("Angle", currSkill.targetingAngle, 10, 360, plyEdGUI.ColorTealTrans, 200, 100, 0, 0);
				plyEdGUI.LookLikeControls();
				EditorGUILayout.Space();
			}
			EditorGUILayout.EndVertical();
			EditorGUILayout.EndHorizontal();
		}

		private void InstantDelivery()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Instant Delivery");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				currSkill.targetLocation = (Skill.TargetLocation)EditorGUILayout.EnumPopup("Direction/ Location", currSkill.targetLocation);
				currSkill.hitHeightPercentage = EditorGUILayout.IntSlider("Hit Height %", currSkill.hitHeightPercentage, 0, 100);
				currSkill.instantHitDelay = EditorGUILayout.Slider("Hit Delay", currSkill.instantHitDelay, 0f, 60f);
				currSkill.maxEffects = EditorGUILayout.IntSlider("Max Targets Select", currSkill.maxEffects, 1, 20);
				currSkill.targetingDistance = EditorGUILayout.Slider("Max Distance from self", currSkill.targetingDistance, 1, 100);

				if (currSkill.targetLocation == Skill.TargetLocation.AtClickPosition ||
					currSkill.targetLocation == Skill.TargetLocation.AtSelected ||
					currSkill.targetLocation == Skill.TargetLocation.MouseOver)
				{
					ShowTargetingRange(true);
				}
				else
				{
					ShowTargetingRange(false);
				}
			}
			EditorGUILayout.EndVertical();
		}

		private void ProjectileDelivery()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Projectile Delivery");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				EditorGUILayout.BeginHorizontal();
				EditorGUILayout.BeginVertical();
				{
					EditorGUILayout.BeginHorizontal();
					GUILayout.Space(EditorGUIUtility.labelWidth + 10);
					for (int i = 0; i < currSkill.projectileFabs.Length; i++)
					{
						if (plyEdGUI.ToggleButton(activefab == i, (i + 1).ToString(), EditorStyles.miniButton, GUILayout.Width(25))) activefab = i;
					}
					EditorGUILayout.EndHorizontal();

					currSkill.projectileFabs[activefab] = (GameObject)EditorGUILayout.ObjectField("Prefab(s)", currSkill.projectileFabs[activefab], typeof(GameObject), false);
					EditorGUILayout.Space();

					currSkill.projectileMoveMethod = (Skill.ProjectileMoveMethod)EditorGUILayout.EnumPopup("Move Method", currSkill.projectileMoveMethod);
					if (currSkill.projectileMoveMethod == Skill.ProjectileMoveMethod.AngledFromEach)
					{
						currSkill.moveMethod_b_opt = EditorGUILayout.Toggle("Random Angle", currSkill.moveMethod_b_opt);
					}
					if (currSkill.projectileMoveMethod == Skill.ProjectileMoveMethod.DirectToTarget)
					{
						currSkill.moveMethod_b_opt = EditorGUILayout.Toggle("Follow", currSkill.moveMethod_b_opt);
						currSkill.hitHeightPercentage = EditorGUILayout.IntSlider("Hit Height %", currSkill.hitHeightPercentage, 0, 100);
					}
					currSkill.maxEffects = EditorGUILayout.IntSlider("Max Projectiles", currSkill.maxEffects, 1, 20);
					currSkill.projectileCreateDelay = EditorGUILayout.Slider("Create Delay", currSkill.projectileCreateDelay, 0f, 10f);
					currSkill.projectileCreateDelayBetween = EditorGUILayout.Slider("Between Create Delay", currSkill.projectileCreateDelayBetween, 0f, 10f);

					currSkill.useVectorOffset = EditorGUILayout.Toggle("Use Vector offset", currSkill.useVectorOffset);
					if (currSkill.useVectorOffset) currSkill.projectileCreateOffset = EditorGUILayout.Vector3Field("Create at Offset", currSkill.projectileCreateOffset);
					else currSkill.projectileCreateAtTagged = EditorGUILayout.TextField("Create at Tagged", currSkill.projectileCreateAtTagged);

					currSkill.projectileMoveSpeed = EditorGUILayout.FloatField("Move Speed", currSkill.projectileMoveSpeed);
					currSkill.collisionRayWidth = EditorGUILayout.FloatField("Collision Ray Width", currSkill.collisionRayWidth);
					if (currSkill.projectileMoveMethod != Skill.ProjectileMoveMethod.DirectToTarget)
					{
						currSkill.maxFlightDistance = EditorGUILayout.IntSlider("Fizzle Distance", currSkill.maxFlightDistance, 1, 100);
					}
					currSkill.maxLiveTime = EditorGUILayout.FloatField("Max Live Time", currSkill.maxLiveTime);
					currSkill.triggerSecondaryOnFizzle = EditorGUILayout.Toggle("Trigger secondary on Fizzle", currSkill.triggerSecondaryOnFizzle);
					if (currSkill.triggerSecondaryOnFizzle) currSkill.triggerSecondaryOnFizzleOnlyIfObstacle = EditorGUILayout.Toggle("...only if obstacle", currSkill.triggerSecondaryOnFizzleOnlyIfObstacle);
					currSkill.destroyProjectileOnHit = EditorGUILayout.Toggle("Destroy Projectile on Hit", currSkill.destroyProjectileOnHit);
				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.BeginVertical(GUILayout.Width(100));
				{
					GUILayout.Box(projectileImg[(int)currSkill.projectileMoveMethod], plyEdGUI.BoxNoPaddingStyle, GUILayout.Width(100), GUILayout.Height(100));
				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Space();

				if (currSkill.projectileMoveMethod == Skill.ProjectileMoveMethod.ActorFaceDirection)
				{
					currSkill.targetLocation = (Skill.TargetLocation)EditorGUILayout.EnumPopup("Actor Direction", currSkill.targetLocation);
					currSkill.targetingDistance = EditorGUILayout.Slider("Max Distance from self", currSkill.targetingDistance, 1, 100);
				}
				else if (currSkill.projectileMoveMethod == Skill.ProjectileMoveMethod.AngledFromEach)
				{
					currSkill.targetLocation = (Skill.TargetLocation)EditorGUILayout.EnumPopup("Actor Direction", currSkill.targetLocation);
					currSkill.targetingDistance = EditorGUILayout.Slider("Max Distance from self", currSkill.targetingDistance, 1, 100);
					ShowTargetingRange(false);
				}
				else if (currSkill.projectileMoveMethod == Skill.ProjectileMoveMethod.DirectToTarget)
				{
					currSkill.targetLocation = (Skill.TargetLocation)EditorGUILayout.EnumPopup("Actor Direction", currSkill.targetLocation);
					currSkill.targetingDistance = EditorGUILayout.Slider("Max Distance from self", currSkill.targetingDistance, 1, 100);
					if (currSkill.targetLocation == Skill.TargetLocation.AtClickPosition ||
						currSkill.targetLocation == Skill.TargetLocation.AtSelected ||
						currSkill.targetLocation == Skill.TargetLocation.MouseOver)
					{
						ShowTargetingRange(true);
					}
					else
					{
						ShowTargetingRange(false);
					}
				}
			}
			EditorGUILayout.EndVertical();
		}

		private void plyBloxEdButtons()
		{
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			if (GUILayout.Button(GC_plyBlox, GUILayout.Width(120), GUILayout.Height(25)))
			{
				if (currSkill.blox == null)
				{
					currSkill.blox = currSkill.gameObject.GetComponent<plyBlox>();
					EditorUtility.SetDirty(currSkill);
				}

				if (currSkill.blox != null)
				{
					Selection.activeObject = currSkill.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
					plyBloxEd.Show_plyBloxEd(currSkill.blox, currSkill.def.screenName);
				}
				else Debug.LogError("[Skill Editor] The Skill object is invalid. No plyBlox object was found on it.");
			}
			EditorGUILayout.Space();
			if (GUILayout.Button(GC_plyBloxVars, GUILayout.Width(135), GUILayout.Height(25)))
			{
				if (currSkill.blox == null)
				{
					currSkill.blox = currSkill.gameObject.GetComponent<plyBlox>();
					EditorUtility.SetDirty(currSkill);
				}

				if (currSkill.blox != null)
				{
					Selection.activeObject = currSkill.gameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
				}
				else Debug.LogError("[Skill Editor] The Skill object is invalid. No plyBlox object was found on it.");
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();
		}

		private void SecondaryHit()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Secondary Hit");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				currSkill.secondaryMaxTargets = EditorGUILayout.IntSlider("Max Secondary Targets", currSkill.secondaryMaxTargets, 0, 20);

				if (currSkill.secondaryMaxTargets > 0)
				{
					currSkill.secondaryObstacleCheckMask = plyEdGUI.LayerMaskField("Obstacle Check", currSkill.secondaryObstacleCheckMask, 0);
					if (currSkill.secondaryObstacleCheckMask != 0)
					{
						currSkill.secondaryObstacbleCheckHeight = EditorGUILayout.FloatField("Check height offset", currSkill.secondaryObstacbleCheckHeight);
					}
					EditorGUILayout.BeginHorizontal();
					EditorGUILayout.BeginVertical(GUILayout.Width(EditorGUIUtility.labelWidth));
					{
						GUILayout.Label("Range");
					}
					EditorGUILayout.EndVertical();
					EditorGUILayout.BeginVertical();
					{
						plyEdGUI.LookLikeControls(60);
						GUI.enabled = false;
						plyEdGUI.AngleField("Angle", 360, 10, 360, plyEdGUI.ColorTealTrans, 200, 100, currSkill.secondaryRadius, 20);
						GUI.enabled = true;
						currSkill.secondaryRadius = EditorGUILayout.IntSlider("Radius", currSkill.secondaryRadius, 1, 20, GUILayout.Width(200));
						plyEdGUI.LookLikeControls();
						EditorGUILayout.Space();
					}
					EditorGUILayout.EndVertical();
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.Space();
				}
			}
			EditorGUILayout.EndVertical();
		}

		// ============================================================================================================
	}
}