﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	public class Player_InputDefiner : InputDefiner
	{
		public override List<InputDefinition> DefineInput()
		{
			return new List<InputDefinition>()
			{
				new InputDefinition() {
					category = "Player", name = "ClickSelectTarget",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Mouse0 } }
				},
				new InputDefinition() {
					category = "Player", name = "SelectNextTarget", screenName1 = "Next Target",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { 
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Tab },
						new InputBind() { device = InputBind.Device.Gamepad, key1 = KeyCode.JoystickButton4 } 
					}
				},
				new InputDefinition() {
					category = "Player", name = "ClearTarget",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { 
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Escape },
						new InputBind() { device = InputBind.Device.Gamepad, key1 = KeyCode.JoystickButton1 } 
					}				},

				new InputDefinition() {
					category = "Player", name = "ClickInteract",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Mouse1 } }
				},
				new InputDefinition() {
					category = "Player", name = "Interact",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.E } }
				},

			};
		}

		// ============================================================================================================
	}
}
