﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	[System.Serializable]
	public class plyRPGEdDataAsset : ScriptableObject
	{
		[HideInInspector] public List<GameObject> actorFabs = new List<GameObject>(0);
		[HideInInspector, System.NonSerialized] public List<Actor> actors = new List<Actor>(0);

		// ============================================================================================================

		public bool UpdateActorCache()
		{
			bool ret = false;

			// first check if there are "null" entries and remove them now
			if (actorFabs.Count > 0)
			{
				for (int i = actorFabs.Count - 1; i >= 0; i--)
				{
					if (actorFabs[i] == null)
					{
						ret = true;
						actorFabs.RemoveAt(i);
						continue;
					}

					if (actorFabs[i].GetComponent<Actor>() == null)
					{
						ret = true;
						actorFabs.RemoveAt(i);
						continue;
					}
				}
			}

			actors = new List<Actor>(actorFabs.Count);
			for (int i = 0; i < actorFabs.Count; i++)
			{
				actors.Add(actorFabs[i].GetComponent<Actor>());
			}

			return ret;
		}

		public void CheckActorFab(Actor actor)
		{
			Object obj = EditorUtility.IsPersistent(actor) ? actor : PrefabUtility.GetPrefabParent(actor);
			if (obj != null)
			{
				actor = (Actor)obj;
				if (false == actorFabs.Contains(actor.gameObject))
				{
					actorFabs.Add(actor.gameObject);
					EditorUtility.SetDirty(this);
					UpdateActorCache();
				}
			}
		}

		// ============================================================================================================
	}
}