﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyBloxKit;
using plyBloxKitEditor;
using plyGame;
using plyCommonEditor;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(CharaAniClipNameData))]
	public class CharaAniClipNameData_Handler : plyBlockFieldHandler
	{

		private string[] clips = new string[0];

		public override object GetCopy(object obj)
		{
			CharaAniClipNameData target = obj as CharaAniClipNameData;
			if (target != null) return target.Copy();
			return new CharaAniClipNameData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			LegacyAnimControl aniControl = null;
			
			// Check if there is a field named "targetChara" as it is most likely candidate here
			FieldInfo[] fields = fieldOfBlock.GetType().GetFields();
			for (int i = 0; i < fields.Length; i++)
			{
				if (fields[i].FieldType == typeof(GameObject_Value))
				{
					if (fields[i].Name.Equals("targetChara"))
					{
						GameObject_Value cv = fields[i].GetValue(fieldOfBlock) as GameObject_Value;
						if (cv != null)
						{
							GameObject go = cv.value as GameObject;
							if (go != null)
							{
								aniControl = go.GetComponent<LegacyAnimControl>(); 
							}
						}
						break;
					}
				}
			}

			// If nothing found then look for one on Blox' GameObject this field is used in.
			if (aniControl == null)
			{
				if (fieldOfBlock.owningBlox != null)
				{
					aniControl = fieldOfBlock.owningBlox.gameObject.GetComponent<LegacyAnimControl>();
				}
			}

			if (aniControl == null)
			{
				if (clips.Length > 0) clips = new string[0];
				return;
			}

			if (aniControl.ani == null)
			{
				if (clips.Length > 0) clips = new string[0];
				return;
			}

			List<string> names = new List<string>();
			foreach (AnimationState state in aniControl.ani)
			{
				if (!string.IsNullOrEmpty(state.name)) names.Add(state.name);
			}

			clips = new string[names.Count];
			for (int i = 0; i < names.Count; i++) clips[i] = names[i];
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			CharaAniClipNameData target = obj == null ? new CharaAniClipNameData() : obj as CharaAniClipNameData;

			EditorGUI.BeginChangeCheck();
			target.name = EditorGUILayout.TextField(target.name, plyEdGUI.TextFieldNoLRMarginStyle);
			if (EditorGUI.EndChangeCheck()) ret = true;

			int sel = EditorGUILayout.Popup(-1, clips, EditorStyles.miniButtonRight, GUILayout.Width(20));
			if (sel >= 0)
			{
				target.name = clips[sel];
				ret = true;
			}

			obj = target;
			return ret;
		}

		// ============================================================================================================
	}
}