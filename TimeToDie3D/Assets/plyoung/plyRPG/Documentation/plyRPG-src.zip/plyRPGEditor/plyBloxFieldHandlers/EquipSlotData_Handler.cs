﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyBloxKitEditor;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(EquipSlotData))]
	public class EquipSlotData_Handler : plyBlockFieldHandler
	{

		private string[] names = new string[0];
		private ItemsAsset asset;

		public override object GetCopy(object obj)
		{
			EquipSlotData target = obj as EquipSlotData;
			if (target != null) return target.Copy();
			return new EquipSlotData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			EquipSlotData target = obj == null ? new EquipSlotData() : obj as EquipSlotData;
			CheckNamesArray();
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			EquipSlotData target = obj == null ? new EquipSlotData() : obj as EquipSlotData;

			EditorGUI.BeginChangeCheck();
			target.name = EditorGUILayout.TextField(target.name, plyEdGUI.TextFieldNoLRMarginStyle);
			if (EditorGUI.EndChangeCheck()) ret = true;

			int sel = EditorGUILayout.Popup(-1, names, EditorStyles.miniButtonRight, GUILayout.Width(20));
			if (sel >= 0)
			{
				target.name = names[sel];
				ret = true;
			}

			obj = target;
			return ret;
		}

		private void CheckNamesArray()
		{
			asset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(plyEdUtil.DATA_PATH_SYSTEM + "items.asset", null);
			if (names.Length != asset.equipSlots.Count)
			{
				names = new string[asset.equipSlots.Count];
				for (int i = 0; i < names.Length; i++)
				{
					names[i] = asset.equipSlots[i];
				}
			}
		}

		// ============================================================================================================
	}
}