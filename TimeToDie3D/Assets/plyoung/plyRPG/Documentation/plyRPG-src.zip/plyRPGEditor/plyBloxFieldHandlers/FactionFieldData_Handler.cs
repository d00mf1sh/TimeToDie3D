﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyBloxKitEditor;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(FactionFieldData))]
	public class FactionFieldData_Handler : plyBlockFieldHandler
	{

		private ActorFactionManager asset;

		public override object GetCopy(object obj)
		{
			FactionFieldData target = obj as FactionFieldData;
			if (target != null) return target.Copy();
			return new FactionFieldData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			FactionFieldData target = obj == null ? new FactionFieldData() : obj as FactionFieldData;
			if (asset == null)
			{
				GameObject fab = plyEdUtil.LoadOrCreatePrefab<ActorFactionManager>("Factions Manager", plyEdUtil.DATA_PATH_SYSTEM + "factionsman.prefab");
				asset = fab.GetComponent<ActorFactionManager>();
			}

			// check if saved faction still valid
			if (!string.IsNullOrEmpty(target.id))
			{
				bool found = false;
				UniqueID id = new UniqueID(target.id);
				for (int i = 0; i < asset.definedFactions.Count; i++)
				{
					if (id == asset.definedFactions[i].id) { found = true; break; }
				}
				if (!found)
				{
					target.id = "";
					target.cachedName = "";
					ed.ForceSerialise();
				}
			}
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			FactionFieldData target = obj == null ? new FactionFieldData() : obj as FactionFieldData;

			if (GUILayout.Button(string.IsNullOrEmpty(target.cachedName) ? "-select-" : target.cachedName))
			{
				List<object> l = new List<object>();
				for (int i = 0; i < asset.definedFactions.Count; i++) l.Add(new UniqueIdNamePair() { id = asset.definedFactions[i].id.Copy(), name = asset.definedFactions[i].def.screenName });
				plyListSelectWiz.ShowWiz("Select Faction", l, true, null, OnFactionSelect, new object[] { ed, target });
			}

			obj = target;
			return ret;
		}

		private void OnFactionSelect(object sender, object[] args)
		{
			FactionFieldData target = args[1] as FactionFieldData;
			plyBloxEd plyed = args[0] as plyBloxEd;

			plyListSelectWiz wiz = sender as plyListSelectWiz;
			UniqueIdNamePair uimp = wiz.selected as UniqueIdNamePair;
			wiz.Close();

			if (plyed == null || target == null) return;

			GUI.changed = true;
			if (uimp != null)
			{
				target.id = uimp.id.ToString();
				target.cachedName = uimp.name;
			}
			else
			{
				target.id = "";
				target.cachedName = "";
			}
			plyed.ForceSerialise();
			plyed.Repaint();
		}
		
		// ============================================================================================================
	}
}