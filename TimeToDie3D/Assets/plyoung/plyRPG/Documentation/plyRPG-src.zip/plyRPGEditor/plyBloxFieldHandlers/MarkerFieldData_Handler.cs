﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyBloxKitEditor;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(MarkerFieldData))]
	public class MarkerFieldData_Handler : plyBlockFieldHandler
	{

		private MarkersAsset markerAsset;

		public override object GetCopy(object obj)
		{
			MarkerFieldData target = obj as MarkerFieldData;
			if (target != null) return target.Copy();
			return new MarkerFieldData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			MarkerFieldData target = obj == null ? new MarkerFieldData() : obj as MarkerFieldData;
			if (markerAsset == null)
			{
				markerAsset = (MarkersAsset)EdGlobal.LoadOrCreateAsset<MarkersAsset>(plyEdUtil.DATA_PATH_SYSTEM + "markers.asset", "Marker Definitions");
				markerAsset.UpdateCache();
			}

			// check if saved still valid
			if (!string.IsNullOrEmpty(target.id))
			{
				bool found = false;
				UniqueID id = new UniqueID(target.id);
				for (int i = 0; i < markerAsset.markers.Count; i++)
				{
					if (id == markerAsset.markers[i].id) { found = true; break; }
				}
				if (!found)
				{
					target.id = "";
					target.cachedName = "";
					ed.ForceSerialise();
				}
			}
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			MarkerFieldData target = obj == null ? new MarkerFieldData() : obj as MarkerFieldData;

			if (GUILayout.Button(string.IsNullOrEmpty(target.cachedName) ? "-select-" : target.cachedName))
			{
				markerAsset.UpdateCacheIfNeeded();
				List<object> l = new List<object>();
				for (int i = 0; i < markerAsset.markers.Count; i++) l.Add(new UniqueIdNamePair() { id = markerAsset.markers[i].id.Copy(), name = markerAsset.markers[i].name });
				plyListSelectWiz.ShowWiz("Select Marker", l, true, null, OnSelect, new object[] { ed, target });
			}

			obj = target;
			return ret;
		}

		private void OnSelect(object sender, object[] args)
		{
			MarkerFieldData target = args[1] as MarkerFieldData;
			plyBloxEd plyed = args[0] as plyBloxEd;

			plyListSelectWiz wiz = sender as plyListSelectWiz;
			UniqueIdNamePair uimp = wiz.selected as UniqueIdNamePair;
			wiz.Close();

			if (plyed == null || target == null) return;

			GUI.changed = true;
			if (uimp != null)
			{
				target.id = uimp.id.ToString();
				target.cachedName = uimp.name;
			}
			else
			{
				target.id = "";
				target.cachedName = "";
			}
			plyed.ForceSerialise();
			plyed.Repaint();
		}
		
		// ============================================================================================================
	}
}