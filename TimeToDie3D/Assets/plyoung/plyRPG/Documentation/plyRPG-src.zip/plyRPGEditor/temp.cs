﻿
//using UnityEngine;
//using UnityEditor;
//using plyCommonEditor;
//using plyBloxKitEditor;

//namespace myUniqueNamespace
//{
//	[InitializeOnLoad]
//	public class MyEditorScript
//	{
//		static MyEditorScript()
//		{
//			EditorApplication.update += RunOnce;
//		}

//		private static void RunOnce()
//		{
//			EditorApplication.update -= RunOnce;

//			// init things here that should be loaded once the editor is up 
//			// and would/ might cause errors if it executed in Constructor

//			// load the icon that will be used in the Block attribute field "ShowIcon"
//			// here you can use the plyEdGUI function to help with loading
//			Texture2D icon = plyEdGUI.LoadEditorTexture("Assets/plyBlox Plugins/MyBlocks/Icons/ico1.png");
				
//			// 'icon_name' should be a unique name of the icon as used with ShowIcon
//			plyBloxGUI.blockIcons.Add("icon_name", icon);
//		}
//	}
//}